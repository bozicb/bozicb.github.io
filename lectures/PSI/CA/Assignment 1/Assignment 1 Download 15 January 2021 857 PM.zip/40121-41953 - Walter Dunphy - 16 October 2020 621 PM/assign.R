# Q1) a, The variables; Age, height and weight are all continuous variables.
#  The variables Profession and Name are categorical.

#  b,  Nominal = Name Gender subject   
# Ordinal = Staff number Semester  
#
# c, 
# z score = .39 - .33 / .03 = 2 
# P(2.0) = 0.0228 , got from tables 
# 100 * .0228 = 2.28 bottles are expected to contain more than 0.39L
#
# Q2 
# a)

salary <- readRDS("salary.rds")
names(salary)
summary(salary)

install.packages('pastecs')
install.packages('psych')
install.packages('Hmisc')

library('Hmisc')
library('pastecs')
library('psych')

# b)
packageDescription('Hmisc') 
# Contains many functions useful for data analysis 
packageDescription('pastecs')
packageDescription('psych')

describe(salary) # both pysch and Hmisc packages use describe function

stat.desc(salary) # using package pastecs to describe the data  

# c)

describeBy(salary, salary$gender)
# using psych package describeBy function to 
# generate summary statistics grouping by Gender 

# d)
data(iris) # load iris dataset 

names(iris)
summary(iris$Petal.Length)
# from summary function we see that;
# median = 4.35
# mean = 3.758
# Range = max - min of Petal.Length = 6.9 - 1.0 
# Range = 5.9
quantile(iris$Petal.Length)
quantile(iris$Petal.Length, 0.98)
# 98th percentile = 6.602

# e) 
hist(iris$Sepal.Width)
# dispersion method = median, as visibly from the histogram there are 
# outliers in the data that would affect the use of the mean. 

# f)
data("HairEyeColor")
dataHaireye <- as.data.frame(HairEyeColor)

Combo <- apply(HairEyeColor, c(1, 2), sum)
Combo
mosaicplot(Combo, main = "Relation between hair and eye color", shade = TRUE)
# mosaic plots are suitable for multivariate categorical data 

# Q3,
# a)
set.seed(19) 
RainfallDub <- floor( runif(20, min = 0, max = 28)) 
 # using random number generating function, runif
RainfallCork <- floor( runif(20, min = 0, max = 28))
RainfallDub
RainfallCork

AnnualRain <- matrix(c(RainfallDub, RainfallCork), ncol = 2, byrow = TRUE)

x <- colnames(AnnualRain) <- c('Dublin', 'Cork')
y <- rownames(AnnualRain) <- c(1:20)
# plot
library(TSA) # load package time series analysis 

dev.new(width=5, height=8)
plot.ts(AnnualRain, xlab = "Year 1 to 20", ylab = y)
# As we are looking to plot data over a period of time I felt it suitable
# to use a time series plot.
# From the plot we can compare the rainfall for the two cities from year
# 1 to 20 of the last 20 years. For example in year 1 Dublin had annual average
# rainfall of 3 compared to Cork which had an average of 19

mosaicplot(AnnualRain, shade = TRUE)

#b)
setWorld <- read.table('world-small.csv', sep = ',', header = TRUE)
names(setWorld)
hist(setWorld)
# i
hist(setWorld$gdppcap08)
# ii.
boxplot(setWorld$polityIV)

summary(setWorld)
attach(setWorld)
# iii.
summarize(setWorld$gdppcap08, setWorld$region, max)
# = from output We see the middle east has the highest gdpcap

# iv.
summarize(setWorld$country, setWorld$polityIV, min)
# = from output we see Qatar , has the lowest of polityIV  

#3. c) 
PetLovers <- data.frame(numberofpeople=c(298, 492, 785, 2034), pet=c("Macaw","cats","fish","dogs"))
PetLovers
# bar chart i feel is the most suitable graph for the pets dataset

library(ggplot2)

PetPlot <- ggplot(PetLovers, aes(pet, numberofpeople))
PetPlot+geom_col(stat = "identity") 
# bar chart, from this we can visualize clearly just how many more dog owners 
# are in Dublin as opposed to the other pets with fish the next most popular. 

# it is not a good idea to use a pie chart as examining part to whole
# relationships with regard pet owners with simple proportions doesn't provide 
# meaningful information. Also pie charts are poor at communicating the data. 
