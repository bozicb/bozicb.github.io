#Question 1A answer continuous variables=height,weight,age. Categorical variables = profession , name

#Question 1B Answer = Nominal = gender,name,subject Ordinal= Staff number,Semester

 
#Question 1C Answer= z score = 2 (.39-.33)/0.03 = 2 
#As a proportion of 1, 0.0228 are likely to above .39L as a number of bottles 
#100*0.0228 = 2.28 answer =  2.28 bottles are expected to contain more than the .39L

#Question 2A

 install.packages("Hmisc")
 install.packages("pastecs")
 install.packages("psych")
 
#Question 2b
#HMISC contains functions for data analysis
#PSYCH contains functions for analyzing data that are used in psychology
#Pastecs contains data for space ecological series 
 
 packageDescription("Hmisc")
 packageDescription("psych")
 packageDescription("pastecs")
 
 #storing salary.rds in salary dataframe
 
 salary <-readRDS("salary.rds")
 
 
 library("Hmisc")
 describe(salary)
 
 #pastecs uses stat.desc
 library("pastecs") 
 stat.desc(salary)
 
 
 library("psych")
 describe(salary)
 
 
 
#Question 2c
 
 library("psych")
 describeBy(salary, salary$gender)
 
#Load iris data set
 
 data(iris)
 
#Question 2d
 
 dat <- iris
 head(dat)
 rng <- range(dat$Petal.Length)
 rng 
 max(dat$Petal.Length)-min(dat$Petal.Length)

#Range =5.9
 
 
 mean(dat$Petal.Length)

 #Mean = 3.758
 
 median(dat$Petal.Length)
#Median = 4.35
 
 quantile(dat$Petal.Length,0.98)

 #98th percentile = 6.602
 #Question 2e
 
 #use ggplot2 package
 
 library (ggplot2)
 head(iris) 
 histogram <- ggplot(data=iris, aes(x=Sepal.Width)) 
 attach (iris) 
 hist(Sepal.Width) 

 #Median as it is less affected by outliers. 
 
 #Question 2f
 data ("HairEyeColor")
 HairEye <- as.data.frame(HairEyeColor)
 names(HairEye)
 
  # table showing HairEyeColor
 y <- apply(HairEyeColor , c(1, 2), sum)
 y 

 mosaicplot(y, main = 'Relationship between Hair Color And Eye Color')
#Mosaic plots are suitable for visualizing multivariate categorical data in R 
 
 #Question 3A
 #Use Random Number generator to generate rainfall for cork and dublin
 #Store in data frames DublinRainFall , CorkRainFall
 #Use matrix to store data for years and dublinrainfall and corkrainfall
 #Store table in Rainfall dataframe
 
 DublinRainFall <- floor(runif(20 ,min = 0, max = 28))
 CorkRainFall <- floor(runif(20,min=0, max=28))
 DublinRainFall
 CorkRainFall
 Rainfall <- matrix(c(DublinRainFall,CorkRainFall),ncol = 2,byrow=TRUE)
 colnames(Rainfall) <- c("Dublin","Cork")
 rownames(Rainfall) <- c('2001','2002','2003','2004','2005','2006','2007','2008','2009','2010','2011','2012','2013','2014','2015','2016','2017','2018','2019','2020')
 Rainfall <- as.table(Rainfall)
 Rainfall
 

 #A scatterplot is good to use in this example because they can observe relationships
 #between the data. the dots show patterns when data is taken as a whole, so we can
 # see the relationship between rain in cork and dublin in the last 20 years. 
 
 
 
 
 plot (DublinRainFall, main='Rainfall',xlab="rainfall", ylab="year", pch=20)
 
 
 
 
 #Question 3B
 World <- read.table('world-small.csv', sep = ',', header = TRUE)
 summary(World)
 attach (World) 
 hist (gdppcap08) 
 boxplot (polityIV) 
 
 #display first 6 rows of dataset
 head (World) 
 rng <- range(World$gdppcap08) 
 rng 
 library(Hmisc) 
 summarize(World$gdppcap08,World$region,max) 
 #highest gdp = Middle East
 summarize(World$country,World$polityIV,min)
 #LOWEST POLITYIV=QATAR 
 
 
 #Question 3c
 #Create data frame called ds with below values
 ggplot()
 df <- data.frame(numberofpeople=c(298,492,785,2034), pet=c("Macaw","cats","fish","dogs"))
 df

 
library(ggplot2)
p <-ggplot(df,aes(pet, numberofpeople)) 
p+geom_bar(stat="identity")


# Why is a pie chart not used : pie charts are poor at communicating data they take 
#up more space and are harder to read than alternatives because there is no scale used.
#They often distort the information and make it more difficult for decision makers
#to understand the info they contain 




