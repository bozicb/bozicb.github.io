# Q1 (a) 
# Weight and height are continuous. 
# Age is discrete.
# Name and profession are categorical. Profession could be discrete if, for example, the dataset only contains professions in a college/school.
# 
# (b)
# Nominal - Name, subject, gender
# Ratio/Interval -  Semester (because you can't have a negative number for a semester)
# Ordinal- Staff number, assuming the numbers can be ordered. Otherwise it would be nominal.
# 
# (c)
# The z-score for this is 2 which means 0.39 is 2 standard deviations from the mean. So there is a 2.5% chance of a bottle having more than 0.39L (because 2 SDs is 95% of the data so 2.5% of the data is expected to be higher than 0.39)
# 2.5% of 100 is 2.5 so we are expecting 2.5 of the bottles to contain more than .39L

# Q2 (a) Installing packages
install.packages('Hmisc')
install.packages('pastecs')
install.packages('psych')

# Q2 (b)
# Read in salary.rds dataset
salary<-readRDS("salary.rds")

# HMisc description of data:
# Instead of giving description in 1 table it describes each variable separately
# There are 7 variables (columns) and 52 observations (rows/instances)
# Gender - no missing values. 2 distinct values (14 female and 38 male). 73% are male
# Rank - no missing values. 3 distinct values (18 Assisstants, 14 Associates and 20 full). 34.6% are assistants. 26.9% are associates and 38.5% are full.
# yr - no missing values. 18 Distinct. Lowest number is 0 and highest is 25. For each value we see the frequency and proportion. The mean is 7.481
# dg - no missing values. 2 distinct values. It shows the sum is 34, the mean is 0.6538 and the gmd is 0.4615
# exper - no missing val. 29 distinct vals. Mean is 16.12 and gmd is 11.85. Lowest value is 1 and highest is 35
# salary - no missing val. 51 distinct vals. mean is 23,798. Gmd is 6,755. Lowest is 15,000 and highest is 38,045
# expcat - no missing val. 7 distinct val. Mean is 3.654 and gmd is 2.327. For each value we see the frequency and proportion. Lowest val is 1 and highest is 7
Hmisc::describe(salary)

# pastecs description of data:
# This gives a table of statistics about the data
# For each variable it lists, the number of values, how many null values, the number of missing values, the min value, the max value, the range, sum (of non missing values),
# median, mean, variance, standard deviation 
pastecs::stat.desc(salary)

# psych description of data:
# This also gives us a table of statistics about the data but with different descriptors 
# Variables with a * beside the name means that they are categorical or logic and were converted to numeric and then described
# For each variable it tells us the count of instances, the mean, standard deviation, median, trimmed mean, mad (median absolute deviation from the median), minimum value, maximum value, range, skew and kurtosis
psych::describe(salary)

# Q2 (c)
# Summary statistics by using grouping by Gender
psych::describeBy(salary, salary$gender)

# Load iris dataset
irisData <- as.data.frame(iris)

# Q2 (d)
# mean, median, range, 98th percentile of petal.length
psych::describe(irisData)
quantile(irisData$Sepal.Length, c(.32, .57, .98))
# mean is 5.84, median is 5.80, range is 3.6 and 98th percentile is 7.7

# Q2 (e)
# Draw the histogram for Septal.Width
hist(irisData$Sepal.Width)
# You can use standard deviation for the measure of dispersion method as the data is not skewed with no outliers

# Q2 (f)
# Load haireyecolor dataset
dataHairEye <- as.data.frame(HairEyeColor)
# Show total number of people with various color combinations of hair and eyes. Which chart suits best for this task? Plot the same.
# I think the bar chart suits this best as it is clear to see the count for each combination and you can also easily compare the counts
counts <- table(dataHairEye$Hair, dataHairEye$Eye)
barplot(counts, main="Hair and Eye Combinations", xlab="Hair", ylab="Count", legend = rownames(counts))

# Q3 (a)
# Store 20 random data points between 0 to 28 for Dublin and Cork in 2 variables
dublinRain <- sample(0:28, 20)
corkRain <- sample(0:28, 20)
# Create line chart with dublin rain data
plot(dublinRain,type = "o",col = "red", xlab = "Year", ylab = "Average Rain fall", main = "Rain fall in Dublin and Cork")
# Add line for cork rain data
lines(corkRain, type = "o", col = "blue")
# I think line chart is most suitable as we can see the trend for each city over the years and we can also see the difference in rain fall between the cities for each year

# Q3 (b)(i)
# Load world-small.csv
worldSmall<-read.csv("world-small.csv")
# Histogram of gdppcap08
hist(worldSmall$gdppcap08, xlab='gdppcap08', main='Histogram of gdppcap08 and frequency')

# Q3 (b)(ii)
#Boxplot for polityIV
boxplot(worldSmall$polityIV, main="Boxplot for polityIV")

# Q3 (b)(iii)
# Show the region that has highest gdpcap.
subset(worldSmall, gdppcap08 == max(gdppcap08))
# Returned row with highest gdppcap08 and region is Middle East

# Q3 (b)(iv)
# Show the country with the lowest polityIV
subset(worldSmall, polityIV == min(polityIV))
# Returned is two rows as two countries have the lowest polityIV - Qatar and Saudi Arabia

# Q3 (c)(i)
# A suitable graph for this is a barchart
#labels = lbls,
pets = c('Dogs', 'Cats', 'Fish', 'Macaw')
noPeople = c(2034, 492, 785, 298)

# Q3 (b)(i)
# I chose a barplot as I think it shows the data the most clearly. If we use a histogram, the macaw count is so low that it is not visible. The margin is too small between the two smallest counts for a pie chart. The barchart shows the data the most simply and clearly
barplot(noPeople, main="Pets in Dublin", names.arg=pets, ylab="Count")

# Q3 (b)(ii)
# EG of pie chart
# I don't think this works well because, for example, there are 200 more cases of people with cats but in the pie chart it looks very similar/the same to the macaw count. So this makes the data quite unclear as these values are not the same
# The data is heavily skewed which doesn't work well for pie charts
pie(noPeople, labels = pets, main="Pie Chart of Pets")
