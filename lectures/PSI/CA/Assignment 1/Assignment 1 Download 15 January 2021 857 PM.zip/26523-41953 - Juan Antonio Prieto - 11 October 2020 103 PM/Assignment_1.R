#1.	Understanding data (3 marks)

#(a)	Assume that you have a table with variables that describe a person. Name, age, height, weight and profession. Identify variables that are discrete, continuous, and categorical. (1 mark)
#Name: Qualitative
#Age: Discrete
#Height: Continuous
#Weight: Continuous
#Profession: Categorical

#(b)	Assume that you have a table with variables that describe a lecturer. Name, gender, subject, semester, and staff number. Identify variables that are ordinal, nominal, interval, and ratio. (1 mark)
#Name: Qualitative
#Gender: Nominal.
#Subject: Ordinal.
#Semester: Interval
#Staff number: Interval

#(c)	You and a friend wonder if it is "normal" that some bottles of your favourite beer contain more beer than others although the volume is stated as 0.33L. You find out from the manufacturer that the volume of beer in a bottle has a mean of 0.33L and a standard deviation of 0.03. If you now measure the beer volume in the next 100 bottles that you drink with your friend, how many of those 100 bottles are expected to contain more than 0.39L given that the information of the manufacturer is correct? (1 mark)
#We should apply the formula:
#  Z Score = (Observed Value - Mean of the Sample)/standard deviation
#Z score = ( x - � ) / ??

#Z Score = (0.39 - 0.33)/ 0.03 = 2
#Taking in consideration the 95%, the 0.05 in Z Score 2 is  .97982
#In our example, we get the intersection at a value of 0. 97982 (~ 097982)
#To get this as a percentage we multiply that number with 100. Therefore 0. 97982 x 100 = 97.98%
#100 - 97.98  = 2.02
#So, values more than 0.39  is expected to occur in 2.02% of cases. 


salary
head(salary)

#2.	Descriptive statistics (6 marks) Use salary.rds dataset from lecture 1.

#(a)	Install the following packages Hmisc, pastecs, psych (1 mark)
install.packages("Hmisc")
install.packages("pastecs")
install.packages("psych")
library(Hmisc)
library(pastecs)
library(psych)

#(b)	Describe the data using installed packages and identify the differences in description by different package. 
packageDescription("Hmisc")
packageDescription("pastecs")
packageDescription("psych")


#(c)	Generate summary statistics by using grouping by Gender
install.packages("psych")
library(psych)
head(salary)
summary(salary)
summary(salary$gender)

#Load iris dataset into workspace.
iris
head(iris)

#(d)	Identify mean, median, range, 98th percentile of Petal.Length (1 mark)
summary(iris)
mean(iris$Petal.Length)
median(iris$Petal.Length)
range(iris$Petal.Length)
quantile(iris$Petal.Length,.98)

#(e)	Draw the histogram for Septal.Width, mention which measure of dispersion method suits the best? (1 mark)
hist(iris$Sepal.Width, breaks = 50, col = "darkgreen", xlab = "x", ylab = "y", prob = T, 
     main = "Histogram for Sepal Width")
var(iris$Sepal.Width, na.rm=TRUE)
sd(iris$Sepal.Width, na.rm=TRUE)
IQR(iris$Sepal.Width, na.rm=TRUE)
  ##The best for measuere of dispersion is the SD due give the same units as the original values.

#Load HairEyeColor
dataHairEye <- as.data.frame(HairEyeColor)
dataHairEye
head(dataHairEye)

#(f)	As a customer, I would like to know the total number of people with various color combinations of hair and eyes. Which chart suits best for this task? Plot the same.
table_color = table(dataHairEye$Hair, dataHairEye$Eye)
table_color

plot(dataHairEye$Hair, dataHairEye$Eye, pch = 20, col = "blue")
abline(0, 1, lty = 3, col = "red")

#3.	Visualisation

#(a)	A meteorologist wants to compare the annual average rain fall between two cities 
#for the past 20 years. Which plot is most suitable? Plot the graph by generating
#20 random data points between 0 to 28 for Dublin and Cork. 


dublin <- c(24, 25, 16, 19, 8, 13, 19, 6, 10, 1, 22, 7, 16, 23, 5, 17, 8, 9, 19, 28)
cork <- c(14, 15, 26, 28, 18, 3, 9, 16, 1, 10, 12, 17, 6, 13, 15, 6, 18, 19, 20, 8)
plot(dublin, cork, pch = 20, col = "blue")
boxplot(dublin)
boxplot(cork)
boxplot(dublin~cork) #(the visualization when I choose the boxplot to be represented both variables
#at the same time (dublin and cork) is not clear enough. I prefer in this case each one
#be represented separately).

### I will go for boxplot because it takes the IQR and the mean.

#(b)	Load the provided world-small.csv file. 
world.small <- read.csv("~/DIT/Prob&Statistics/Assigment 1/world-small.csv", header=TRUE)
View(world.small)
head (world.small)

#i.	Draw histogram for 'gdppcap08'
hist(world.small$gdppcap08, breaks = 50, col = "darkgreen", xlab = "gdppcap08", prob = T, 
     main = "gdppcap08 Histogram")

#ii.	Draw boxplot for 'polityIV'
boxplot(world.small$polityIV, col = "greenyellow")


#iii.	Identify the region that has highest gdpcap.
#The region with high gdpcap is Middle East with Qatar 85868 gdpcap.

#iv.	Which country has lowest polityIV ?
#The region with lowest polityIV is Middle East with Qatar and Saudi Arabia with 0.0.

#(c)	Table 1 represents people in Dublin who like to own certain types of pets. (2 marks)


HM<-matrix(c(2034, 492, 785, 298),ncol=1,byrow=TRUE)
rownames(HM)<-c("Dogs", "Cats", "Fish", "Macaw")
colnames(HM)<-c("Number of people")
HM <- as.table(HM)
HM

# Create the data for the chart

H <- c(2034, 492, 785, 298)
M <- c("Dogs", "Cats", "Fish", "Macaw")
barplot(H,names.arg=M,xlab="Month",ylab="Revenue",col="blue",
        main="Revenue chart",border="red")

#ii.	Is it a good idea to choose a pie chart (in case you have not chosen it in (i))? 
#Why is it a good idea or why is it not a good idea?

#I did not take the piechart because is more easy and visual to understand the results if I 
#select the barplot for this example.

pie(H,labels=as.character(M))
