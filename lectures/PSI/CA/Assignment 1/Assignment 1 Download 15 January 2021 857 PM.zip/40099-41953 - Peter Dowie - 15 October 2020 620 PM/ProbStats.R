#load libraries
#install.packages("Hmisc")
#install.packages("pastecs")
#install.packages("psych")
rm(list = ls())

library(Hmisc)
library(pastecs)
library(psych)

#{r setup, include=TRUE}
#knitr::opts_chunk$set(echo = TRUE)
#Assume that you have a table with variables that describe a person.  Name, age,height, weight and profession.  Identify variables that are discrete, continuous, andcategorical.  (1 mark)
#Create dataframe
Name <- c("Raquel")
Height <- c(5.2)
Weight <- c(8.2)
Age <- c(33)
Profession <- c("Geneticist")
df <- data.frame(Name, Height, Weight, Age, Profession, stringsAsFactors =  T)
df

#Class
class(df$Name)
class(df$Height)
class(df$Weight)
class(df$Age)
class(df$Profession)

#Type
typeof(df$Name) #Categorical
typeof(df$Height)#Continuous
typeof(df$Weight)#Continuous
typeof(df$Age)#Discrete
typeof(df$Profession) #Categorical

#Summary
dfsum<- summary(df)


#Variables 
categorical <- c(Name, Profession)
categorical$'Description' = "Two or more categories with no intrinsic order"

discrete <- c(Age)
discrete$'Description' = "Finite counteable quantity"

continuous <- c(Height, Weight)
continuous$'Description' <- c("Unlimited between the lowest and highest points of measurement")


#######################################################################
#Assume  that you  have a  table with  variables  that  describe  a lecturer.   Name,gender, subject, semester, and staff number.  Identify variables that are ordinal,nominal, interval, and ratio.  (1 mark)
lname <- "Bojan"
lgender <- "Male"
lsubject <- "Prob and Statistical Inference"
lsemester <- "first"
lstaff_number <- 10004546

ldf <- data.frame(lname, lgender, lsubject, lsemester, lstaff_number)

#Class
class(ldf$lname) 
class(ldf$lgender)
class(ldf$lsubject)
class(ldf$lsemester)
class(ldf$lstaff_number)

#Type
typeof(ldf$lname) #nominal
typeof(df$lgender) #nominal
typeof(df$lsubject) #nominal
typeof(df$lsemester) #ordinal, interval
typeof(df$lstaff_number) #ratio, interval

#Summary
dfsum<- summary(ldf)

ordinal <- c(lsemester)
ordinal$'Description' <- "Two or more categories with an intrinsic order"
nominal <- c(lgender,lsubject,lname)
nominal$'Description' <- "Two or more categories with no intrinsic order"
interval <- c(lsemester,lstaff_number)
interval$'Description' <- "Values on a scale of equally measured distanced"
ratio <- lstaff_number
ratio$'Description' <- "Values on a scale of equally measured distanced with a zero value"


#########################################################
mean.v <- .33
std.v <- .03
#Therefore 3.9 represents 2 deviations from the mean (.33 + (2*.03))
#This will represent 2.3% of cases.
#Since the sample size is 100 bottles we can expect 100*2.3% bottles in this group
answer <- 100*.023


#########################################################
#Install the following packagesHmisc, pastecs, psych(1 mark)
#ínstall packages
install.packages("Hmisc")
install.packages("pastecs")
install.packages("psych")
library(Hmisc)
library(pastecs)
library(psych)


#load dataset
#Initial summary with base
f <- readRDS("~/Downloads/salary.rds")
sum <- summary(f)
sum_by_rank <- by(f, f$rank, summary)
sum_by_gender <- by(f, f$gender, summary)

#Describe the data using installed packages and identify the differences in description by different package.  (1 mark)
#Summarise with Hmisc
#Error loading Hmisc from library. If it had worked I would have used the describe function
Hmsic_error <- "Error: package or namespace load failed for ‘Hmisc’ in dyn.load(file, DLLpath = DLLpath, ...):
  unable to load shared object '/Library/Frameworks/R.framework/Versions/4.0/Resources/library/png/libs/png.so':
  dlopen(/Library/Frameworks/R.framework/Versions/4.0/Resources/library/png/libs/png.so, 6): Symbol not found: _inflateValidate
Referenced from: /Library/Frameworks/R.framework/Versions/4.0/Resources/library/png/libs/png.so (which was built for Mac OS X 10.13)
Expected in: /usr/lib/libz.1.dylib
in /Library/Frameworks/R.framework/Versions/4.0/Resources/library/png/libs/png.so"
Hmisc::describe(f)

#Summarise with pastecs
desc <- pastecs::stat.desc(f) #basic description
scores <- cbind(f$yr,f$dg,f$exper,f$salary,f$expcat)
scores <- stat.desc(scores)
basic_scores <- stat.desc(scores, basic = T)
desc_scores <- stat.desc(scores, desc = T)
scores_comp <- stat.desc(scores, basic=TRUE, desc=TRUE, norm=TRUE, p=0.95)

#Summarise with psch
ps_desc <- describe(f) #basic description
yr_desc <- describeBy(f, group = f$yr)
expcat_desc <- describeBy(f, group = f$expcat)
dg_desc <- describeBy(f, group = f$dg)
sal_desc <- describeBy(f, group = f$salary)
lc <- lowerCor(scores)


#Generate summary statistics by using grouping by Gender.  (1 mark)
gender_desc <- describeBy(f, group = f$gender)

#ídentify mean, median, range, 98th percentile of Petal.Length (1 mark)
dfi <- data("iris")
dat <- iris
pl <- stat.desc(dat$Petal.Length)
print(pl) #mean, median and range
pl98 <- quantile(dat$Sepal.Length, 0.98) #98th percentile

#Draw  the  histogram  for  Septal.Width,  mention  which  measure  of  dispersion method suits the best?  (1 mark)
hist(dat$Sepal.Width)
#Based on the plot I think that standard deviation is the most suitable measure of dispersion for this dataset.
#It has a normal distribution that matches the idealised bell curve shap.

#LoadHairEyeColordataset into workspace
hedf <- as.data.frame(HairEyeColor)
install.packages("ggplot2")
library(ggplot2)
#As a customer, I would like to know the total number of people with various colorcombinations of hair and eyes.  Which chart suits best for this task?  Plot the same.(1 mark)
plot(hedf)
hedf$ID <- paste(hedf$Hair, hedf$Eye, hedf$Sex, sep="")
hedf$Freq <- factor(hedf$Freq, levels = hedf$Freq)


data <- data.frame(num =y, cat = x)    
ggplot(data,aes(x= reorder(cat,-num),num))+geom_bar(stat ="identity")


data <- data.frame(hedf$ID, hedf$Freq)
mat <- as.matrix(data)

                 
ggplot(data,aes(x= reorder(hedf$ID,hedf$Freq),hedf$Freq))+ geom_bar(stat="identity", aes(fill=hedf$ID), width=.5)#Ordered 
ggplot(hedf, aes(x=Freq , y=ID, label=ID)) + geom_bar(stat="identity", aes(fill=ID), width=.5, las =1) #legible

#A meteorologist wants to compare the annual average rain fall between two citiesfor the past 20 years.  Which plot is most suitable?  Plot the graph by generating20 random data points between 0 to 28 for Dublin and Cork.  (2 marks)
County <- c("Dublin","Dublin","Dublin","Dublin","Dublin","Dublin","Dublin","Dublin","Dublin","Dublin","Cork","Cork","Cork","Cork","Cork","Cork","Cork","Cork","Cork","Cork")
County <- as.data.frame(County) 
County$rain <- sample(28, size = nrow(County), replace = TRUE)
av_rain <- aggregate(County[,2], list(County$County), mean)
av_rain <- col
ggplot(av_rain,aes(x= reorder(av_rain$Group.1,av_rain$x),av_rain$x))+ geom_bar(stat="identity", aes(fill=av_rain$Group.1), width=.5)#Ordered 


#Load the provided world-small.csv file.  (2 marks)
world.small <- read.csv("~/Downloads/world-small.csv")
#i.  Draw histogram for ‘gdppcap08’ii.  
hist(world.small$gdppcap08)
#Draw boxplot for ‘polityIV’iii.  
boxplot(world.small$polityIV)

#Identify the region that has highest gdpcap.iv.  
ws <- aggregate(world.small$gdppcap08 ~ world.small$region, data = world.small, max)#Both methods correct Answer is Middle East
#tapply(world.small$gdppcap08 , world.small$region, max)#
#ws <- sort(ws$`world.small$gdppcap08`, decreasing = T)
ggplot(ws,aes(x= reorder(ws$`world.small$region`,ws$`world.small$gdppcap08`),ws$`world.small$gdppcap08`))+ geom_bar(stat="identity", aes(fill=ws$`world.small$region`), width=.5)#Ordered 

#Which country has lowest polityIV ?
ws2 <- aggregate(world.small$polityIV ~ world.small$region, data = world.small, min)#Both methods correct Answer is Middle East
#ws2 <- tapply(world.small$polityIV, world.small$region, min)#
ws2 <- as.data.frame(ws2)
colnames(ws2) <- c("Region", "polityIV")
#ws <- sort(ws$`world.small$gdppcap08`, decreasing = T)
ggplot(ws2,aes(x= reorder(ws2$Region, ws2$polityIV),ws2$polityIV))+ geom_bar(stat="identity", aes(fill=ws2$Region), width=.5)#Ordered 
