#1. Understanding data (3 marks)
#(a) Assume that you have a table with variables that describe a person. Name, age,
#height, weight and profession. Identify variables that are discrete, continuous, and
#categorical. (1 mark)

# ANSWER 1.a) Name - Categorical, Age - Continous, Height - Continous, Weight - Continous, Profession - Categorical


#(b) Assume that you have a table with variables that describe a lecturer. Name,
#gender, subject, semester, and staff number. Identify variables that are ordinal,
#nominal, interval, and ratio. (1 mark)

#ANSWER 1.b) Name - Nominal, Gender - Nominal, Subject - Nominal, Semester - Ordinal, Staff Number - Nominal 


#(c) You and a friend wonder if it is ”normal” that some bottles of your favourite
#beer contain more beer than others although the volume is stated as 0.33L. You
#find out from the manufacturer that the volume of beer in a bottle has a mean
#of 0.33L and a standard deviation of 0.03. If you now measure the beer volume
#in the next 100 bottles that you drink with your friend, how many of those 100
#bottles are expected to contain more than 0.39L given that the information of the
#manufacturer is correct? 

# ANSWER 1.c) Assuming a normal distribution 95% of the bottles would fall within 2 Standarad Deviations of the mean(0.27 and 0.39).
#That leaves 5% outside of it and 2.5% above 0.39. So 2 or 3 bottles would be above 0.39L. 

#question 2
#2.a)
install.packages('Hmisc')
install.packages('pastecs') 
install.packages('psych')

library(Hmisc)
library(pastecs)
library(psych)

dat <-readRDS('salary.rds')

#2.b)ANSWER

psych::describe(dat)
#Good for both quantitive and qualatiative stats. 
# Provides high level descriptive stats - N, Mean, Standard Dev., Median, Rang etc as well as an insight into how
# the shape of the data(skew, kurto)

Hmisc::describe(dat)
#Useful for both numerica and categorical variables
#Also provides useful stats like the range, distinct, proporation of each cat. variabl
pastecs::stat.desc(dat)
#pastecs is more suited for quantitive statistic

pastecs::stat.desc(dat)
#pastecs is more quited for numeric statistic

#2.c ANSWER

describeGen <- psych::describeBy(x = dat, group = dat$gender)
print(describeGen)

#2.d ANSWER
data("iris")

#mean
meaniris <- mean(iris$Petal.Length)
print(meaniris)
#median
mediris <- median(iris$Petal.Length)
print(mediris)
#range
raniris <- range(iris$Petal.Length)
print(raniris)
#98th percentile
perpetal = iris$Petal.Length     
quantile(perpetal, c(.98)) 


#2.e ANSWER

install.packages('ggplot2')
install.packages('ggthemes') 

library(ggplot2)
library(ggthemes)


hist(iris$Sepal.Width, main = 'Sepal Width', xlab = "Sepal Width cm", breaks = 10)

#2.f

data("HairEyeColor")
dataHairEye <-as.data.frame(HairEyeColor)
print(dataHairEye)


#3a ANSWER

Dubtemp <- sample(x = 0:28, size  = 20)
Corktemp <- sample(x = 0:28, size  = 20)


#3b

#i
df <- read_csv("world-small.csv")
hist(df$gdppcap08,main = 'GDP Per Capita', xlab = 'GDP', breaks = 20)


#ii
# Boxplot of Polity IV
boxplot(df$polityIV, main = 'Boxplot of Polity IV')

install.packages('dplyr')
library(dplyr)



filter(df, gdppcap08 >= 7000)


# 3c 

pets<-matrix(c(2034,492,785,298),ncol=1,nrow=4)
rownames(pets)<-c( "Dog", 'Cat', 'Fish', 'Macaw')
colnames(pets)<-c('Number of People')
pets <- as.table(pets)
pets

hist(pets, breaks = 4)

#Ran out of trying to get this done, trying to get this to become a Bar Chart

#Depends on the question being asked, but Pie chart are better used for showing how data points as a proportion of other ones.
#Also considering a Macaw is a type of Bird not sure if it makes sense to show proportion comparing to other animals
#And finally certain people may own multiple animals which means they appear double counted in a Pie Chart
