
# Q1(a) Assume that you have a table with variables that describe a person. Name, age, height, weight and profession. 
#Identify variables that are discrete, continuous, and categorical. (1 mark) 
#Discrete = age (age can be a continuous variable, but when recording age in a table like this scenario, typical to  use discrete value eg give age in years rather than mili-seconds)
#Continuous= height, weight
#Categorical = profession, name,



## Q1(b) Assume that you have a table with variables that describe a lecturer: 
##Name, gender, subject, semester, and staff number. Identify variables that are ordinal, nominal, interval, and ratio. (1 mark) 
## Answer: 
##Ordinal: 
##Nominal:  name, gender, semester, subject, staff number
##Interval:
##Ratio:

###Q1(c)You and a friend wonder if it is normal that some bottles of your favourite beer contain more beer than others although
###the volume is stated as 0.33L. You find out from the manufacturer that the volume of beer in a bottle has a mean 
###of 0.33L and a standard deviation of 0.03. If you now measure the beer volume in the next 100 bottles that you
### drink with your friend, how many of those 100 bottles are expected to contain more than 0.39L given that 
###the information of the manufacturer is correct? (1 mark)
### Answer Q1 (c) 0.39l is 0.06l greater than the mean, which is equal to 2 standard deviations or 2??. We would 
### expect therefore that 95% of all bottles would contain between 0.27 (0.33 - 0.06) and 0.39 (0.33 + 0.06). 
### 5 % will contain more than 2 ?? , which means 2.5% will contain more than 0.39l... 
### on assumption manufacturer's info is correct, 2.5% will be 2.5 bottles of the 100, 
## so we expect 2.5 bottles (so 2 or 3 bottles) of the next 100 bottles to contain more than 0.39l, and 5 of the next 200 bottles.




## Q2 a  

## load salary.rds dataset

salary <-readRDS("salary.rds")

## Perform descriptive stats on this dataset using various packages


## install packages required
install.packages("Hmisc")
install.packages("pastecs")
install.packages("psych")


## first try Hmisc
# attach/load Hmisc
library(Hmisc)


## use describe function in Hmisc on variable year

describe(salary$year)

## output is NULL

## try with variable gender

describe(salary$gender)
## output is given here.
## take-away that Hmisc works with categorical variables, not year which is an interval variable

##detach Hmisc

## ii.now try pastecs

library(pastecs)

## try describe for gender
stat.desc(salary$gender)
## output is only "NAs" which indicates package does not work with categorical variables

## try describe for salary
stat.desc(salary$salary)

## we want to reduce output to 2 decimal places  and run again
options(digits = 2)
stat.desc(salary$salary)
## descriptive inidcators for this package include number of cases (nbr val), number of null values, also some dispersion measures such as minimum, maximum and range.

### iii. now try psych

# detach pastecs

## load psych
library(psych)

## describe on variable gender
describe(salary$gender)
## output error essage: Argument is not numeric or logical so returning NA

## describe for variable salary

describe(salary$salary)
##output here with numeric variable salary is interesitng. we get extra descriptive detail on Central tendency measures such as a trimmed mean. We also get extra 
## dispersion measures such as skew & kurtosis &  range. 


### c. Generate summary statistics by using grouping by Gender
### use psych again for this
describeBy(salary$salary,salary$gender)
## output gives desired detail


#### d. Identify mean, median, range, 98th percentile of Petal.Length

## Load iris dataset 

library(datasets)
data(iris)


#### d. Identify mean, median, range, 98th percentile of Petal.Length
##using pastecs will give us answer for most of these.
## detach psych, 


###load pastecs

library(pastecs)

##summary descriptive detail
summary(iris$Petal.Length)

options(scipen=100) 
stat.desc(iris$Petal.Length)

## provided us with all required info except for 98th percentile
## use quantile(variable, c(.98))

quantile(iris$Petal.Length, c(.98))


##### e. Draw the histogram for Septal.Width, mention which measure of dispersion method suits the best
## detach psych

hist(iris$Sepal.Width)
### output is almost perfect bellcurve, so standard deviation is the most apt measure of dispersion here



###### f) As a customer, I would like to know the total number of people with various color combinations
##### of hair and eyes. Which chart suits best for this task? Plot the same.

#### answer UNSURE atm

#from library datasets
library("datasets")
dataHairEye <- as.data.frame(HairEyeColor)




### Q3 
# a A meteorologist wants to compare the annual average rain fall between two cities for the past 20 years. 
# Which plot is most suitable? Plot the graph by generating 20 random data points between 0 to 28 for Dublin and Cork. (2 marks)

## most suitable plot would be a group bar chart: Time on x axis and 2 bars per each time interval, one for each  county. 
## Average rainfall would be on the y-axis
## don't know how to produce this


## b.Load provided world-small csv

world_small <- read.csv("world-small.csv", header=TRUE, sep=",")

#Draw histogram for `gdppcap08'. Cleaned up labels for better visuals.

hist(world_small$gdppcap08, xlab="GDP per Capita 2008", main = "Distribution of GDP per Capita 2008")

## Draw boxplot for `polityIV'. Gave it a better header.

boxplot(world_small$polityIV,main="PolityIV")

### Identify the region that has highest gdpca?
### In table, sorting by GDPCap returns Middle East region as the highest

#### Which country has lowest polityIV ?
#### Similarly sorting the dataset by PolityIV retuns Qatar as the lowest in this measure.



### c.i. Plot the most suitable graph for the given dataset.
### a good candidate for most suitable is the bar chart
### import as csv file saved in working directory
pet_lovers <- read.csv("pet_lovers.csv", header=TRUE, sep=",")

##ggplot
library("ggplot2")

## produce barchart
pet_loverBar <- ggplot(pet_lovers, aes(Pet, Number.of.people)) + geom_bar(stat="Identity")
pet_loverBar + coord_flip()
## this produces a horizontal barchart


### ii. pie chart suitability?
### problem with pie chart is can be difficult due to the angulation design to decipher accurately the values.
####The brain's not very good at comparing the size of angles and with no scale, reading accurate values is difficult. 
#### Here being able to accuratley deduce the difference between the values for Cats, Fish & Macaw won't be easy

