########### 1. Undersanding Data ##########
#(a)Name: Nominal
# Discrete: age, 
# Continous: height, weight
# Categorical: profession, name

#(b)
# Ordinal: semester
# Nominal: gender, subject, name, Student ID
# Interval:
# Ratio: 

#(c)  95% percent within two standard deviations - 2.5% 

###############2. Descriptive statistics##############
df <- readRDS("C:/Users/kfitzpa4/Downloads/salary (2).rds") #Load Data

head(df)

library(Hmisc)
describe(df)

library(pastecs) #loadpastecs
stat.desc(df)

library(psych) #load pysch to summarize stats by group
describe(df)

#(c) Generate summary statistics by using grouping by Gender. (1 mark) Hint: use package psych

library(psych)
describeBy(df, group = df$gender)

# Iris#

library(datasets)
data(iris)
summary(iris)

#(d)Identify mean, median, range, 98th percentile of Petal.Length
mean(iris$Petal.Length)
median(iris$Petal.Length)
range(iris$Petal.Length)
quantile(iris$Petal.Length, 0.98)

#(e) Draw the histogram for Septal.Width, mention which measure of dispersion method suits the best?
hist(iris$Sepal.Width) #Std best

#Load HairEyeColor dataset into workspace.

library(datasets)
data(HairEyeColor)
dataHairEye <- as.data.frame(HairEyeColor)
view(dataHairEye)


#As a customer, I would like to know the total number of people with various color 
#combinations of hair and eyes. Which chart suits best for this task? Plot the same.

library(reshape)
mix <- melt(HairEyeColor)
mix <- within(mix, {
  color <- tolower(Hair)
  color <- ifelse(color == 'blond', 'yellow', color)
  color1 <- tolower(Eye)
  color1 <- ifelse(color1 == 'hazel', 'brown', color1)
  value <- value / 2
  value1 <- value
})

mix <- melt(mix, id.vars = -(4:5))
cols <- c(apply(mix[1:16, c('color','color1')], 1, c))

library(ggplot2)
ggplot(data = mix, aes(x = interaction(Hair, Eye), y = value, fill = interaction(variable, interaction(Hair, Eye)))) +
  geom_bar(stat = 'identity') + facet_grid(Sex ~ .) + 
  theme(legend.position = 'none') + 
  scale_fill_manual(values = cols)

############### 3. Visualisation #############

#(a) A meteorologist wants to compare the annual average rain fall between two cities for the past 20 years. 
#Which plot is most suitable? Plot the graph by generating 20 random data points between 0 to 28 for Dublin and Cork.

Date <- seq(2000, 2019)
Dublin <- runif(20, 0, 28)
CORK <- runif(20, 0, 28)
library(tidyverse)
df <- tibble(Date, Dublin, CORK)
df

plot(df$Dublin, type = "o", col = "blue")
lines(df$CORK, type = "o", col = "red")
  

#(b) Load the provided world-small.csv le. (2 marks)
#i. Draw histogram for `gdppcap08'
#ii. Draw boxplot for `polityIV'
#iii. Identify the region that has highest gdpcap.
#iv. Which country has lowest polityIV ?

library(readr)
world_small <- read_csv("Kieran/TUD/Stats/world-small.csv")

hist(world_small$gdppcap08)

world_small %>%
  select(polityIV) %>%
  boxplot()

head(world_small)

with(world_small, world_small$region[which.max(world_small$gdppcap08)])


with(world_small, world_small$country[which.max(world_small$polityIV)])

#(c) Table 1 represents people in Dublin who like to own certain types of pets. 
#i. Plot the most suitable graph for the given dataset.
#ii. Is it a good idea to choose a pie chart (in case you have not chosen it in (i))?
  #Why is it a good idea or why is it not a good idea?

Pet <- c("Dogs", "Cats", "Fish", "Macaw")
No.People <-c(2034, 492, 785, 298)

PetData <- data.frame(Pet, No.People)

pie(No.People, Pet) #Clear way of seeing how the different pets are broken up in terms of number of owners. 
