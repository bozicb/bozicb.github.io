#D20125690@mytudublin.ie
#D20125690
#Darragh Goslin

#1. Understanding data (3 marks)
#(a) Assume that you have a table with variables that describe a person. Name, age,
#height, weight and profession. Identify variables that are discrete, continuous, and
#categorical. (1 mark)

print('Name- categorical
Age- continous
Height-continous
Weight-contious
Profession,nominal/categorical')


#(b) Assume that you have a table with variables that describe a lecturer. Name,
#gender, subject, semester, and staff number. Identify variables that are ordinal,
#nominal, interval, and ratio. (1 mark)

print('-name - nominal
-gender - nominal
-subject - nominal
-semester - interval
-staff number - ratio because a newer staff number might infer length of service')




#(c) You and a friend wonder if it is "normal" that some bottles of your favourite
#beer contain more beer than others although the volume is stated as 0.33L. You
#nd out from the manufacturer that the volume of beer in a bottle has a mean
#of 0.33L and a standard deviation of 0.03. If you now measure the beer volume
#in the next 100 bottles that you drink with your friend, how many of those 100
#bottles are expected to contain more than 0.39L given that the information of the
#manufacturer is correct? (1 mark)

print( '-empirical rule 99.7 fall within 3q deviation of the mean
 - 0.33 - 0.09 = 0.24 mean -3sd  and mean + 3sd = .33 + .09 = 0.42
 0.39l is within 0.24 and 0.42
 - Answer : less than 0.3 of 100 bottles will have more than .39ml.
 Rounding down to 0')


#2. Descriptive statistics (6 marks)
#Use salary.rds dataset from lecture 1.

salary<-readRDS("salary.rds")

#(a) Install the following packages Hmisc, pastecs, psych (1 mark)

library('Hmisc')
library('pastecs')
library('psych')


#(b) Describe the data using installed packages and identify the differences in description
#by different package. (1 mark)

Hmisc::describe(salary)
print('provides the count of variables and observations ordered by groups rather than variables')

stat.desc(salary)
print('Only shows numeric data')

psych::describe(salary)
print('shows alot of summary statistics eg mean, range etc . can also summarise by group')



#(c) Generate summary statistics by using grouping by Gender. (1 mark) Hint: use
#package psych

psych::describeBy(salary,salary$gender)

#Load iris dataset into workspace.
library(datasets)
data(iris)

#(d) Identify mean, median, range, 98th percentile of Petal.Length (1 mark)

mean(iris$Petal.Length)

median(iris$Petal.Length)

range(iris$Petal.Length)

quantile(iris$Petal.Length,.98)


#(e) Draw the histogram for Septal.Width, mention which measure of dispersion
#method suits the best? (1 mark)
#Mean or Standard Deviation would be the best measure of dispersion based on the shape of the curve

hist(iris$Sepal.Width,xlim = c(2, 4.5), col = "red", xlab = "Sepal Width (cm)", 
     main = "Sepal Width")


#Load HairEyeColor dataset into workspace.
dataHairEye <- as.data.frame(HairEyeColor)
Hmisc::describe(dataHairEye)


#Hint: dataHairEye < 􀀀 as.data.frame(HairEyeColor)


#(f) As a customer, I would like to know the total number of people with various color
#combinations of hair and eyes. Which chart suits best for this task? Plot the same.
#(1 mark)

library(ggplot2)

qplot(data = dataHairEye,y = Freq)+ labs(x = "Combinations of Hair/Eyes", y = "Frequency of combination")+ theme_bw(base_size=13)  + geom_point(aes(colour = Freq),shape = 19) + ggtitle ("Hair Eye Combo")


#3. Visualisation (6 marks)
#(a) A meteorologist wants to compare the annual average rain fall between two cities
#for the past 20 years. Which plot is most suitable? Plot the graph by generating
#20 random data points between 0 to 28 for Dublin and Cork. (2 marks)

county <- c('dublin','cork','dublin','cork','dublin','cork','dublin','cork','dublin','cork','dublin','cork','dublin','cork','dublin','cork','dublin','cork','dublin','cork','dublin')
county

rainfall <- c(runif(21, min=1, max=28))
rainfall

year <- c(seq(2000, 2020))
year

df <- data.frame(county, rainfall, year)
df

rainData <- ggplot(df, aes(year))
rainData + geom_density() + labs(x = "Year", y = "rain")

rainData + geom_density(aes(fill = county), alpha = 0.5) + labs(x = "Years", y = "Rainfall")




#(b) Load the provided world-small.csv file. (2 marks)

worldData <- read.csv('world-small.csv',sep = ',',header = TRUE)

#i. Draw histogram for `gdppcap08'
hist(worldData$gdppcap08, main="GDP per capita 2008",
     xlab="GDP per capita",
     col="chocolate",
     border="brown", )

library(ggplot2)
library(reshape)
library(plyr)
library (Hmisc)

#ii. Draw boxplot for `polityIV'

wdBoxplot <- ggplot(worldData, aes(polityIV))
wdBoxplot + geom_boxplot() + labs(y = "polityIV",x = 'gdppcap08')

#iii. Identify the region that has highest gdpcap.

qplot(data = worldData,x= gdppcap08,y = region, binwidth=0.2)

highGDP <- worldData$region[worldData$gdppcap08 == max(worldData$gdppcap08)]
print(highGDP)

#iv. Which country has lowest polityIV ?


lowPol <- worldData$country[worldData$polityIV == min(worldData$polityIV)]
print(lowPol)

# (c) Table 1 represents people in Dublin who like to own certain types of pets. (2marks)

#i. Plot the most suitable graph for the given dataset.

slices <- c(2034, 492, 785, 298)
lbls <- c("Dogs", "Cats", "Fish", "Macaw")
pct <- round(slices/sum(slices)*100)
lbls <- paste(lbls, pct) # add percents to labels
lbls <- paste(lbls,"%",sep="") # ad % to labels
pie(slices,labels = lbls, col=rainbow(length(lbls)),
    main="People in Dublin Pets")

#ii. Is it a good idea to choose a pie chart (in case you have not chosen it in (i))?
# Why is it a good idea or why is it not a good idea?

print('Good for nominal data,easy for non data people to read')
