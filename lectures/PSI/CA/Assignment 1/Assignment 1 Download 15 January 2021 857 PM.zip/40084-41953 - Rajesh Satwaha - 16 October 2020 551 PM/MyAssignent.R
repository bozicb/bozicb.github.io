# ==================================================================================== ##
# Assigment -1 - MATH 9102 - Probability and Statistical Inference
# From Rajesh Satwaha - Student number D201125671 , Email:D201125671@mytudublin.ie
## =================================================================================== ##

#Q1 Understanding data
#Q1 (a) Assume that you have a table with variables that describe a person. Name, age, height, weight and 
#        profession. Identify variables that are discrete, continuous, and categorical.

#Answer - Q1 (a)
#   Variable that are Discrete --> Age
#   Variable that are Continuous --> Height and Weight
#   Variable that are Categorical --> Name and profession
#


#Q1 (b) Assume that you have a table with variables that describe a lecturer. 
#       Name, gender, subject, semester, and staff number. 
#       Identify variables that are ordinal,nominal, interval, and ratio.

#Answer Q1 (b)
#       Variable that are ordinal --> staff number
#       Variable that are nominal --> gender and name 
#       Variable that are interval --> semester
#       Variable that are ratio   --> subject

#Q1 (c) You and a friend wonder if it is "normal" that some bottles of your favorite 
#       beer contain more beer than others although the volume is stated as 0.33L. 
#       You find out from the manufacturer that the volume of beer in a bottle has a mean
#       of 0.33L and a standard deviation of 0.03. If you now measure the beer volume
#       in the next 100 bottles that you drink with your friend, how many of those 100
#       bottles are expected to contain more than 0.39L given that the information of the
#       manufacturer is correct?
  

# Answer Q1 (c) Map to standard normal by Calculating the z score     

          Z <- (0.39-0.33)/0.03
          Z

#Q2 --> Use salary.rds dataset from lecture 1
        salary<-readRDS("salary.rds")
        names(salary)


# Q2 (a) Install the Packages - Hmisc, pastecs, psych
# Q2 (b) Describe the data using installed packages and identify the differences in description by different package.
# Answer
      library(Hmisc)
      describe(salary)
      
      library(pastecs)
      describe(salary)
      
      library(psych)
      describe(salary)

#Q2 (c) Generate summary statistics by using grouping by Gender.
# Answer
      library(psych)
      summary(salary$gender)

#Q2 (d) Load iris data set into work space.
# Answer
      
#      install.packages('iris')
#      library(iris)

#       Identify mean, median, range, 98th percentile of Petal.Length
        #Mean
        mean(iris$Petal.Length)

        #Median
        median(iris$Petal.Length)
        
        #Range
        range(iris$Petal.Length)

#Q2 (e) Draw the histogram for Septal.Width, mention which measure of dispersion method suits the best?

#Answer
        library(ggplot2)
        #Create the histogram 
        septalWidth <- iris
        septalWidthHist <- ggplot(septalWidth, aes(Sepal.Width)) + theme(legend.position="none")
        septalWidthHist + geom_histogram(binwidth = 0.4) + labs(x = "Sepal.Width", y = "Frequency")
#       septalWidthHist
        
#Q2 (f)Load HairEyeColor dataset into workspace.
        dataHairEye <- as.data.frame(HairEyeColor)

#Q2 (f) As a customer, I would like to know the total number of people with various color
#combinations of hair and eyes. Which chart suits best for this task? Plot the same.

#Answer
    # creating a basic bar chart for all sex (i.e. Male & Female in different colour) for both Hair & Eye for their frequency
    mybarplot <- ggplot(dataHairEye, aes(Hair,Eye, fill = Sex ))    
    mybarplot + stat_summary(fun.y = mean, geom = "bar", position="dodge") + labs(x="Hair") + labs(y="Eye") + scale_fill_manual("Sex", values=c("Female" = "#008000", "Male" = "#0000FF"))
#    mybarplot


#Q3 (a) A meteorologist wants to compare the annual average rain fall between two cities
#       for the past 20 years. Which plot is most suitable? Plot the graph by generating
#       20 random data points between 0 to 28 for Dublin and Cork.

#Answer
#   Generate 20 random data for two variable Dublin and Cork between 0 to 28      
      # Create two vectors for datas
      Dublin <- c(runif(20, min=0, max=28))
      Cork <- c(runif(20, min=0, max=28))
      Yr <- c(1:20)
  
  # Create a dataframe for all three vectors
    
      avgRainfall <- data.frame(Dublin, Cork,Yr)
                                      
#    plot them on a graph to show the average rainfall between two cities
      
      plot(Dublin,Cork,col="red",pch=19)

#    plot them on a bar graph to show the yearwise rainfall between two cities
      
      myrainplot <- ggplot(avgRainfall, aes(Dublin,Cork, fill = Yr )) 
      myrainplot + stat_summary(fun.y = mean, geom = "bar", position="dodge") + labs(x="Dublin") + labs(y="Cork")
  
      
  # ============ My another way of Rain fall =================    
      years <- c(2000:2020)
      cities <- c("Dublin", "Cork")
      rainfall <- matrix(runif(40, 0, 28),ncol=2,byrow=TRUE)
      colnames(rainfall) <- cities
      rownames(rainfall) <- years
      df <- as.data.frame(rainfall)
      df
      myrainplot <- ggplot(df, aes(years,cities)) +geom_bar(stat = "identity")
      myrainplot
      
  # ==========================================================    
      
#Q3 (b) Load the provided world-small.csv fileany

#Answer
    # define the file name
    filename <- 'world-small.csv'
    # load using read.csv  
    worldsmall <- read.csv(filename)
    # list top 6 to corss check loading of csv
    head(worldsmall)
    
    
#Q3 (b) i. Draw histogram for `gdppcap08'

#Answer
    library(ggplot2)
    #Creating the histogram 
    worldSmallHist <- ggplot(worldsmall, aes(gdppcap08)) + theme(legend.position="none")
    worldSmallHist + geom_histogram(binwidth=9000) + labs(x = "gdppcap08", y = "Frequency") 

    
#Q3 (b) ii. Draw boxplot for `polityIV'

#Answer
# Drawing a boxplot    
    worldSmallBoxplot <- ggplot(worldsmall, aes(polityIV))
    worldSmallBoxplot + geom_boxplot() + labs(x = "polityIV")

# Drawing a boxplot again of polityIV by region    
    worldSmallBoxplot <- ggplot(worldsmall, aes(polityIV, region))
    worldSmallBoxplot + geom_boxplot() + labs(x = "polityIV",y="region")
    

#Q3 (b) iii. Identify the region that has highest gdpcap.

#Answer
     
    worldsmallCountry <- read.csv('world-small.csv')
#    max(worldsmallCountry$gdppcap08, na.rm = TRUE)
    # get the vector position for max value of gdpcap using whichmax() and then diplay the region
    worldsmallCountry$region[which.max(worldsmallCountry$gdppcap08)]
    
# plotted the gdpcap for each region in box plot
    # as per box plot it shows Middle East region has highest gdpcap
    worldSmallBoxplot1 <- ggplot(worldsmall, aes(gdppcap08, region))
    worldSmallBoxplot1 + geom_boxplot() + labs(x = "gdpcap",y="region")

#Q3 (b) iv. Which country has lowest polityIV ?

    worldsmallCountry <- read.csv('world-small.csv')
    #    min(worldsmallCountry$polityIV, na.rm = TRUE)
    # get the vector position for max value of gdpcap using whichmin() and then diplay the country
    worldsmallCountry$country[which.min(worldsmallCountry$polityIV)]
    

#Q3 (c) Table 1 represents people in Dublin who like to own certain types of pets.
#          Table 1: Pet Lovers
#          Pet    Number of people
#          Dogs     2034
#          Cats     492
#          Fish     785
#          Macaw    298


      
#Q3 (c) i. Plot the most suitable graph for the given dataset.

#Answer
      # load the data from csv file as shown above in table. I have upload it with assignment
      df <- read.csv('petlovers.csv')
    
      # plot them in geombar()
      plotpet <- ggplot(df, aes(Pets,People)) +geom_bar(stat = "identity")
      plotpet
      
      # plot them in geomline()
      plotpet <- ggplot(df, aes(Pets,People)) + geom_line(aes(y = People, colour = "Pets"))
      plotpet
      
#Q3 (c) ii. Is it a good idea to choose a pie chart (in case you have not chosen it in (i))?
#           Why is it a good idea or why is it not a good idea?

#Answer
#          No - its not a good idea, as data for no of people loves dogs is an outlier i.e. too high and it held most percentage 
#          of the pie chart.      
