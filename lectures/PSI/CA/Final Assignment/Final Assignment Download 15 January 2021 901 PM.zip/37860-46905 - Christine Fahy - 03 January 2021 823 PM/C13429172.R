# Student Number: C13429172
# Student Name:   Christine Fahy
# ProgrammeCode:  MATH9102
# OptionChosen:   Option A
# Version of R:   4.0.2

# Install and load the following packages:
if(!require(Hmisc))install.packages("Hmisc")
if(!require(Hmisc))install.packages("stargazer")
if(!require(Hmisc))install.packages("lm.beta")
if(!require(Hmisc))install.packages("ggplot2")
if(!require(Hmisc))install.packages("dplyr")
library(Hmisc)
library(stargazer)
library(lm.beta)
library(ggplot2)
library(dplyr)

# Load the CSV file
house_data <- read.csv('House-Dataset.csv')

# Summary for each variable
Hmisc::describe(house_data)

# Check if any houses where there are 0 bedrooms and 0 bathrooms
sum(house_data$bedrooms == 0 & house_data$bathrooms == 0) #7
house_data[house_data$bedrooms == 0 & house_data$bathrooms == 0,]

# Check if sqft_lot is smaller than sqft_living for any houses to see if there is any invalid data
sum(house_data$sqft_lot < house_data$sqft_living) #789

# Clean the data:
# - Remove row for bedroom outlier
house_data <- house_data[!(house_data$bedrooms == 33),]
# - Remove rows for bedroom/bathroom outliers
house_data <- house_data[!(house_data$bedrooms == 0 & house_data$bathrooms == 0),]
# - Remove rows for sqft_lot/sqft_living outliers
house_data <- house_data[!(house_data$sqft_lot < house_data$sqft_living),]

# Relationship between bedrooms/bathrooms and price
plot(house_data$bedrooms, house_data$price)
cor.test(house_data$bedrooms, house_data$price, method="spearman")
t.test(house_data$bedrooms, house_data$price)

plot(house_data$bathrooms, house_data$price)
cor.test(house_data$bathrooms, house_data$price, method="spearman")
t.test(house_data$bathrooms, house_data$price)

# Relationships for sqft_living, sqft_lot, and sqft_basement
plot(house_data$sqft_living, house_data$price)
cor.test(house_data$sqft_living, house_data$price, method="spearman")
t.test(house_data$sqft_living, house_data$price)

plot(house_data$sqft_lot, house_data$price)
cor.test(house_data$sqft_lot, house_data$price, method="spearman")
t.test(house_data$sqft_lot, house_data$price)

plot(house_data$sqft_basement, house_data$price)
cor.test(house_data$sqft_basement, house_data$price, method="spearman")
t.test(house_data$sqft_basement, house_data$price)

# Relationships for condition, lat and long
plot(house_data$condition, house_data$price)
cor.test(house_data$condition, house_data$price, method="spearman")
t.test(house_data$condition, house_data$price)

plot(house_data$lat, house_data$price)
cor.test(house_data$lat, house_data$price, method="spearman")
t.test(house_data$lat, house_data$price)

plot(house_data$long, house_data$price)
cor.test(house_data$long, house_data$price, method="spearman")
t.test(house_data$long, house_data$price)

# Boxplot for Condition and mean/standard deviation of prices for each condition
ggplot(house_data, aes(x=condition, y=price, fill=condition, group=condition)) + geom_boxplot()
house_data %>% group_by(condition) %>% summarise(mean(price), sd(price)) 


# Model 1 for bedrooms and bathrooms
model1 <- lm(house_data$price ~ house_data$bedrooms + house_data$bathrooms)
stargazer(model1, type="text")
anova(model1)
lm.beta(model1)
summary(model1)

# Model 1 - Cook's Distance
cooks1 <- cooks.distance(model1)
plot(cooks1, ylab='Cooks Distance')
max(cooks1)

# Model 1 - VIF
1/vif(model1)

# Model 1 - QQ Plot
qqPlot(model1)


# Model 2 adding sqft_living, sqft_lot and sqft_basement
model2 <- lm(house_data$price ~ house_data$bedrooms + house_data$bathrooms + house_data$sqft_living + house_data$sqft_lot + house_data$sqft_basement)
stargazer(model2, type="text")
anova(model2)
lm.beta(model2)
summary(model2)

# Model 2 - Cook's Distance
cooks2 <- cooks.distance(model2)
plot(cooks2, ylab='Cooks Distance')
max(cooks2)

# Model 2 - VIF
1/vif(model2)

# Model 2 - QQ Plot
qqPlot(model2)


# Model 3 adding condition, lat and long
model3 <- lm(house_data$price ~ house_data$bedrooms + house_data$bathrooms + house_data$sqft_living + house_data$sqft_lot + house_data$sqft_basement + house_data$condition + house_data$lat + house_data$long)
stargazer(model3, type="text")
anova(model3)
lm.beta(model3)
summary(model3)

# Model 3 - Cook's Distance
cooks3 <- cooks.distance(model3)
plot(cooks3, ylab='Cooks Distance')
max(cooks3)

# Model 3 - VIF
1/vif(model3)

# Model 3 - QQ Plot
qqPlot(model3)


# Compare Models
stargazer(model1, model2, model3, type="text")