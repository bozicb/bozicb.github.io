#D20125665 - Laura Smith
#MATH 9102 Prob & Stats
#Final Assignment
#Created using R Version 4.0.2
#31/12/2020

##Relevant Library Install & Import:

if(!require(ggplot2))install.packages("ggplot2")
if(!require(psych))install.packages("psych")
if(!require(gmodels))install.packages("gmodels")
if(!require(stats))install.packages("stats")
if(!require(lmtest))install.packages("lmtest")
if(!require(lm.beta))install.packages("lm.beta")
if(!require(stargazer))install.packages("stargazer")
if(!require(caret))install.packages("caret")
if(!require(Epi))install.packages("Epi")
if(!require(rcompanion))install.packages("rcompanion")
if(!require(dplyr))install.packages("dplyr")
if(!require(car))install.packages("car")

library(ggplot2) #For Graphs & Histograms
library(psych) #Descriptive functions
library(gmodels) #For chi test
library(stats) #Summary stats
library(lmtest)
library(lm.beta) #More linear model functions
library(stargazer) #For formatting outputs/tables
library(caret) 
library(Epi)
library(rcompanion)
library(dplyr)
library(car)


#Read in Brewer's Friend dataset
brewData <- read.csv("RecipeData.csv", header = TRUE)

########################################################################################
### Section headings in this code are named in line with the accompanying Report:    ###
### MATH9102_PSI_FinalAssignment_Laura_Smith_D20125665                               ###
### This report details the analysis, models built and conclusions form this project ###
### and includes all visual plots created by this code.                              ###
########################################################################################


### 3. The Data ###

## Before Outlier Removal ##

#Summary statistics of the dataset as a whole
summary(brewData)

#Summaries of the individual variables used in the subsequent models

#Histogram of ABV (Alcohol By Volume)
ABVHist <- ggplot(brewData, aes(x=ABV)) + geom_histogram(binwidth = 0.5, colour = "black", fill = "pink")
ABVHist <- ABVHist + labs(x="Alcohol By Volume", y = "Frequency") 
ABVHist <- ABVHist + stat_function(fun = function(x) (dnorm(x, mean = mean(brewData$ABV, na.rm=TRUE), sd = sd(brewData$ABV, na.rm=TRUE)) * 50000), colour = "red", size = 1)
ABVHist
#Summary of ABV (Alcohol By Volume)
psych::describe(brewData$ABV)

#Histogram of IBU (International Bitterness Units)
IBUHist <- ggplot(brewData, aes(x=IBU)) + geom_histogram(binwidth = 25, colour = "black", fill = "light blue")
IBUHist <- IBUHist + labs(x="International Bittering Units", y = "Frequency") 
IBUHist <- IBUHist + stat_function(fun = function(x) (dnorm(x, mean = mean(brewData$IBU, na.rm=TRUE), sd = sd(brewData$IBU, na.rm=TRUE)) * 1000000), colour = "blue", size = 1)
IBUHist
#Summary of IBU (International Bitterness Units)
psych::describe(brewData$IBU)

#Histogram of Color (Colour of finished brewed beer)
ColHist <- ggplot(brewData, aes(x=Color)) + geom_histogram(binwidth = 5, colour = "black", fill = "light yellow")
ColHist <- ColHist + labs(x="Colour Scale", y = "Frequency") 
ColHist <- ColHist + stat_function(fun = function(x) (dnorm(x, mean = mean(brewData$Color, na.rm=TRUE), sd = sd(brewData$Color, na.rm=TRUE)) * 500000), colour = "orange", size = 1)
ColHist
#Summary of Color (Colour of finished brewed beer)
psych::describe(brewData$Color)

#Bar chart of BrewMethod (Method of brewing)
methodBar <- ggplot(brewData, aes(BrewMethod, fill = BrewMethod)) + geom_histogram(stat="count")
methodBar <- methodBar + labs(x="Brewing Method") + theme(legend.position="none")
methodBar
#Summary table of BrewMethod (Method of brewing)
table(brewData$BrewMethod)

#Histogram of OG (Original Gravity of wort prior to fermentation)
OGHist <- ggplot(brewData, aes(x=OG)) + geom_histogram(binwidth = 0.01, colour = "black", fill = "pink")
OGHist <- OGHist + labs(x="Original Gravity", y = "Frequency") 
OGHist <- OGHist + stat_function(fun = function(x) (dnorm(x, mean = mean(brewData$OG, na.rm=TRUE), sd = sd(brewData$OG, na.rm=TRUE)) * 100000), colour = "red", size = 1)
OGHist
#Summary of OG (Original Gravity of wort prior to fermentation)
psych::describe(brewData$OG)

#Histogram of FG (Final Gravity of wort after fermentation)
FGHist <- ggplot(brewData, aes(x=FG)) + geom_histogram(binwidth = 0.01, colour = "black", fill = "light blue")
FGHist <- FGHist + labs(x="Final Gravity", y = "Frequency") 
FGHist <- FGHist + stat_function(fun = function(x) (dnorm(x, mean = mean(brewData$FG, na.rm=TRUE), sd = sd(brewData$FG, na.rm=TRUE)) * 50000), colour = "blue", size = 1)
FGHist
#Summary of FG (Final Gravity of wort after fermentation)
psych::describe(brewData$FG)

#Histogram of Efficiency (Beer mash extraction efficiency - extracting sugars from the grain during mash)
EffHist <- ggplot(brewData, aes(x=Efficiency)) + geom_histogram(binwidth = 10, colour = "black", fill = "light yellow")
EffHist <- EffHist + labs(x="Efficiency", y = "Frequency") 
EffHist <- EffHist + stat_function(fun = function(x) (dnorm(x, mean = mean(brewData$Efficiency, na.rm=TRUE), sd = sd(brewData$Efficiency, na.rm=TRUE)) * 1000000), colour = "orange", size = 1)
EffHist
#Summary of Efficiency (Beer mash extraction efficiency - extracting sugars from the grain during mash)
psych::describe(brewData$Efficiency)


## Outlier Removal method ##


#Number of rows in the dataset prior to outlier removal
nrow(brewData)


# Subset 1: Outliers Removed for ABV & IBU #

#Removal of outliers for ABV & IBU
brewDataOutRem <- filter(brewData, brewData$ABV > 5.080 & brewData$ABV < 6.830 & brewData$IBU > 23.37 & brewData$IBU < 56.38)
#Number of rows following this subsetting of the data
nrow(brewDataOutRem)
#Summary of subset 1 of the data
summary(brewDataOutRem)


# Subset 2: Outliers Removed for ABV, OG & FG #

#Removal of outliers for ABV, OG & FG
brewDataOutRem2 <- filter(brewData, brewData$ABV > 5.080 & brewData$ABV < 6.830 & brewData$OG > 1.051 & brewData$FG > 1.011, brewData$OG < 1.069 & brewData$FG < 1.017)
#Number of rows following this subsetting of the data
nrow(brewDataOutRem2)
#Summary of subset 2 of the data
summary(brewDataOutRem2)


## After Outlier Removal ##


# Subset 1: Outliers Removed for ABV & IBU #

#Histogram of ABV (Alcohol By Volume) in Subset 1
ABVHist2 <- ggplot(brewDataOutRem, aes(x=ABV)) + geom_histogram(binwidth = 0.1, colour = "black", fill = "pink")
ABVHist2 <- ABVHist2 + labs(x="Alcohol By Volume", y = "Frequency") 
ABVHist2 <- ABVHist2 + stat_function(fun = function(x) (dnorm(x, mean = mean(brewDataOutRem$ABV, na.rm=TRUE), sd = sd(brewDataOutRem$ABV, na.rm=TRUE)) * 2500), colour = "red", size = 1)
ABVHist2
#Summary of ABV (Alcohol By Volume) in Subset 1
psych::describe(brewDataOutRem$ABV)

#Histogram of IBU (International Bitterness Units) in Subset 1
IBUHist2 <- ggplot(brewDataOutRem, aes(x=IBU)) + geom_histogram(binwidth = 2.5, colour = "black", fill = "light blue")
IBUHist2 <- IBUHist2 + labs(x="International Bittering Units", y = "Frequency") 
IBUHist2 <- IBUHist2 + stat_function(fun = function(x) (dnorm(x, mean = mean(brewDataOutRem$IBU, na.rm=TRUE), sd = sd(brewDataOutRem$IBU, na.rm=TRUE)) * 50000), colour = "blue", size = 1)
IBUHist2
#Summary of IBU (International Bitterness Units) in Subset 1
psych::describe(brewDataOutRem$IBU)

#Histogram of Color (Colour of the home brew at the end of the process) in Subset 1
ColHist2 <- ggplot(brewDataOutRem, aes(x=Color)) + geom_histogram(binwidth = 1, colour = "black", fill = "light yellow")
ColHist2 <- ColHist2 + labs(x="Colour Scale", y = "Frequency") 
ColHist2 <- ColHist2 + stat_function(fun = function(x) (dnorm(x, mean = mean(brewDataOutRem$Color, na.rm=TRUE), sd = sd(brewDataOutRem$Color, na.rm=TRUE)) * 25000), colour = "orange", size = 1)
ColHist2
#Summary of Color (Colour of the home brew at the end of the process) in Subset 1
psych::describe(brewDataOutRem$Color)

#Bar chart of BrewMethod (Method of brewing) in subset 1
methodBar2 <- ggplot(brewDataOutRem, aes(BrewMethod, fill = BrewMethod)) + geom_histogram(stat="count")
methodBar2 <- methodBar2 + labs(x="Brewing Method") + theme(legend.position="none")
methodBar2
#Summary table of BrewMethod (Method of brewing) in subset 1
table(brewDataOutRem$BrewMethod)


# Subset 2: Outliers Removed for ABV, OG & FG #

#Histogram of ABV (Alcohol By Volume) in Subset 2
ABVHist3 <- ggplot(brewDataOutRem2, aes(x=ABV)) + geom_histogram(binwidth = 0.1, colour = "black", fill = "pink")
ABVHist3 <- ABVHist3 + labs(x="Alcohol By Volume", y = "Frequency") 
ABVHist3 <- ABVHist3 + stat_function(fun = function(x) (dnorm(x, mean = mean(brewDataOutRem2$ABV, na.rm=TRUE), sd = sd(brewDataOutRem2$ABV, na.rm=TRUE)) * 1500), colour = "red", size = 1)
ABVHist3
#Summary of ABV (Alcohol By Volume) in Subset 2
psych::describe(brewDataOutRem2$ABV)

#Histogram of OG (Original Gravity of wort prior to fermentation) in Subset 2
OGHist2 <- ggplot(brewDataOutRem2, aes(x=OG)) + geom_histogram(binwidth = 0.001, colour = "black", fill = "light blue")
OGHist2 <- OGHist2 + labs(x="Original Gravity", y = "Frequency") 
OGHist2 <- OGHist2 + stat_function(fun = function(x) (dnorm(x, mean = mean(brewDataOutRem2$OG, na.rm=TRUE), sd = sd(brewDataOutRem2$OG, na.rm=TRUE)) * 15), colour = "blue", size = 1)
OGHist2
#Summary of OG (Original Gravity of wort prior to fermentation) in Subset 2
psych::describe(brewDataOutRem2$OG)

#Histogram of FG (Final Gravity of wort after fermentation) in Subset 2
FGHist2 <- ggplot(brewDataOutRem2, aes(x=FG)) + geom_histogram(binwidth = 0.001, colour = "black", fill = "light yellow")
FGHist2 <- FGHist2 + labs(x="Final Gravity", y = "Frequency") 
FGHist2 <- FGHist2 + stat_function(fun = function(x) (dnorm(x, mean = mean(brewDataOutRem2$FG, na.rm=TRUE), sd = sd(brewDataOutRem2$FG, na.rm=TRUE)) * 15), colour = "orange", size = 1)
FGHist2
#Summary of FG (Final Gravity of wort after fermentation) in Subset 2
psych::describe(brewDataOutRem2$FG)

#Histogram of Efficiency (Beer mash extraction efficiency - extracting sugars from the grain during mash) in subset 2
EffHist2 <- ggplot(brewDataOutRem2, aes(x=Efficiency)) + geom_histogram(binwidth = 10, colour = "black", fill = "darkseagreen1")
EffHist2 <- EffHist2 + labs(x="Efficiency", y = "Frequency") 
EffHist2 <- EffHist2 + stat_function(fun = function(x) (dnorm(x, mean = mean(brewDataOutRem2$Efficiency, na.rm=TRUE), sd = sd(brewDataOutRem2$Efficiency, na.rm=TRUE)) * 250000), colour = "forestgreen", size = 1)
EffHist2
#Summary of Efficiency (Beer mash extraction efficiency - extracting sugars from the grain during mash) in subset 2
psych::describe(brewDataOutRem2$Efficiency)


## Relationships ##


# Subset 1 #

#Scatter plot of ABV vs IBU
ABVIBUSca2 <- ggplot(brewDataOutRem, aes(ABV, IBU)) + geom_point() 
ABVIBUSca2 <- ABVIBUSca2 + labs(x = "Alcohol By Volume", y = "International Bittering Units") + geom_smooth(method=lm, se=FALSE)
ABVIBUSca2

#Scatter plot of ABV vs Color
ABVColSca2 <- ggplot(brewDataOutRem, aes(ABV, Color)) + geom_point() 
ABVColSca2 <- ABVColSca2 + labs(x = "Alcohol By Volume", y = "Colour Scale") + geom_smooth(method=lm, se=FALSE)
ABVColSca2

#Box Plot of ABV vs Brew Method
methABVBox2 <- ggplot(brewDataOutRem, aes(BrewMethod, ABV))
methABVBox2 <- methABVBox2 + geom_boxplot() + labs(x = "Brewing Methods", y = "ABV")
methABVBox2

#Scatter plot of IBU vs Color
IBUColSca2 <- ggplot(brewDataOutRem, aes(IBU, Color)) + geom_point() 
IBUColSca2 <- IBUColSca2 + labs(x = "IBU", y = "Colour Scale") + geom_smooth(method=lm, se=FALSE)
IBUColSca2

#Correlation test between ABV & IBU
cor.test(brewDataOutRem$ABV, brewDataOutRem$IBU, method="pearson")

#Correlation test between ABV & Color
cor.test(brewDataOutRem$ABV, brewDataOutRem$Color, method="pearson")

#Correlation test between IBU & Color
cor.test(brewDataOutRem$IBU, brewDataOutRem$Color, method="pearson")

#Anova correlation test for ABV & BreMethod
res.aov <- aov(brewDataOutRem$ABV ~ brewDataOutRem$BrewMethod, data = brewDataOutRem)
# Summary of this analysis
summary(res.aov)


# Subset 2 #

#Scatter plot of ABV vs OG
ABVOGSca2 <- ggplot(brewDataOutRem2, aes(ABV, OG)) + geom_point() 
ABVOGSca2 <- ABVOGSca2 + labs(x = "ABV", y = "Original Gravity") + geom_smooth(method=lm, se=FALSE)
ABVOGSca2

#Scatter plot of ABV vs FG
ABVFGSca2 <- ggplot(brewDataOutRem2, aes(ABV, FG)) + geom_point() 
ABVFGSca2 <- ABVFGSca2 + labs(x = "ABV", y = "Final Gravity") + geom_smooth(method=lm, se=FALSE)
ABVFGSca2

#Scatter plot of ABV vs Efficiency
ABVEffSca2 <- ggplot(brewDataOutRem2, aes(ABV, Efficiency)) + geom_point() 
ABVEffSca2 <- ABVEffSca2 + labs(x = "ABV", y = "Efficiency") + geom_smooth(method=lm, se=FALSE)
ABVEffSca2

#Correlation test between ABV & OG
cor.test(brewDataOutRem2$ABV, brewDataOutRem2$OG, method="pearson")

#Correlation test between ABV & FG
cor.test(brewDataOutRem2$ABV, brewDataOutRem2$FG, method="pearson")

#Correlation test between ABV & Efficiency
cor.test(brewDataOutRem2$ABV, brewDataOutRem2$Efficiency, method="pearson")


### 4. Model Results ###


## Hypothesis 1 ##

#Model for IBU to predict ABV#
modelABVIBU <- lm(brewDataOutRem$ABV ~ brewDataOutRem$IBU)
summary(modelABVIBU)
lm.beta(modelABVIBU)
stargazer(modelABVIBU, type="text")

#Model for Color to predict ABV#
modelABVCol <- lm(brewDataOutRem$ABV ~ brewDataOutRem$Color)
summary(modelABVCol)
lm.beta(modelABVCol)
stargazer(modelABVCol, type="text")

#Model for IBU plus Color to predict ABV#
modelABVIBUCol <- lm(brewDataOutRem$ABV ~ brewDataOutRem$IBU + brewDataOutRem$Color)
anova(modelABVIBUCol)
summary(modelABVIBUCol)
lm.beta(modelABVIBUCol)
stargazer(modelABVIBUCol, type="text")


## Hypothesis 2 ##

#Recode Brew Method to Categorical Codes prior to modelling
brewDataOutRem$BrewMethod = recode(brewDataOutRem$BrewMethod,'"All Grain" = 0 ; "BIAB" = 1; "extract" = 2; "Partial Mash" = 3')
#Check this recoding has completed correctly
head(brewDataOutRem)
table(brewDataOutRem$BrewMethod)

#Model for BrewMethod to predict ABV#
modelABVBM <- lm(brewDataOutRem$ABV ~ brewDataOutRem$BrewMethod)
summary(modelABVBM)
lm.beta(modelABVBM)
stargazer(modelABVBM, type="text")

#Model for IBU plus Color plus BrewMethod to predict ABV
modelABVAll <- lm(brewDataOutRem$ABV ~ brewDataOutRem$IBU + brewDataOutRem$Color + brewDataOutRem$BrewMethod)
anova(modelABVAll)
summary(modelABVAll)
lm.beta(modelABVAll)
stargazer(modelABVAll, type="text")


## Hypothesis 3 ##

#Model for OG to predict ABV
modelABVOG <- lm(brewDataOutRem2$ABV ~ brewDataOutRem2$OG)
summary(modelABVOG)
lm.beta(modelABVOG)
stargazer(modelABVOG, type="text")

#Model for FG to predict ABV
modelABVFG <- lm(brewDataOutRem2$ABV ~ brewDataOutRem2$FG)
summary(modelABVFG)
lm.beta(modelABVFG)
stargazer(modelABVFG, type="text")

#Model for OG plus FG to predict ABV
modelABVOGFG <- lm(brewDataOutRem2$ABV ~ brewDataOutRem2$OG + brewDataOutRem2$FG)
anova(modelABVOGFG)
summary(modelABVOGFG)
lm.beta(modelABVOGFG)
stargazer(modelABVOGFG, type="text")


## Hypothesis 4 ##

#Model for OG plus FG plus efficiency to predict ABV
modelABVOGFGEff <- lm(brewDataOutRem2$ABV ~ brewDataOutRem2$OG + brewDataOutRem2$FG + brewDataOutRem2$Efficiency)
anova(modelABVOGFGEff)
summary(modelABVOGFGEff)
lm.beta(modelABVOGFGEff)
stargazer(modelABVOGFGEff, type="text")


### Appendix ###

#Relationships between variables prior to outlier removal

#Scatter plot of ABV vs IBU
ABVIBUSca <- ggplot(brewData, aes(ABV, IBU)) + geom_point() 
ABVIBUSca <- ABVIBUSca + labs(x = "Alcohol By Volume", y = "International Bittering Units") + geom_smooth(method=lm, se=FALSE)
ABVIBUSca

#Scatter plot of ABV vs Color
ABVColSca <- ggplot(brewData, aes(ABV, Color)) + geom_point() 
ABVColSca <- ABVColSca + labs(x = "Alcohol By Volume", y = "Colour Scale") + geom_smooth(method=lm, se=FALSE)
ABVColSca

#Box plot of ABV vs Brewing Method
methABVBox <- ggplot(brewData, aes(BrewMethod, ABV))
methABVBox <- methABVBox + geom_boxplot() + labs(x = "Brewing Methods", y = "ABV")
methABVBox

#Scatter plot of ABV vs OG
ABVOGSca <- ggplot(brewData, aes(ABV, OG)) + geom_point() 
ABVOGSca <- ABVOGSca + labs(x = "ABV", y = "Original Gravity") + geom_smooth(method=lm, se=FALSE)
ABVOGSca

#Scatter plot of ABV vs FG
ABVFGSca <- ggplot(brewData, aes(ABV, FG)) + geom_point() 
ABVFGSca <- ABVFGSca + labs(x = "ABV", y = "Final Gravity") + geom_smooth(method=lm, se=FALSE)
ABVFGSca

#Scatter plot of ABV vs Efficiency
ABVEffSca <- ggplot(brewData, aes(ABV, Efficiency)) + geom_point() 
ABVEffSca <- ABVEffSca + labs(x = "ABV", y = "Efficiency") + geom_smooth(method=lm, se=FALSE)
ABVEffSca

