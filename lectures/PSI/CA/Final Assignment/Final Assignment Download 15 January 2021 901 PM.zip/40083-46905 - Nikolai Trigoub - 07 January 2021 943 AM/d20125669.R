
# Student Number: D20125669
# Student Name: Nikolai Trigoub
# ProgrammeCode: TU256
# Option Chosen: A
# The version of R used - Mac Version 1.3.1093

installed.packages("dplyr")
installed.packages("lubridate")
installed.packages("corrplot")
install.packages("Hmisc")
install.packages("ggplot2")
install.packages('fastDummies')
install.packages("ggstatsplot")
install.packages("sjPlot")
install.packages("gt")
install.packages("moments")
install.packages("fastDummies")

library(dplyr)
library(lubridate)
library(corrplot)
library(Hmisc)
library(ggplot2)
library(fastDummies)
library(tidyverse) 
library(broom)
library(carData)
library(psych)
library(lubridate)
library(stargazer)
library(corrplot)
library(car)
library(ggstatsplot)
library(reshape2)
library(ggstatsplot)
library(sjPlot)
library(gt)
library(moments)
library(fastDummies)

# Load in the Data CSV
df <- read.csv("nyc-rolling-sales.csv", header = T, na.strings = c("NA"," ","	
 -  "))
#Reduce the Varibables to the ones that we are interested in
df1 <- df %>% select(BOROUGH, BUILDING.CLASS.CATEGORY, RESIDENTIAL.UNITS, COMMERCIAL.UNITS, GROSS.SQUARE.FEET, YEAR.BUILT,  SALE.PRICE, SALE.DATE)

#Do some Summary Statistics
str(df1)
summary(df1)

#Convert to appropriate type
df1$BOROUGH <- as.factor(df1$BOROUGH)
df1$RESIDENTIAL.UNITS <- as.numeric(df1$RESIDENTIAL.UNITS)
df1$COMMERCIAL.UNITS <- as.numeric(df1$COMMERCIAL.UNITS)
df1$GROSS.SQUARE.FEET <- as.numeric(df1$GROSS.SQUARE.FEET) 
df1$YEAR.BUILT <- as.numeric(df1$YEAR.BUILT) 
df1$SALE.PRICE <- as.numeric(df1$SALE.PRICE) 
df1$SALE.DATE <-  ymd_hms(df1$SALE.DATE)
df1$BUILDING.CLASS.CATEGORY <- as.factor(df1$BUILDING.CLASS.CATEGORY)

df1 %>% 
  select_if(function(x) any(is.na(x))) %>% 
  summarise_each(funs(sum(is.na(.)))) -> df1_NA

###Remove data that isn't complete or inaccurate or not of interest to us

#We also want to remove all Sales including Commercial property as we are only interested in Residental
df1 <- subset(df1, COMMERCIAL.UNITS==0)

#We also want to remove all Sales where the residental units are = 0
df1 <- subset(df1, RESIDENTIAL.UNITS==1)

df1 <- subset(df1, BUILDING.CLASS.CATEGORY=="01 ONE FAMILY DWELLINGS                    ")

# Removing all datapoints where Square Metres is equal to 0 - Assume these are either land sale or missing values
df1 <- subset(df1, GROSS.SQUARE.FEET>0)
str(df1)

#We want to remove the $ Sales 0 as they are transfers not purchases
df1 <- subset(df1, SALE.PRICE > 0)

#Now to check for NAs in the data
df1 %>% 
  select_if(function(x) any(is.na(x))) %>% 
  summarise_each(funs(sum(is.na(.)))) -> df1cleaned_NA

str(df1)


#Adding Month Column & categorising whether it is peak, off-peak or neutral
df1 <- df1 %>% mutate(month = month(SALE.DATE, label = T))



levels(df2$month)

df21 <- df1 %>% filter(month == "May" | month == "Jun" | month == "Jul" | month == "Aug") %>% mutate(time = 'Peak')
df22 <- df1 %>% filter(month == "Nov" | month == "Dec" | month == "Jan"| month == "Feb" ) %>% mutate(time = 'OffPeak')
df23 <- df1 %>% filter(month == "Mar" | month == "Apr" | month == "Sep" | month == "Oct" ) %>% mutate(time = 'Neutral')

#Below is the dataset with month and peak/offpeak/neutral
df1final <- bind_rows(df21, df22, df23)
describe(df1final$time)


str(df1final)
summary(df1final)


# What do we want to use in our MLR  Total Sq Foot, Borough, Seasonality

df1finallessman <- subset(df1final, BOROUGH!=1)
df1finaljustman <- subset(df1final, BOROUGH==1)

#Lets look at Sales 

ggsalessqm <- ggplot(df1final,aes(x =GROSS.SQUARE.FEET,y= SALE.PRICE)) +
  geom_point()

ggsalessqm

#Boxplot of Sales Price by Area
box1to5 <- ggplot(df1final, aes(x=BOROUGH, y=SALE.PRICE)) + 
  geom_boxplot()
  labs(title="Boxplot 5 Boroughs vs Price")
 

box2to5 <- ggplot(df1finallessman, aes(x=BOROUGH, y=SALE.PRICE)) + 
  geom_boxplot()
  labs(title="Boxplot 4 Boroughs Ex. Manhattan vs Price")

box1to5 
box2to5  

# Bar Chart of Freqency by Borough
bar1to5 <- ggplot(df1final, aes(x=BOROUGH)) + 
  geom_bar()
bar1to5

#Histogram Charts of Price All 5 Boroughs
sales1to5 <- ggplot(df1final, aes(x=SALE.PRICE)) + 
  geom_histogram(binwidth =100000, fill="steelblue")+
  labs(title="Histogram Sale Price - Borough 1, 2, 3, 4, 5", 
       x="Sale Price", y = "Count")
sales1to5

#Histogram Charts of Price 2-5 Boroughs
sales2to5 <- ggplot(df1finallessman, aes(x=SALE.PRICE)) + 
  geom_histogram(binwidth =100000, fill="steelblue") +
  labs(title="Histogram Sale Price - Borough 2, 3, 4, 5", 
       x="Sale Price", y = "Count")
sales2to5

#Histogram Charts of Price Brough 1 Manhattan
sales1 <- ggplot(df1finaljustman, aes(x=SALE.PRICE)) + 
  geom_histogram(binwidth =100000, fill="steelblue") +
  labs(title="Histogram Sale Price - Borough 1 Only", 
       x="Sale Price", y = "Count")
sales1

#Point of Price All 5 Boroughs to Square Feet
psales1to5 <- ggplot(df1final, aes(x = GROSS.SQUARE.FEET, y=SALE.PRICE, color = BOROUGH)) + 
  geom_point() +
  labs(title="Plot of Sale Price vs Land Sq Ft - Borough 1, 2, 3, 4, 5", 
       x="Land Square Feet", y = "Sale Price")
psales1to5

#Point of Price 2-5 Boroughs to Square Feet
psales2to5 <- ggplot(df1finallessman, aes(x = GROSS.SQUARE.FEET, y=SALE.PRICE, color = BOROUGH)) + 
  geom_point() +
  labs(title="Plot of Sale Price vs Land Sq Ft - Borough 2, 3, 4, 5", 
                   x="Land Square Feet", y = "Sale Price")
psales2to5

#Summary Table Price
sumSP <- df1final %>% group_by(BOROUGH) %>% summarise(Mean_Sale_Price=mean(SALE.PRICE), Median_Sale_Price=median(SALE.PRICE), Mean_SQ_FOOTAGE=mean(GROSS.SQUARE.FEET), IQR_Sale_Price=IQR(SALE.PRICE), SD_Sale_Price=sd(SALE.PRICE), Min_Sale_Price=min(SALE.PRICE), Max_Sale_Price=max(SALE.PRICE),Dollar_SQ_Foot=(Mean_Sale_Price/Mean_SQ_FOOTAGE), N=n()) 

gt(sumSP) %>%
  tab_header(
    title = "Sales Price All Boroughs",
  )


sumLQF <- df1final %>% group_by(BOROUGH) %>% summarise(Mean_SQ_FOOTAGE=mean(GROSS.SQUARE.FEET), Median_SQ_FOOTAGE=median(GROSS.SQUARE.FEET), IQR_SQ_FOOTAGE=IQR(GROSS.SQUARE.FEET), SD_SQ_FOOTAGE=sd(GROSS.SQUARE.FEET), Min_SQ_FOOTAGE=min(GROSS.SQUARE.FEET), Max_SQ_FOOTAGE=max(GROSS.SQUARE.FEET), N=n()) 

gt(sumLQF) %>%
  tab_header(
    title = "Square Footage Price All Boroughs",
    subtitle = glue::glue("No Outliers Removed")
  )



#Look at Histogram by Borough

Hist1<- ggplot(subset(df1final, BOROUGH == 1), 
       aes(x = SALE.PRICE)) +
       geom_histogram(binwidth =250000, fill="steelblue")+
       labs(title="Histogram Sale Price - Borough 1 Manhattan", x="Sale Price", y = "Count")


Hist2<- ggplot(subset(df1final, BOROUGH == 2), 
               aes(x = SALE.PRICE)) +
  geom_histogram(binwidth =250000, fill="steelblue")+
  labs(title="Histogram Sale Price - Borough 2 Bronx", x="Sale Price", y = "Count")

Hist3<- ggplot(subset(df1final, BOROUGH == 3), 
               aes(x = SALE.PRICE)) +
  geom_histogram(binwidth =250000, fill="steelblue")+
  labs(title="Histogram Sale Price - Borough 3 Brooklyn", x="Sale Price", y = "Count")

Hist4<- ggplot(subset(df1final, BOROUGH == 4), 
               aes(x = SALE.PRICE)) +
  geom_histogram(binwidth =250000, fill="steelblue")+
  labs(title="Histogram Sale Price - Borough 4 Queens", x="Sale Price", y = "Count")

Hist5<- ggplot(subset(df1final, BOROUGH == 5), 
               aes(x = SALE.PRICE)) +
  geom_histogram(binwidth =250000, fill="steelblue")+
  labs(title="Histogram Sale Price - Borough 5 Staten Island", x="Sale Price", y = "Count")

#return the Histograms of Price per borough to assess normality pre outlier. 
Hist1
Hist2
Hist3
Hist4
Hist5

#We can see from the historgrams that the while Boroughs 2-5 show normality in the Sales.Price distribution this is not present in Manhattan Borough 1. 
#Due to the presence of large outliers, small number of records (n=75) it was decided to exlude to remove Manhattan data from the study and focus on Boroughs 2-5 as the data there has more likelyhood to be significant 


#Q-Q Plots for Sale Price All 5 Boroughs
qqnorm(df1final$SALE.PRICE)
qqline(df1final$SALE.PRICE, col=2)

#Q-Q Plots for Sale Price 4 Boroughs
qqnorm(df1finallessman$SALE.PRICE)
qqline(df1finallessman$SALE.PRICE, col=2)

#Calculate Skew & Kurtosis

describe(df1finallessman, skew = TRUE)


#Skew =  17.6, Kurtosis = 489.07  for Sales Price All Boroughs, No Outlier Removal
skew(df1final$SALE.PRICE)
kurtosis(df1final$SALE.PRICE)

#Skew =  7.59 Kurtosis = 122.47  for Sales Price 2-5 Boroughs, No Outlier Removal
skew(df1finallessman$SALE.PRICE)
kurtosis(df1finallessman$SALE.PRICE)





#Seperate the Building Age into Pre & Post War
#df2final$Age <- cut(df2final$YEAR.BUILT, breaks=c(0,1945,2016), labels = c("Pre WW2", "Post WW2"))


#Create Dummy Variables for Borough, Time & Age



# Correlation Plot

#Corr <- cor(df1finallessman)
#Corr <- corrplot(df1finallessman, method = "number")


# Pearson Correlation
#cor(df2final$SALE.PRICE, df2final$GROSS.SQUARE.FEET)




#Linear model 1 - Sales Price & SqFt 

model1 <- lm(formula = SALE.PRICE ~ GROSS.SQUARE.FEET, data = df1finallessman)
model1
summary(model1)
Anova(model1)
# Confidence Intervals
confint(model1, conf.level=0.95)
plot(model1)


plot(cooks.distance(lm(SALE.PRICE ~ GROSS.SQUARE.FEET, data = df1finallessman)))



# Estimated intercept is 435,331 (SE = 7588) and estimated slope is  51.91 (SE = 1.886). For testing the null hypothesis, that there is no relation between Land Square Feet and Price the t -statistic is 27.53.  
# Based on the T-Distribution with 12,691 degrees of freedom p-value < 2e-16). We would reject the null hyptothesis using a  0.05 significance level
# For testing the hypothesis that the intercept is 0, T Statistic is 57.37 based on the t distribution with the 12691 degrees of freedom (p-value < 2e-16 ). We can reject the null hypothesis
# Residual Standard Error is 497900
# Adjusted R-Squared is 0.05627, approaching a Medium Effect (Cohen, 1988 XXX).  5.627%  of the variance in y can be explained by Regression Model 1


#Linear model 2 - Sales Price & SqFt & Borough

#Start by creating dummy variables

dftest <- df1finallessman
df1finallessman$BOROUGH <- factor(df1finallessman$BOROUGH)
dftest$BOROUGH <- factor(dftest$BOROUGH)

levels(df1finallessman$BOROUGH)
levels(dftest$BOROUGH)

df1finallessman <- df1finallessman %>%
  dummy_cols(select_columns = "BOROUGH", remove_first_dummy = TRUE)


model2 <- lm(formula = SALE.PRICE ~ GROSS.SQUARE.FEET + BOROUGH_3 + BOROUGH_4 + BOROUGH_5, data = df1finallessman)
model2
summary(model2)
Anova(model1, model2)

plot(cooks.distance(lm(SALE.PRICE ~ GROSS.SQUARE.FEET + BOROUGH_3 + BOROUGH_4 + BOROUGH_5 , data = df1finallessman)))

vif(lm(SALE.PRICE ~ GROSS.SQUARE.FEET + BOROUGH_3 + BOROUGH_4 + BOROUGH_5, data = df1finallessman))

#Linear model 3 - Sales Price & SqFt & Borough & Season



df1finallessman <- df1finallessman %>%
  dummy_cols(select_columns = "time", remove_first_dummy = TRUE)
str(df1finallessman)
model3 <- lm(formula = SALE.PRICE ~ GROSS.SQUARE.FEET + BOROUGH_3 + BOROUGH_4 + BOROUGH_5 + time_OffPeak + time_Peak, data = df1finallessman)
model3
summary(model3)
Anova(model3)

plot(cooks.distance(lm(SALE.PRICE ~ GROSS.SQUARE.FEET + BOROUGH_3 + BOROUGH_4 + BOROUGH_5 + time_OffPeak + time_Peak, data = df1finallessman)))

vif(lm(SALE.PRICE ~ GROSS.SQUARE.FEET + BOROUGH_3 + BOROUGH_4 + BOROUGH_5 + time_OffPeak + time_Peak, data = df1finallessman))


anova(model2, model3)


nb.html


output: html_notebook
