library(ggplot2)
library(Hmisc)
library(psych)
library(semTools)
library(car)

# 1. Daily high-temperature and accidents
temp <- c(91,56,75,68,50,39,98)
accidents <- c(2,9,7,6,6,10,1)
accTemp <- data.frame(temp, accidents)
scatter1 <- ggplot(accTemp, aes(temp, accidents))
scatter1 + geom_point()
scatter1 + geom_point() + geom_smooth()
# Plot appears to show weak negative correlation between temperature and
# accidents based on plot. Does not account for confounding variables, if applicable.

# 2. 1% level of significance test whether insulin has reduced sugar level
before <- c(350,400,250,200,180)
after <- c(200,300,200,150,120)
insulin <- data.frame(before,after)
cor.test(insulin$after,insulin$before, method="pearson")
# p-value of 0.03024 > 0.01 therefore don't reject null hypothesis that there is
# no relationship between the two variables based on 1% significance level.

# 3. Correlation test of student exam results in 2 subjects
maths <- c(50,54,56,59,60,62,61,65,67,71,71,74)
stat <- c(22,25,34,28,26,30,32,30,28,34,36,40)
scoreSet <- data.frame(maths,stat)
# Visualise data to assess linearity
ggplot(scoreSet, aes(stat,maths)) + geom_point()
# Test data for normality graphically
ggplot(scoreSet, aes(stat)) + geom_histogram(aes(y=..density..)) + stat_function(fun = dnorm, args = list(mean = mean(scoreSet$stat), sd = sd(scoreSet$stat)))
qplot(sample=scoreSet$stat,stat='qq')
ggplot(scoreSet, aes(maths)) + geom_histogram(aes(y=..density..)) + stat_function(fun = dnorm, args = list(mean = mean(scoreSet$maths), sd = sd(scoreSet$maths)))
qplot(sample=scoreSet$stat,stat='qq')
# Shapiro-Wilk test
shapiro.test(scoreSet$stat)
shapiro.test(scoreSet$maths)
# Based on normality (qq) plots and shapiro p>0.05 assume normality  
# Test data for correlation
cor.test(scoreSet$stat,scoreSet$maths, method = "pearson")

# 4. Heart Disease
heartdisease <- read.csv("heartdisease.data")
# (a) Assess variables for normality
# (i) graphical assessment
qplot(sample=heartdisease$Chol,stat="qq")
qplot(sample=heartdisease$RestBP,stat="qq")
qplot(sample=heartdisease$MaxHR,stat="qq")
# From normality plots variables appear to come from normal distributions

# (ii) numerically Using Shapiro-Wilk test
shapiro.test(heartdisease$Chol)
shapiro.test(heartdisease$RestBP)
shapiro.test(heartdisease$MaxHR)
# Results indicate deviation from normality but may be impacted by large sample
# (iii) skew and kurtosis-should be zero in normal distribution
skew(heartdisease$Chol)
kurtosis(heartdisease$Chol)
skew(heartdisease$RestBP)
kurtosis(heartdisease$RestBP)
skew(heartdisease$MaxHR)
kurtosis(heartdisease$MaxHR)
# (b) relationship between variables Pearson, Spearman/Kendall
# (i) 
cor.test(heartdisease$Chol,heartdisease$RestBP, method = "spearman")
# (ii)
shapiro.test(heartdisease$Oldpeak)
cor.test(heartdisease$Chol,heartdisease$Oldpeak, method = "spearman")
# No strong correlation between variables analysed in either (i) or (ii)

# 5. Is there a significant difference between those with hepatitis for bilirubin and sgot variables (two groups)
# t-tests for each variable-bilirubin/sgot
hepatitis <- read.csv("hepatitis.data")
colnames(hepatitis) <- c("Class", "AGE", "SEX", "STEROID", "ANTIVIRALS", "FATIGUE", "MALAISE", "ANOREXIA", "LIVERBIG", "LIVERFIRM", "SPLENPALPABLE", "SPIDERS", "ASCITES", "VARICES", "BILIRUBIN", "ALKPHOSPHATE", "SGOT", "ALBMIN", "PROTIME", "HISTOLOGY")
# (i) Histology difference - Bilirubin 
# Levenes test (continuous~categorical) in advance of t-test
leveneTest(as.numeric(BILIRUBIN)~factor(HISTOLOGY), data = hepatitis)
# Pr(>F) 0.002331 < 0.5 not homogeneous - var.equal=FALSE
# t.test(outcome ~ predictor, data = df)
t.test(as.numeric(BILIRUBIN)~factor(HISTOLOGY),var.equal=FALSE, data = hepatitis)
# Results imply that there is difference in histology but not significant
# (ii) Histology difference - SGOT
leveneTest(as.numeric(SGOT)~factor(HISTOLOGY), data = hepatitis)
# Pr(>F) 0.08539
t.test(as.numeric(SGOT)~factor(HISTOLOGY), var.equal=FALSE, data = hepatitis)
# Results imply significant difference in histology

# 6. Hypothesis test Alk. Phosphate-Hepatitis Histology p<0.05
# H0 Null hypothesis - Alk. levels have no impact on Histology
# H1 Alternative Hypothesis - Alk. levels have some impact on Histology
leveneTest(as.numeric(ALKPHOSPHATE)~factor(HISTOLOGY), data = hepatitis)
t.test(as.numeric(ALKPHOSPHATE)~factor(HISTOLOGY), data = hepatitis)
# p= >0.05 - Don't reject null hyptothesis (H0)

# 7. (a) Does bilirubin affect liver firm (binary variable-yes/no)
# t.test(bilirubin, liver firm)
leveneTest(as.numeric(BILIRUBIN)~factor(as.numeric(LIVERFIRM)), data = hepatitis)
# Pr(>F) > 0.5 indicates homogeneity of data
t.test(as.numeric(BILIRUBIN)~factor(as.numeric(LIVERFIRM)),var.equal=TRUE,data = hepatitis)
# Results indicate that Bilirubin level affects Liver Firm

# (b) differences in steroid level (no/yes) and hepatitis histology (no/yes)
# compare output (histology)
# Variables are not continuous
wilcox.test(as.numeric(STEROID)~as.factor(HISTOLOGY),data = hepatitis)
# Results indicate difference in attributes