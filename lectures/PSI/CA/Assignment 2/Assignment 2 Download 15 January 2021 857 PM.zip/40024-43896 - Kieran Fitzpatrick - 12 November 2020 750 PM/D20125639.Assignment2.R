library(pastecs) #For creating descriptive statistic summaries
library(ggplot2) #For creating histograms with more detail than plot
library(psych) # Some useful descriptive functions
library(semTools) #For skewness and kurtosis
library(car) # For Levene's test for homogeneity of variance 
library(coin)# For Wilcox test (non-parametric)

########## 1. ############

temp <- c(91,56,75,68,50,39,98)
accidents <- c(2,9,7,6,6,10,1)
accTemp <- data.frame(temp, accidents)
plot(accTemp) #Negative Corelation 

########### 2. #############

before <- c(350,400,250,200,180)
after <- c(200,300,200,150,120)
t.test(before, after, paired = T, alternative = "less", conf.level = 0.99) #
#can conclude that the difference between the two paired samples are not significantly different.

##### Question 3. ######
maths <- c(50,54,56,59,60,62,61,65,67,71,71,74)
stat <- c(22,25,34,28,26,30,32,30,28,34,36,40)
scoreSet <- data.frame(maths, stat)

qqnorm(scoreSet$maths)
qqline(scoreSet$maths, col='red')
qqnorm(scoreSet$stat)
qqline(scoreSet$stat, col='blue')

shapiro.test(scoreSet$maths) #Normal
shapiro.test(scoreSet$stat) #Normal

#Pearson Correlation
stats::cor.test(scoreSet$maths, scoreSet$stat, method='pearson') #Two variables are correlated

##### Question 4. #########
heartdisease <- read_csv("heartdisease.csv")

#(a)Assess the following variables for normality
View(heartdisease)
shapiro.test(heartdisease$Chol)
qqnorm(heartdisease$Chol)
qqline(heartdisease$Chol, col='red')
hist(heartdisease$Chol)  #Not Normal, Outliers

shapiro.test(heartdisease$RestBP)
qqnorm(heartdisease$RestBP)
qqline(heartdisease$RestBP, col='red')
hist(heartdisease$RestBP) #Not Normal

shapiro.test(heartdisease$MaxHR)
qqnorm(heartdisease$MaxHR)
qqline(heartdisease$MaxHR, col='red')
hist(heartdisease$MaxHR) #NotNormal


#(b)
cor.test(heartdisease$Chol, heartdisease$RestBP, method = "kendall") #Weak Correlation

cor.test(heartdisease$Chol, heartdisease$Oldpeak, method = "kendall") #Weak

#######Question 5 #########

hepatitis <- read.table("hepatitis.data", sep = ",")
colnames(hepatitis) <- c("Class", "AGE", "SEX", "STEROID", "ANTIVIRALS",
                         "FATIGUE", "MALAISE", "ANOREXIA", "LIVER BIG", "LIVER FIRM", "SPLEN PALPABLE",
                         "SPIDERS", "ASCITES", "VARICES","BILIRUBIN","ALK PHOSPHATE", "SGOT","ALBMIN",
                         "PROTIME", "HISTOLOGY")
colnames(hepatitis) <- tolower(colnames(hepatitis))
View(hepatitis)
#Get bilirubin descriptive statistics by group
hepatitis$bilirubin <- as.numeric(hepatitis$bilirubin)
hepatitis$sgot <- as.numeric(hepatitis$sgot)
hepatitis$histology <- as.character(hepatitis$histology)
describeBy(hepatitis$bilirubin, group = hepatitis$histology, na.rm = TRUE)

describeBy(hepatitis$sgot, group = hepatitis$histology, na.rm = TRUE)

shapiro.test(hepatitis$bilirubin)
hist(hepatitis$bilirubin)


#Create data subsets
hep.pos <- subset(hepatitis, histology==1)
hep.neg <-subset(hepatitis, histology==2)

#Create plots of these
gs <- ggplot(hep.pos, aes(x=hep.pos$bilirubin))
gs <- gs + labs(x="Bilirubin - Hepatitis Positive")
gs <- gs + geom_histogram(binwidth=1, colour="black", aes(y=..density.., fill=..count..))
gs <- gs + scale_fill_gradient("Count", low="#DCDCDC", high="#7C7C7C")
gs <- gs + stat_function(fun=dnorm, color="red",args=list(mean=mean(hep.pos$bilirubin, na.rm=TRUE), sd=sd(hep.pos$bilirubin, na.rm=TRUE)))
gs

gs <- ggplot(hep.neg, aes(x=hep.neg$bilirubin))
gs <- gs + labs(x="Bilirubin - Hepatitis Negative")
gs <- gs + geom_histogram(binwidth=1, colour="black", aes(y=..density.., fill=..count..))
gs <- gs + scale_fill_gradient("Count", low="#DCDCDC", high="#7C7C7C")
gs <- gs + stat_function(fun=dnorm, color="red",args=list(mean=mean(hep.neg$bilirubin, na.rm=TRUE), sd=sd(hep.neg$bilirubin, na.rm=TRUE)))
gs

boxplot(hep.pos$bilirubin, hep.neg$bilirubin)

# Test for differences on  Histology
stats::wilcox.test (bilirubin~histology, data=hepatitis)
# less than the significance level alpha = 0.05. We can conclude that BILIRUBIN hisology 1 median is significantly different from  Histology 2's median 

#Get sgot descriptive statistics by group
describeBy(hepatitis$sgot, group = hepatitis$histology, na.rm = TRUE)
shapiro.test(hepatitis$sgot) #Not normal

stats::wilcox.test (sgot~histology, data=hepatitis) 
#greater than the significance level alpha = 0.05. We can conclude that SGOT hisology 1 median is not significantly different from SGOT Histology 2's median


#####Question 6#########

hepatitis <- read.table("hepatitis.data", sep = ",")
colnames(hepatitis) <- c("Class", "AGE", "SEX", "STEROID", "ANTIVIRALS",
                         "FATIGUE", "MALAISE", "ANOREXIA", "LIVER BIG", "LIVER FIRM", "SPLEN PALPABLE",
                         "SPIDERS", "ASCITES", "VARICES","BILIRUBIN","ALK PHOSPHATE", "SGOT","ALBMIN",
                         "PROTIME", "HISTOLOGY")
colnames(hepatitis) <- tolower(colnames(hepatitis))
hepatitis$`alk phosphate` <- as.numeric(hepatitis$`alk phosphate`)
describeBy(hepatitis$`alk phosphate`, group = hepatitis$histology, na.rm = TRUE)

#Hppothesis - Test whether Alk Phosphte is higher for people without hepatitis histology

#Create data subsets
hep.1 <- subset(hepatitis, histology==1)
hep.2 <-subset(hepatitis, histology==2)

hist(hep.1$`alk phosphate`)
hist(hep.2$`alk phosphate`)

qqnorm(hep.1$`alk phosphate`)
qqline(hep.1$`alk phosphate`, col='red')

qqnorm(hep.2$`alk phosphate`)
qqline(hep.2$`alk phosphate`, col='blue')

boxplot(hep.1$`alk phosphate`, hep.2$`alk phosphate`)

wilcox.test(hep.1$`alk phosphate`, hep.2$`alk phosphate`) #The p-value of the test is 0.0002348, which is less than the significance level alpha = 0.05.Accept

######Question 7 ########
#(i)
hepatitis$bilirubin <- as.numeric(hepatitis$bilirubin)
hepatitis$`liver firm` <- as.numeric(hepatitis$`liver firm`)
describeBy(hepatitis$bilirubin, group = hepatitis$`liver firm`, na.rm = TRUE)

livf1 <- subset(hepatitis,`liver firm`==1)
livf2 <-subset(hepatitis, `liver firm`==2)
boxplot(livf1$bilirubin, livf2$bilirubin)

hist(livf1$bilirubin)
hist(livf2$bilirubin) 

median(livf1$bilirubin, na.rm = T)
median(livf2$bilirubin, na.rm = T)

#The level of bilirubin has a smaller mean and median in those people without liver firmness, with a higher variance. 

wilcox.test(livf1$bilirubin, livf2$bilirubin, mu=0) #Reject Null Hypothesis

#(ii)
View(hepatitis)

dropped1 <- hepatitis[!(hepatitis$steroid=="?" | hepatitis$histology=='?'),]
View(dropped1)

attach(dropped1)
names(dropped1)

TAB <- table(steroid, histology)
TAB

barplot(TAB,beside=T, legend=T)
chisq.test(TAB, correct = T)