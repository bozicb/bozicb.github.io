####################################################################################
################################## Assignment 2 ####################################
############################### Leandro Pessini ####################################
####################################################################################

# loading libraries
if(!require(ggplot2)) install.packages("ggplot2")
if(!require(dplyr)) install.packages("dplyr")
if(!require(lsr)) install.packages("lsr")
if(!require(semTools)) install.packages("semTools")
if(!require(pastecs)) install.packages("pastecs")
if(!require(stats)) install.packages("stats")
if(!require(coin)) install.packages("coin")
if(!require(psych)) install.packages("psych")
if(!require(car)) install.packages("car")
if(!require(gmodels)) install.packages("gmodels")
if(!require(moments)) install.packages("moments")
if(!require(mosaic)) install.packages("mosaic")

####################################################################################
####################################################################################

# 1- A study was done in which the high daily temperature and the number of traffic
# accidents within the city were recorded. These sample data are shown as follows.
# Identify whether the data is positively correlated or negatively correlated using a scatterplot.

temp <- c(91,56,75,68,50,39,98)
accidents <- c(2,9,7,6,6,10,1)
accTemp <- data.frame(temp, accidents)

ggplot(accTemp, aes(x=accidents, y=temp)) + 
  geom_point() +
  geom_smooth(method = "lm", se = FALSE, col = "red")

# The graph shows a correlation indicating that when the Temperature decreases, the number of accidents increases.
# Accidents and Temperature are negatively correlated

####################################################################################
####################################################################################

# 2- Following data gives the readings of sugar level of 5 diabetic patient before and after
# taking insulin. Using 1% level of significance test whether insulin has reduced sugar
# level.

before <- c(350,400,250,200,180)
after <- c(200,300,200,150,120)

diabetic.patients <- data.frame(
  readings = rep(c("before", "after"), each = 5),
  sugar.level = c(before,  after)
)

group_by(diabetic.patients, readings) %>%
  summarise(
    mean = mean(sugar.level),
    sd = sd(sugar.level)
  )

# We can see that the Mean of Sugar Level after taking insulin is highly reduced but need further investigation

ggplot(diabetic.patients, aes(x=reorder(readings, -sugar.level), y=sugar.level)) +
         ylab("Sugar Level") +
         xlab("Taking Insulin") +
         geom_boxplot()
# The boxplot also shows a clear reduction in sugar level but we need to test to see if
# it is significant

# Differences of sugar level before and after taking Insulin
difference.sugar.level <- with(diabetic.patients,
                   sugar.level[readings == "before"] - sugar.level[readings == "after"])

# applying Shapiro Test for checking normality
shapiro.test(difference.sugar.level)

# The distribution of the differences are not significantly different from normal distribution,
# so we can assume normality = Shapiro p-value = 0.1264

# Sugar level average before taking insulin is greater than the sugar level
# average after taking insulin
sugar.level.tTest <- t.test(before, after, paired = TRUE, alternative = "greater", conf.level = 0.99)
sugar.level.tTest

# Calculate the eta squared for effect size
etaSquared.sugarlevel <- sugar.level.tTest$statistic[1]*sugar.level.tTest$statistic[1] / (sugar.level.tTest$statistic[1]*sugar.level.tTest$statistic[1] + sugar.level.tTest$parameter[1] )
etaSquared.sugarlevel

# Conclusion: 

# A paired-sample t-test was conducted to evaluate the impact of the insulin on sugar levels in patients
# with diabetics. There was a statistic significant decrease in sugar levels before taking insulin
# (M = 276, SD = 95.6) and after (M = 194, SD = 68.4, t(4) = 4.24, p = 0.006). 
# The mean decrease was 82 with 99% confidence level.
# The eta squared statistic (~0.82) indicated a large effect size.


####################################################################################
####################################################################################

# 3- The following dataset includes the score of students in mathematics and statistics.
# Justify with R code suitable correlation test. 
# [Hint: Check for normality and test the data for correlation]

maths <- c(50,54,56,59,60,62,61,65,67,71,71,74)
stat <- c(22,25,34,28,26,30,32,30,28,34,36,40)
scoreSet <- data.frame(maths, stat)

ggplot(scoreSet, aes(x=maths)) + 
  labs(x="Math") + 
  geom_histogram(binwidth=2, colour="black", aes(y=..density.., fill=..count..)) + 
  scale_fill_gradient("Count", low="#DCDCDC", high="#7C7C7C") + 
  stat_function(fun=dnorm, color="red", args=list(mean=mean(scoreSet$maths, na.rm=TRUE), 
                                                  sd=sd(scoreSet$maths, na.rm=TRUE)))

ggplot(scoreSet, aes(x=stat)) + 
  labs(x="Math") + 
  geom_histogram(binwidth=2, colour="black", aes(y=..density.., fill=..count..)) + 
  scale_fill_gradient("Count", low="#DCDCDC", high="#7C7C7C") + 
  stat_function(fun=dnorm, color="red", args=list(mean=mean(scoreSet$stat, na.rm=TRUE), 
                                                  sd=sd(scoreSet$stat, na.rm=TRUE)))

# The graphs are showing that probably we have normality for both variables

shapiro.test(scoreSet$maths)
shapiro.test(scoreSet$stat)
# Shapiro Test indicates Math (p-value = 0.948) and Stat (p-value = 0.9986)
# We can assume normality

pastecs::stat.desc(scoreSet$maths, basic = F)
pastecs::stat.desc(scoreSet$stat, basic = F)
# Students have an average score of 62.5 in Math
# Students in Statistic have an average score of 30.4

ggplot(scoreSet, aes(x=maths, y=stat)) + 
  geom_point() +
  geom_smooth(method=lm, color="black") +
  xlab("Math") + ylab("Statistic") +
  theme_classic()  
# The Scatterplot indicates that probably there is a correlation between them.

correlation.studentsScores <- cor.test(scoreSet$maths, scoreSet$stat, method = "pearson") # p-value = 0.002565
correlation.studentsScores
# As the p-value(0.002565) is less than the significance level 0.05 we can conclude
# that the correlation between Student's scores in Math and Stat is statistically significant
# cor 0.7835978 - strong positive correlation was found

####################################################################################
####################################################################################


# 4- Consider given dataset heartdisease.csv. Write the code to do the following.

heartdisease <- read.csv("heartdisease.csv")
str(heartdisease)

# (a) Assess the following variables for normality.
# Cholesterol (Chol)
# Blood Pressure (RestBP)
# MaxHR

#################### Cholesterol ####################

# Summary statistics
pastecs::stat.desc(heartdisease$Chol, basic = F)

ggplot(heartdisease, aes(x=Chol)) + 
  labs(x="Cholesterol") + 
  geom_histogram(binwidth=2, colour="black", aes(y=..density.., fill=..count..)) + 
  scale_fill_gradient("Count", low="#DCDCDC", high="#7C7C7C") + 
  stat_function(fun=dnorm, color="red", args=list(mean=mean(heartdisease$Chol, na.rm=TRUE), 
                                                  sd=sd(heartdisease$Chol, na.rm=TRUE)))

#Create a qqplot
qqnorm(heartdisease$Chol)
qqline(heartdisease$Chol, col=2)

# Skeweness and Kurtosis and Z score for Cholesterol
moments::skewness(heartdisease$Chol) # 1.129874
moments::kurtosis(heartdisease$Chol) # 7.398208
zChol <- mosaic::zscore(heartdisease$Chol, na.rm = T)
mean(zChol) # 2.341991e-16

#skew and kurtosis:Approaching normality if [−2, +2].
# z scores [−3.29, +3.29]
# From the tests above only Kurtosis seems to be not normal

# Normality test (Kolmogorov-Smirnov)
ks.test(heartdisease$Chol, "pnorm", mean(heartdisease$Chol), sd(heartdisease$Chol)) # p-value = 0.3103

# Conclusion (Normality):
# The graphs indicates that we probably have a normal distribution with a few outliers
# After analysing the Skeweness/Kurtosis/ZScores it also shows that Cholesterol is probably normal distributed
# Kolmogorov-Smirnov test indicates p-value (0.3103) > 0.05 so we can assume normality.


#####################  Blood Pressure ####################

# Summary statistics
pastecs::stat.desc(heartdisease$RestBP, basic = F)

ggplot(heartdisease, aes(x=RestBP)) + 
  labs(x="Cholesterol") + 
  geom_histogram(binwidth=2, colour="black", aes(y=..density.., fill=..count..)) + 
  scale_fill_gradient("Count", low="#DCDCDC", high="#7C7C7C") + 
  stat_function(fun=dnorm, color="red", args=list(mean=mean(heartdisease$RestBP, na.rm=TRUE), 
                                                  sd=sd(heartdisease$RestBP, na.rm=TRUE)))

#Create a qqplot
qqnorm(heartdisease$RestBP)
qqline(heartdisease$RestBP, col=2)

# Skeweness and Kurtosis and Z score for Blood Pressure
moments::skewness(heartdisease$RestBP) # 0.7025346
moments::kurtosis(heartdisease$RestBP) # 3.845881
zRestBP <- mosaic::zscore(heartdisease$RestBP, na.rm = T)
mean(zRestBP) # 4.477225e-16

# Normality test (Shapiro and Kolmogorov-Smirnov)
shapiro.test(heartdisease$RestBP)
ks.test(heartdisease$RestBP, "pnorm", mean(heartdisease$RestBP), sd(heartdisease$RestBP)) # p-value = 0.3103

# Conclusion (Not normal):
# The graphs indicates that we probably not have a normal distribution. Specially on the QQ Plot where
# there are a lot of points further from the line
# After analysing the Skeweness/Kurtosis/ZScores I decided to apply both tests Shapiro and KS to check.
# Shapiro test indicates p-value = 1.802e-06 and Kolmogorov-Smirnov test indicates p-value (0.003393)
# Both tests show a p-value < 0.05 so we cannot assume normality.

#####################  MaxHR #################### 

# Summary statistics
pastecs::stat.desc(heartdisease$MaxHR, basic = F)

ggplot(heartdisease, aes(x=MaxHR)) + 
  labs(x="Cholesterol") + 
  geom_histogram(binwidth=2, colour="black", aes(y=..density.., fill=..count..)) + 
  scale_fill_gradient("Count", low="#DCDCDC", high="#7C7C7C") + 
  stat_function(fun=dnorm, color="red", args=list(mean=mean(heartdisease$MaxHR, na.rm=TRUE), 
                                                  sd=sd(heartdisease$MaxHR, na.rm=TRUE)))

#Create a qqplot
qqnorm(heartdisease$MaxHR)
qqline(heartdisease$MaxHR, col=2)

# Skeweness and Kurtosis and Z score for MaxHR
moments::skewness(heartdisease$MaxHR) # -0.5347844
moments::kurtosis(heartdisease$MaxHR) # 2.927602
zMaxHR <- mosaic::zscore(heartdisease$MaxHR, na.rm = T)
mean(zMaxHR) # -1.28562e-16

# Normality test (Kolmogorov-Smirnov)
ks.test(heartdisease$MaxHR, "pnorm", mean(heartdisease$MaxHR), sd(heartdisease$MaxHR)) # p-value = 0.08566

# Conclusion (Normal):
# The graphs indicates that we probably have a normal distribution. Specially on the QQ Plot where
# the points are close to the line
# After analysing the Skeweness/Kurtosis/ZScores only Kurtosis seems out of range for normality.
# Kolmogorov-Smirnov test indicates p-value (0.08566) > 0.05 so we can assume normality.

#############################################

# (b) 

# Relationship between cholesterol and blood pressure

ggplot(heartdisease, aes(x=Chol, y=RestBP)) + 
  geom_point() +
  geom_smooth(method=lm, color="black") +
  xlab("Cholesterol") + ylab("Blood Pressure") +
  theme_classic()  

# The graph indicates maybe there is no correlation or just a very small one as the points are spread and
# the line is almost straight.

cor.test(heartdisease$Chol, heartdisease$RestBP, method = "pearson") #p-value = 0.0235
# Pearson test is showing a cor = 0.13 which indicates a weak relationship

# Because Cholesterol has a few Outliers, I decided to apply Spearman Test as well
# as it appears to handle better with outliers

cor.test(heartdisease$Chol, heartdisease$RestBP, method = "spearman") #p-value = 0.018
# rho 0.1358367 

# Conclusion
# Although the points are spread out on the ScatterPlot, the correlation tests indicate that there is
# a small/positive association between them.

#############################################
# Relationship between cholesterol and Old Peak

ggplot(heartdisease, aes(x=Chol, y=Oldpeak)) + 
  geom_point() +
  geom_smooth(method=lm, color="black") +
  xlab("Cholesterol") + ylab("Old Peak") +
  theme_classic() 

# The graph indicates that probably cholesterol and Old Peak are not correlated but need further test

cor.test(heartdisease$Chol, heartdisease$Oldpeak, method = "pearson") # p-value = 0.4193
cor.test(heartdisease$Chol, heartdisease$Oldpeak, method = "spearman") # p-value = 0.5513

# I also applied both Pearson and Spearman because of the Cholesterol outliers
# Pearson test shows cor 0.04656399
# Spearman test shows rho 0.03435936

# Conclusion
# The correlation test confirmed (correlation coefficient close to 0) that there is not a statistical
# significant association between them.

##########################################################################################################
##########################################################################################################

# 5- Investigate whether there is a difference in the people who have hepatitis and those who did not, 
# by considering the following variables.
# BILIRUBIN
# SGOT

hepatitis <- read.csv("hepatitis.data", na.strings = c("?"))
colnames(hepatitis) <- c("Class", "AGE", "SEX", "STEROID", "ANTIVIRALS",
                         "FATIGUE", "MALAISE", "ANOREXIA", "LIVER BIG", "LIVER FIRM", "SPLEN PALPABLE",
                         "SPIDERS", "ASCITES", "VARICES","BILIRUBIN","ALK PHOSPHATE", "SGOT","ALBMIN",
                         "PROTIME", "HISTOLOGY")

str(hepatitis)

hepatitis$BILIRUBIN <- as.numeric(hepatitis$BILIRUBIN)
hepatitis$SGOT <- as.numeric(hepatitis$SGOT)
hepatitis$HISTOLOGY <- as.factor(hepatitis$HISTOLOGY)

# BILIRUBIN

psych::describeBy(hepatitis$BILIRUBIN, group = hepatitis$HISTOLOGY)

# Descriptive statistics by group 
# group: 1
#   vars  n mean   sd median trimmed mad min max range skew kurtosis   se
#X1    1 80 1.14 0.74    0.9    0.98 0.3 0.4 4.6   4.2 2.69     8.05 0.08
#-------------------------------------------------------------- 
# group: 2
#   vars  n mean   sd median trimmed  mad min max range skew kurtosis   se
#X1    1 68 1.77 1.54    1.2    1.49 0.67 0.3   8   7.7 2.16     4.92 0.19

ggplot(hepatitis, aes(x=BILIRUBIN)) + 
  labs(x="Bilirubin") + 
  geom_histogram(binwidth=2, colour="black", aes(y=..density.., fill=..count..)) + 
  scale_fill_gradient("Count", low="#DCDCDC", high="#7C7C7C") + 
  stat_function(fun=dnorm, color="red", args=list(mean=mean(hepatitis$BILIRUBIN, na.rm=TRUE), 
                                                  sd=sd(hepatitis$BILIRUBIN, na.rm=TRUE)))

# The graphic clearly shows that we have a Skewed distribution for Bilirubin
# Applying test for normality only to confirm that
shapiro.test(hepatitis$BILIRUBIN)
ks.test(hepatitis$BILIRUBIN, "pnorm", mean(hepatitis$BILIRUBIN, na.rm=TRUE), sd(hepatitis$BILIRUBIN, na.rm=TRUE))

# Both tests show that we do not have normality. Shapiro p-value < 2.2e-16 and KS p-value = 3.62e-08

# Non-parametric - Skewed data
wilcox.birubilin.histology <- coin::wilcox_test(BILIRUBIN~HISTOLOGY, data = hepatitis)
wilcox.birubilin.histology # p-value = 0.001737

# Effect size
Zstat <- wilcox.birubilin.histology@statistic@teststatistic
abs(Zstat)/sqrt(length(wilcox.birubilin.histology@statistic@weights))
# 0.2574413

# Conclusion:
# Birubilin levels on patients who had hepatitis differ significantly (Mdn = 1.2) from those 
# who did not had it (Mdn = 0.9), (Z = -3.1319, p-value = 0.001737, r = .25)

#########################################################################################
# SGOT

psych::describeBy(hepatitis$SGOT, group = hepatitis$HISTOLOGY)

#Descriptive statistics by group 
# group: 1
#   vars  n  mean    sd median trimmed   mad min max range skew kurtosis   se
#X1    1 81 75.85 68.79     55   62.38 35.58  14 420   406  2.4     7.12 7.64
#-------------------------------------------------------------- 
# group: 2
#   vars  n  mean     sd median trimmed   mad min max range skew kurtosis    se
#X1    1 69 98.67 108.66     64   78.95 54.86  16 648   632  2.9    10.41 13.08

ggplot(hepatitis, aes(x=SGOT)) + 
  labs(x="SGOT") + 
  geom_histogram(binwidth=2, colour="black", aes(y=..density.., fill=..count..)) + 
  scale_fill_gradient("Count", low="#DCDCDC", high="#7C7C7C") + 
  stat_function(fun=dnorm, color="red", args=list(mean=mean(hepatitis$SGOT, na.rm=TRUE), 
                                                  sd=sd(hepatitis$SGOT, na.rm=TRUE)))

# The graphic clearly shows that we have a Skewed distribution for SGOT
# Applying test for normality only to confirm that
shapiro.test(hepatitis$SGOT)
ks.test(hepatitis$SGOT, "pnorm", mean(hepatitis$SGOT, na.rm=TRUE), sd(hepatitis$SGOT, na.rm=TRUE))

# Both tests show that we do not have normality. Shapiro p-value < 2.2e-16 and KS p-value = 1.45e-06

# Non-parametric - Skewed data
wilcox.sgot.histology <- coin::wilcox_test(SGOT ~ HISTOLOGY, data = hepatitis)
wilcox.sgot.histology # p-value = 0.3103

# Effect size
Zstat <- wilcox.sgot.histology@statistic@teststatistic
abs(Zstat)/sqrt(length(wilcox.sgot.histology@statistic@weights))
# 0.08283767 - very small effect size

# Conclusion:
# SGOT levels on patients who had hepatitis did not differ significantly (Mdn = 55) from those 
# who did not had it (Mdn = 64), (Z = -1.0146, p-value = 0.3103, r = .008)

##########################################################################################################
##########################################################################################################


# 6- Formulate a hypothesis by considering ALK PHOSPHATE levels and hepatitis histology by considering 
#hepatitis dataset. Mention whether you accept or reject the hypothesis.


# Null Hipotesis - the level of Alk Phosphate does not differ on pacients who had hepatites or not.
# Alternative Hipotesis - the level of Alk Phosphate differs on pacients who had hepatites or not.

# 1% level of significance test wheter the Alk Phosphate differ on hepatites positive pacients

hepatitis$`ALK PHOSPHATE` <- as.numeric(hepatitis$`ALK PHOSPHATE`)

qplot(x = HISTOLOGY, y = `ALK PHOSPHATE`, 
      geom = "boxplot", 
      data = hepatitis, 
      xlab = "Hepatitis", 
      ylab = "Alk Phosphate",
      fill=I("orchid4"))

# There is a clear difference in Alk Phosphate levels between those who had hepatitis and those who had not.
# The boxplot suggests that having hepatites is associated with a higher level of Alk Phosphate.

psych::describeBy(hepatitis$`ALK PHOSPHATE`, group = hepatitis$HISTOLOGY)

#Descriptive statistics by group 
# group: 1
#   vars  n  mean    sd median trimmed   mad min max range skew kurtosis   se
#X1    1 71 92.77 46.48     81   86.23 28.17  26 280   254 1.55     2.82 5.52
#-------------------------------------------------------------- 
# group: 2
#   vars  n  mean    sd median trimmed   mad min max range skew kurtosis   se
# X1    1 54 122.2 53.81  114.5  115.39 44.48  40 295   255 1.13     1.04 7.32

ggplot(hepatitis, aes(x=`ALK PHOSPHATE`)) + 
  labs(x="`ALK PHOSPHATE`") + 
  geom_histogram(binwidth=2, colour="black", aes(y=..density.., fill=..count..)) + 
  scale_fill_gradient("Count", low="#DCDCDC", high="#7C7C7C") + 
  stat_function(fun=dnorm, color="red", args=list(mean=mean(hepatitis$`ALK PHOSPHATE`, na.rm=TRUE), 
                                                  sd=sd(hepatitis$`ALK PHOSPHATE`, na.rm=TRUE)))
#Create a qqplot
qqnorm(hepatitis$`ALK PHOSPHATE`)
qqline(hepatitis$`ALK PHOSPHATE`, col=2)

# Checking normality for Alk Phosphate

# Skeweness and Kurtosis for Alk Phosphate
moments::skewness(hepatitis$`ALK PHOSPHATE`, na.rm = T) # 1.327327
moments::kurtosis(hepatitis$`ALK PHOSPHATE`, na.rm = T) # 4.832983

# Given the QQPlot and Skewness / Kurtosis we have strong indicators that the distribution is not normal

shapiro.test(hepatitis$`ALK PHOSPHATE`)
ks.test(hepatitis$`ALK PHOSPHATE`, "pnorm", mean(hepatitis$`ALK PHOSPHATE`, na.rm=TRUE), sd(hepatitis$`ALK PHOSPHATE`, na.rm=TRUE))

# The Shapiro Test and KS Test confirmed that the Alk Phosphate distribution is not normal
# Shapiro-Wilk normality test -  p-value = 4.11e-08
# Kolmogorov-Smirnov test - p-value = 0.000465

coin::wilcox_test(`ALK PHOSPHATE`~HISTOLOGY, data = hepatitis, conf.int = T, conf.level = 0.99)

# We can reject the Null Hiposthesis p-value 0.0002467 and conclude that with 1% signifcance level that
# the level of Alk Phosphate it does differ on pacients who had hepatites or not.
# Z = -3.6656, p-value = 0.0002467, difference in location -27 

#########################################################################################################
#########################################################################################################

# 7- Investigate the following questions by considering the Hepatitis dataset.

# Does Bilirubin level impact the Liver Firm?

hepatitis$`LIVER FIRM` <- as.factor(hepatitis$`LIVER FIRM`)

psych::describeBy(hepatitis$BILIRUBIN, group = hepatitis$`LIVER FIRM`)

#Descriptive statistics by group 
# group: 1
#   vars  n mean   sd median trimmed  mad min max range skew kurtosis   se
#X1    1 59 1.49 1.01    1.2    1.34 0.74 0.3 4.8   4.5 1.51     1.93 0.13
#-------------------------------------------------------------- 
# group: 2
#   vars  n mean   sd median trimmed  mad min max range skew kurtosis   se
#X1    1 80 1.34 1.33      1    1.01 0.44 0.4   8   7.6 3.39    12.29 0.15

# BILIRUBIN is not normally distributed

hepatitis.clean <- hepatitis[!is.na(hepatitis$`LIVER FIRM`),]
qplot(x = na.omit(`LIVER FIRM`), y = BILIRUBIN, 
      geom = "boxplot", 
      data = hepatitis.clean, 
      xlab = "LIVER FIRM", 
      ylab = "BILIRUBIN",
      fill=I("orchid4"))


wilcox.bilirubin.liver <- coin::wilcox_test(BILIRUBIN~`LIVER FIRM`, data = hepatitis)
wilcox.bilirubin.liver
# Wilcoxon-Mann-Whitney Test
# Z = 1.7192, p-value = 0.08559

# Effect size
Zstat <- wilcox.bilirubin.liver@statistic@teststatistic
abs(Zstat)/sqrt(length(wilcox.bilirubin.liver@statistic@weights))
# 0.08283767 - small effect size

# Conclusion
# Birubilin levels does not have a significantly difference on Liver Firm. 
# Median Liver Firm No - 1.2
# Median Liver Firm Yes - 1

# Wilcox Test shows p-value = 0.08559
# With a small effect r =.08

#########################################################################################################

# Are there any differences in steroid level and hepatitis histology?

# Contingency table for Steroid Levels and Histology
table.steroid.histology <- table(hepatitis$STEROID, hepatitis$HISTOLOGY)
prop.table(table.steroid.histology)

total_row <- margin.table(table.steroid.histology, 2)
total_col <- margin.table(table.steroid.histology, 1)
final_table <- rbind(cbind(table.steroid.histology, total_col), c(total_row, sum(total_col)))
dimnames(final_table)[[1]][3] <- "total_row"
final_table

#           1  2 total_col
#1         37 38        75
#2         46 32        78
#total_row 83 70       153

# It does not show us any visible impact analysing the contigency table.

gmodels::CrossTable(hepatitis$STEROID, hepatitis$HISTOLOGY, fisher = T)
# Using Fisher T because is more indicated for 2 x 2 tables

# The null hypothesis is that the relative proportions of one variable are independent of the second variable; 
# in other words, the proportions at one variable are the same for different values of the second variable

# Conclusion
# p =  0.2582783 - > 0.05 significance level
# There is not enough evidence to reject the Null hypotesis and therefore, indicating that there is not a 
# statistically significant difference on People who took or not Steroids with people who had or Hepatitis
