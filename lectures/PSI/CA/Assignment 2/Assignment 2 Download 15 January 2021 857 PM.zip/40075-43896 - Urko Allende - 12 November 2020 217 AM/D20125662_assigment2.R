library(pastecs) #For creating descriptive statistic summaries
library(ggplot2) #For creating histograms with more detail than plot
library(psych) # Some useful descriptive functions
library(semTools) #For skewness and kurtosis
library(car) # For Levene's test for homogeneity of variance 
library(coin)# For Wilcox test (non-parametric)
library(ggpubr)
library(dplyr)
library(gmodels)

path <- 'D:/Data Science MsC/Statistics/Assignment 2/Datasets/'
getwd()


###########
## 1.Identify whether the data is positively correlated or negatively correlated using a scatterplot. 
#####################################################################################################
temp <- c(91,56,75,68,50,39,98)
accidents <- c(2,9,7,6,6,10,1)
accTemp <- data.frame(temp, accidents)

scatter <- ggplot(accTemp, aes(temp, accidents))
scatter + geom_point() + labs(x = "Temperature", y = "Traffic Accidents") 

# Answer: The data is negatively correlated

###########
## 2. Using 1% level of significance test whether insulin has reduced sugar level.
#################################################################################
before <- c(350,400,250,200,180)
after <- c(200,300,200,150,120)

#H0 - blood sugar levels are equal before and after insulin - before = after
#Ha - blood sugar levels are not equal before and after insulin before > after

t.test(before, after, paired=TRUE)
# Answer: With 1% level of significance we accept the null hypothesis and consider the mean of both samples is the same

# It is not clear from the sample values (small sample size) whether the data is normally distributed. 
# Accidentally, both parametric and non-parametric tests confirm the null hypothesis with a 1% level of significance
# wilcox.test(before ,after, paired=TRUE)

###########
## 3. Justify with R code suitable correlation test.
####################################################
maths <- c(50,54,56,59,60,62,61,65,67,71,71,74)
stats <- c(22,25,34,28,26,30,32,30,28,34,36,40)
scoreSet <- data.frame(maths, stat)

scatter <- ggplot(scoreSet, aes(maths, stat))
scatter + geom_point() + labs(x = "Math", y = "Stats") 

### Assessing if Maths is normally distributed
#skewness and kurtosis for maths
math_skew<-semTools::skew(maths)
math_kurt<-semTools::kurtosis(maths)
#We divide the skew statistic by the standard error to get the standardised score
math_skew[1]/math_skew[2] #satisfies normal dist
math_kurt[1]/math_kurt[2] #satisfies normal dist

qqnorm(maths) 
qqline(maths, col=2) #satisfies normal dist

ggqqplot(maths) #satisfies normal dist
shapiro.test(maths) #satisfies normal dist

### Assessing if Stats is normally distributed
#skewness and kurtosis for stats
stats_skew<-semTools::skew(stats)
stats_kurt<-semTools::kurtosis(stats)
#We divide the skew statistic by the standard error to get the standardised score
stats_skew[1]/stats_skew[2] #satisfies normal dist
stats_kurt[1]/stats_kurt[2] #satisfies normal dist

qqnorm(stats)
qqline(stats, col=2) #satisfies normal dist

ggqqplot(stats) #satisfies normal dist
shapiro.test(stats) #satisfies normal dist

#Pearson Correlation
stats::cor.test(maths, stats, method='pearson')

###########
## 4. 
#################################################################################

#a. Assess the variables for normality
heartdisease <- read.csv('D:/Data Science MsC/Statistics/Assignment 2/Datasets/heartdisease.csv')

#Cholesterol
stat.desc(Cholesterol, basic=F)
Cholesterol <- heartdisease$Chol

gs <- ggplot(heartdisease, aes(x = Chol))
gs <- gs + labs(x="Cholesterol")
gs <- gs + geom_histogram(binwidth=2, colour="black", aes(y=..density.., fill=..count..))
gs <- gs + scale_fill_gradient("Count", low="#DCDCDC", high="#7C7C7C")
gs <- gs + stat_function(fun=dnorm, color="red",args=list(mean=mean(heartdisease$Chol, na.rm=TRUE), sd=sd(heartdisease$Chol, na.rm=TRUE)))
gs

plot(density(Cholesterol))
ggqqplot(Cholesterol) # shows a few cholesterol readings out of normal a normal dist

#skewness and kurtosis for stats
chol_skew <- semTools::skew(Cholesterol)
chol_kurt <- semTools::kurtosis(Cholesterol)
#We divide the skew statistic by the standard error to get the standardised score
chol_skew[1]/chol_skew[2] # does not satisfy normal dist
chol_kurt[1]/chol_kurt[2] # does not satisfy normal dist

shapiro.test(Cholesterol) # rejects the null hypothesis, hence is not normal - more anaylsis required

#### Check impact of outliers for Cholesterol
scaled_chol <- sort(scale(Cholesterol)) %>% 
  as.data.frame() 

within_3.96 <- scaled_chol %>%
 filter(scaled_chol$. < 3.29 & scaled_chol$. > -3.29)

print((length(scaled_chol[,1]) - length(within_3.96[,1]))/ length(scaled_chol[,1]))
# only 0.33% of the values are outside the the +/- 3.29 bands, hence we can treat the distribution as normal

#Blood Pressure

RestBP <- heartdisease$RestBP
stat.desc(RestBP, basic=F)

gs <- ggplot(heartdisease, aes(x = RestBP))
gs <- gs + labs(x="Blood Pressure")
gs <- gs + geom_histogram(binwidth=2, colour="black", aes(y=..density.., fill=..count..))
gs <- gs + scale_fill_gradient("Count", low="#DCDCDC", high="#7C7C7C")
gs <- gs + stat_function(fun=dnorm, color="red",args=list(mean=mean(heartdisease$RestBP, na.rm=TRUE), sd=sd(heartdisease$RestBP, na.rm=TRUE)))
gs

plot(density(RestBP))
ggqqplot(RestBP) # shows a few cholesterol readings out of normal a normal dist

#skewness and kurtosis for stats
RestBP_skew <- semTools::skew(RestBP)
RestBP_kurt <- semTools::kurtosis(RestBP)
#We divide the skew statistic by the standard error to get the standardised score
RestBP_skew[1]/RestBP_skew[2] # does not satisfy normal dist
RestBP_kurt[1]/RestBP_kurt[2] # does not satisfy normal dist

shapiro.test(RestBP) # rejects the null hypothesis, hence is not normal - more anaylsis required

#### Check impact of outliers for Cholesterol
scaled_restPB <- sort(scale(RestBP)) %>% 
  as.data.frame() 

restBP_within_3.96 <- scaled_restPB %>%
  filter(scaled_restPB$. < 3.29 & scaled_restPB$. > -3.29)

print((length(scaled_restPB[,1]) - length(restBP_within_3.96[,1]))/ length(scaled_restPB[,1]))
# only 0.66% of the values are outside the the +/- 3.29 bands, hence we can treat the distribution as normal

#MaxHR
MaxHR <- heartdisease$MaxHR
stat.desc(MaxHR, basic=F)

gs <- ggplot(heartdisease, aes(x = RestBP))
gs <- gs + labs(x="Max HR")
gs <- gs + geom_histogram(binwidth=2, colour="black", aes(y=..density.., fill=..count..))
gs <- gs + scale_fill_gradient("Count", low="#DCDCDC", high="#7C7C7C")
gs <- gs + stat_function(fun=dnorm, color="red",args=list(mean=mean(heartdisease$MaxHR, na.rm=TRUE), sd=sd(heartdisease$MaxHR, na.rm=TRUE)))
gs

plot(density(MaxHR))
ggqqplot(MaxHR) # shows a few cholesterol readings out of normal a normal dist

#skewness and kurtosis for stats
MaxHR_skew <- semTools::skew(MaxHR)
MaxHR_kurt <- semTools::kurtosis(MaxHR)
#We divide the skew statistic by the standard error to get the standardised score
MaxHR_skew[1]/MaxHR_skew[2] # does not satisfy normal dist
MaxHR_kurt[1]/MaxHR_kurt[2] # does satisfy normal dist

shapiro.test(RestBP) # rejects the null hypothesis, hence is not normal - more anaylsis required

#### Check impact of outliers for Cholesterol
scaled_MaxHR <- sort(scale(MaxHR)) %>% 
  as.data.frame() 

MaxHR_within_3.96 <- scaled_MaxHR %>%
  filter(scaled_MaxHR$. < 3.29 & scaled_MaxHR$. > -3.29)

print((length(scaled_MaxHR[,1]) - length(MaxHR_within_3.96[,1]))/ length(scaled_MaxHR[,1]))
# only 0.33% of the values are outside the the +/- 3.29 bands, hence we can treat the distribution as normal

#b. Relationship between cholesterol and blood pressure
scatter <- ggplot(heartdisease, aes(Chol, RestBP))
scatter + geom_point() + labs(x = "Cholesterol", y = "RestBP") 
scatter + geom_point() + geom_smooth(method = "lm", colour = "Red", se = F) + labs(x = "Cholesterol", y = "RestBP") 

# Pearson seems appropriate to study the correlation between this variables as they are close to be normally distributed
# However, is worth nothing that the linear relationship and the homoscedasticity are hard to assess visually

stats::cor.test(heartdisease$Chol, heartdisease$RestBP, method='pearson')
  
#b. Relationship between cholesterol and old peak

ggqqplot(heartdisease$Oldpeak) #not normally distributed

scatter <- ggplot(heartdisease, aes(Chol, Oldpeak))
scatter + geom_point() + labs(x = "Cholesterol", y = "Old peak") 
scatter + geom_point() + geom_smooth(method = "lm", colour = "Red", se = F) + labs(x = "Cholesterol", y = "Old peak") 

# This plot does not meet homoscedasticity and a non-parametric method is required
# Also Old peak is not normally distributed
stats::cor.test(heartdisease$Chol, heartdisease$Oldpeak, method='spearman')
stats::cor.test(heartdisease$Chol, heartdisease$Oldpeak, method='kendall')

###########
## 5. Consider if there's difference between people with hepatitis or not
#################################################################################

hepatitis <- read.csv('D:/Data Science MsC/Statistics/Assignment 2/Datasets/hepatitis.data', sep = ",", 
                      na.strings = "?")
#To add headers

colnames(hepatitis) <- c("Class", "AGE", "SEX", "STEROID", "ANTIVIRALS",
                         "FATIGUE", "MALAISE", "ANOREXIA", "LIVER BIG", "LIVER FIRM", "SPLEN PALPABLE",
                         "SPIDERS", "ASCITES", "VARICES","BILIRUBIN","ALK PHOSPHATE", "SGOT","ALBMIN",
                         "PROTIME", "HISTOLOGY")

hepatitis$SGOT <- as.numeric(hepatitis$SGOT)
hepatitis$BILIRUBIN <- as.numeric(hepatitis$BILIRUBIN)
hepatitis$HISTOLOGY <- as.character(hepatitis$HISTOLOGY)

df_question5 <- hepatitis %>%
  select(15, 17,20)

df_question5 <- df_question5[complete.cases(df_question5), ]

#Check normality of the distributions
boxplot(df_question5$SGOT ~ df_question5$HISTOLOGY)
boxplot(df_question5$BILIRUBIN ~ df_question5$HISTOLOGY)

ggqqplot(df_question5$SGOT) # does not conform to a normal distribution
ggqqplot(df_question5$BILIRUBIN) # does not conform to a normal distribution

plot(density(df_question5$SGOT)) # does not conform to a normal distribution
plot(density(df_question5$BILIRUBIN)) # does not conform to a normal distribution

shapiro.test(df_question5$SGOT) # rejects the null hypothesis - distribution is not normal
shapiro.test(df_question5$BILIRUBIN) # rejects the null hypothesis - distribution is not normal

# Conclusion: Data is non-parametric

# Mann Whitney U test
wilcox.test(df_question5$SGOT ~ df_question5$HISTOLOGY) # accepts the null hypothesis that the median does not differ 
wilcox.test(df_question5$BILIRUBIN ~ df_question5$HISTOLOGY) # rejects the null hypothesis that the median is equal

###########
## 6. Formulate a hypothesis by considering ALK PHOSPHATE
#########################################################

#Ho: ALK PHOSPHATE is equal for groups with hepatitis or without it (Histology)

df_question6 <- hepatitis %>%
  select(16, 20)

df_question6 <- df_question6[complete.cases(df_question6), ]

#Check normality of the distribution
boxplot(df_question6$`ALK PHOSPHATE` ~ df_question6$HISTOLOGY)
ggqqplot(df_question6$`ALK PHOSPHATE`) # does not conform to a normal distribution
plot(density(df_question6$`ALK PHOSPHATE`)) # does not conform to a normal distribution
shapiro.test(df_question6$`ALK PHOSPHATE`) # rejects the null hypothesis - distribution is not normal
ALK <- as.data.frame(sort(scale(df_question6[,1]))) 

#Skewness and Kurtosis
ALK_skew <- semTools::skew(MaxHR)
ALK_kurt <- semTools::kurtosis(MaxHR)
#We divide the skew statistic by the standard error to get the standardised score
ALK_skew[1]/ALK_skew[2] # does not satisfy normal dist
ALK_kurt[1]/ALK_kurt[2] # does satisfy normal dist

#Z-scores ([???3.29,+3.29] for sample size ???80) - for each 
ALK_3.29 <- ALK %>%
  filter(ALK[,1] < 3.29 & ALK[,1] > -3.29)

print((length(ALK[,1]) - length(ALK_3.29[,1]))/ length(ALK[,1])) # only 1.6% of the values are outside -/+ 2.5. We can treat it as normal 

# Homogeneity
df_question6$HISTOLOGY <- as.character(df_question6$HISTOLOGY)
leveneTest(df_question6$`ALK PHOSPHATE` ~ df_question6$HISTOLOGY) # we accept the null hypothesis - data is homogeneous

# T.Test - since the data is normally distributed and homogeneous 
t.test(df_question6$`ALK PHOSPHATE` ~ df_question6$HISTOLOGY, var.equal = TRUE) # we reject the null hypothesis Ho

#Conclusion: the mean of both groups is not equal

###########
## 7.  Investigate the following questions by considering the Hepatitis dataset.
###############################################################################

#a. Does Bilirubin level impact the Liver Firm?
df_question7a <- hepatitis %>%
  select(10, 15)

df_question7a <- df_question7a[complete.cases(df_question7a), ]

boxplot(df_question7a$BILIRUBIN ~ df_question7a$`LIVER FIRM`)

# Homogeneity
df_question7a$`LIVER FIRM` <- as.character(df_question7a$`LIVER FIRM`)
leveneTest(df_question7a$BILIRUBIN ~ df_question7a$`LIVER FIRM`) # we accept the null hypothesis - data is homogeneous

# T.Test - since the data is normally distributed and homogeneous 
t.test(df_question7a$BILIRUBIN ~ df_question7a$`LIVER FIRM`, var.equal = TRUE) # we accept the null hypothesis Ho
#Conclusion: No significant difference in the scores for bilirubin levels was found in relation to Liver Firm - we assume no impact

# b.Are there any differences in steroid level and hepatitis histology?
#Ho: the distribution across steroid level and histology are equal

df_question7b <- hepatitis %>%
  select(4, 20)

df_question7b <- df_question7b[complete.cases(df_question7b), ]

library(gmodels)
gmodels::CrossTable(df_question7b$STEROID, df_question7b$HISTOLOGY, fisher = TRUE, chisq = TRUE, 
                    expected = TRUE, sresid = TRUE, format = "SPSS")

#Conclusion: we reject the null hypothesis, frequencies are not equal

