#Assignment 2 - MATH 9102 Prob & Stats
#D20125665 - Laura Smith
#16/10/2020"


##Relevant Library Install & Import for Assignment 2:
if(!require(pastecs))install.packages("pastecs")
if(!require(ggplot2))install.packages("ggplot2")
if(!require(psych))install.packages("psych")
if(!require(semTools))install.packages("semTools")
if(!require(car))install.packages("car")
if(!require(coin))install.packages("coin")
if(!require(imputeTS))install.packages("imputeTS")
if(!require(gmodels))install.packages("gmodels")

library(pastecs) #Descriptive Stat Summaries
library(ggplot2) #For Graphs & Histograms
library(psych) # Descriptive functions
library(semTools) #For skewness and kurtosis
library(car) # For Levene's test for homogeneity of variance
library(coin)# For Wilcox test (non-parametric)
library(imputeTS) #To replace nas with the mean
library(gmodels) # For chi test



###QUESTION 1 

#Create dataframe
temp <- c(91,56,75,68,50,39,98)
accidents <- c(2,9,7,6,6,10,1)
accTemp <- data.frame(temp, accidents)

#Scatter plot comparing daily temperature high and number of traffic accidents with best fit line in blue
scatterTA <- ggplot(accTemp, aes(accidents, temp)) + geom_point() 
scatterTA <- scatterTA + labs(x = "Number of Accidents", y = "Temperature") + geom_smooth(method=lm, se=FALSE)
scatterTA

##ANSWER: The data is negatively correlated.  



###QUESTION 2

#Create dataframe
before <- c(350,400,250,200,180)
after <- c(200,300,200,150,120)
sugarLevs <- data.frame(before, after)
#Add patient number in order to create graph comparing levels per patient.
sugarLevs$patient <- 1:nrow(sugarLevs)
#Display datframe to check new column has been added correctly
sugarLevs

#Visual representation of the two groups of data, sugar levels before and after each patient had taken insulin.
#This visually shows that all of the points in the "After Insulin" dataset for each patient are higher than the "before" sugar levels.
plotSL <- ggplot(sugarLevs, aes(x=patient)) + geom_point(aes(y = before, color = "red")) + geom_point(aes(y=after, color = "blue"))
plotSL <- plotSL + labs(x = "Patient Numbers", y = "Insulin Level") 
plotSL <- plotSL + scale_color_manual(labels = c("Before Insulin", "After Indsulin"), values = c("red", "blue")) + theme(legend.title = element_blank())
plotSL

#Scatter plot showing the relationship in sugar levels before and after insulin 
#Visually shows the data to be correlated positively
scatterSL <- ggplot(sugarLevs, aes(before, after)) + geom_point() 
scatterSL <- scatterSL + labs(x = "Sugar Level Before Insulin", y = "Sugar Level After Insulin") + geom_smooth(method=lm, se=FALSE)
scatterSL

#Pearson correlation test to test linear correlation
cor.test(sugarLevs$before, sugarLevs$after, method = "pearson")

## r = 0.9 indicating a strong positive ocrrelation



###QUESTION 3

#Create dataframe
maths <- c(50,54,56,59,60,62,61,65,67,71,71,74)
stat <- c(22,25,34,28,26,30,32,30,28,34,36,40)
scoreSet <- data.frame(maths, stat)


##ANALYSIS OF MATHS SCORES
#Describe data to get a feel for the shape of the maths group in the dataframe scoreSet
pastecs::stat.desc(scoreSet$maths, basic=F)

#Test for Skew & Kutosis of Maths scores
semTools::skew(scoreSet$maths)
semTools::kurtosis(scoreSet$maths)
#Skew of "maths" is ~-0.02 which is within the standardised scores to prove normal distributuon.
#Kurtosis of "maths" is ~-0.57 which is within the standardised scores to prove normal distributuon.

# Plot histogram to visually inspect the normality of the maths data
gM <- ggplot(scoreSet, aes(x=maths)) + geom_histogram(binwidth = 5, colour = "black", fill = "light blue")
gM <- gM + labs(x="Maths Score", y = "Number of Students") 
gM <- gM + stat_function(fun = function(x) (dnorm(x, mean = mean(maths, na.rm=TRUE), sd = sd(maths, na.rm=TRUE)) * 50), colour = "blue", size = 1)
gM
#Histogram visually shows a fairly normal distribution of "maths". 

#Run Q-Q plot for maths
qqnorm(scoreSet$maths)
qqline(scoreSet$maths, col=2)
#Also confirms normality of Maths scores.


##ANALYSIS OF STATISTICS SCORES
#Describe data to get a feel for the shape of the stat group in the dataframe scoreSet
pastecs::stat.desc(scoreSet$stat, basic=F)

#Test for Skew & Kutosis of Statistic scores
semTools::skew(scoreSet$stat)
semTools::kurtosis(scoreSet$stat)
#Skew of "stat" is ~0.33 which is within the standardised scores to prove normal distributuon.
#Kurtosis of "stat" is ~-0.15 which is within the standardised scores to prove normal distributuon.

# Plot histogram to visually inspect the normality of the stat data
gS <- ggplot(scoreSet, aes(x=stat)) + geom_histogram(binwidth=5, colour="black", fill = "pink")
gS <- gS + labs(x="Statistics Score", y = "Number of Students")
gS <- gS + stat_function(fun = function(x) (dnorm(x, mean = mean(stat, na.rm=TRUE), sd = sd(stat, na.rm=TRUE)) * 50), colour = "red", size = 1)
gS
#Histogram visually shows a normal distribution of "stat" also. 

#Run Q-Q plot for stat
qqnorm(scoreSet$stat)
qqline(scoreSet$stat, col=2)
#Also confirms normality of Statistics scores.


##TEST CORRELATION BETWEEN MATHS SCORES AND STATISTICS SCORES

#Scatter plot to visually test correlation including best fit line
scatterMS <- ggplot(scoreSet, aes(maths, stat)) + geom_point() 
scatterMS <- scatterMS + labs(x = "Score in Maths", y = "Score in Statistics") + geom_smooth(method=lm, se=FALSE)
scatterMS
#Data looks to be positively correlated 

#Since the data has been proven to be normally distributed, a Pearson correlation test is appropriate.
#Pearson Correlation
stats::cor.test(scoreSet$maths, scoreSet$stat, method='pearson')
#The Correlation Coefficient is ~ 0.78 and the p-value is close to zero showing a strong correlation.



###QUESTION 4

#read in heartdisease CSV and store as adataframe
heartdisease <- read.csv("heartdisease.csv")

## PART (a)


#ANALYSIS OF CHOLESTEROL
#Show summary stats for the dataset to get a feel for its shape
summary(heartdisease)
pastecs::stat.desc(heartdisease$Chol, basic=F)

#Test for Skew & Kutosis of Cholesterol
semTools::skew(heartdisease$Chol)
semTools::kurtosis(heartdisease$Chol)
#Skew of 8.07 which is outside the standardised scores to prove normal distribution and is a high level of skew.
#Kurtosis of 15.96 which is outside the standardised scores to prove normal distribution and is a high level of kurtosis.

#Histogram to visually inspect normality of data
gCh <- ggplot(heartdisease, aes(x=heartdisease$Chol)) + geom_histogram(binwidth=25, colour="black", fill = "light blue")
gCh <- gCh + labs(x="Cholesterol", y = "Number of Patients") 
gCh <- gCh + stat_function(fun = function(x) (dnorm(x, mean = mean(heartdisease$Chol, na.rm=TRUE), sd = sd(heartdisease$Chol, na.rm=TRUE)) * 5000), colour = "blue", size = 1)
gCh
#Shows skewed distribution

#Run Q-Q plot for cholesterol
qqnorm(heartdisease$Chol)
qqline(heartdisease$Chol, col=2)
#Q-Q plot highlights skewedness of data


#ANALYSIS OF REST BLOOD PRESSURE
#Show summary stats for the dataset to get a feel for its shape
pastecs::stat.desc(heartdisease$RestBP, basic=F)

#Test for Skew & Kutosis of resting blood pressure
semTools::skew(heartdisease$RestBP)
semTools::kurtosis(heartdisease$RestBP)
#Skew of 5.02 which is outside the standardised scores to prove normal distribution and a small level of skew.
#Kurtosis of 3.12 which is outside the standardised scores to prove normal distribution and a small level of skew.

#Histogram to visually inspect normality of data
gBP <- ggplot(heartdisease, aes(x=RestBP)) + geom_histogram(binwidth=10, colour="black", fill = "pink")
gBP <- gBP + labs(x="Resting BP", y = "Number of Patients") 
gBP <- gBP + stat_function(fun = function(x) (dnorm(x, mean = mean(heartdisease$RestBP, na.rm=TRUE), sd = sd(heartdisease$RestBP, na.rm=TRUE)) * 2500), colour = "red", size = 1)
gBP
#Shows slight skewedness of data

#Run Q-Q plot for RestBP
qqnorm(heartdisease$RestBP)
qqline(heartdisease$RestBP, col=2)
#Q-Q plot shows skewedness of data


#ANALYSIS OF REST MAXIMUM HEART RATE
#Show summary stats for the dataset to get a feel for its shape
pastecs::stat.desc(heartdisease$MaxHR, basic=F)

#Test for Skew & Kutosis of Maximum heart rate
semTools::skew(heartdisease$MaxHR)
semTools::kurtosis(heartdisease$MaxHR)
#Skew of -3.82 which is outside the standardised scores to prove normal distribution and a small level of skew.
#Kurtosis of -0.19 which is outside the standardised scores to prove normal distribution and a small level of skew.

#Histogram to visually inspect normality of data
gHR <- ggplot(heartdisease, aes(x=heartdisease$MaxHR)) + geom_histogram(binwidth=10, colour="black", fill = "light yellow")
gHR <- gHR + labs(x="Maximum Heart Rate", y = "Number of Patients") 
gHR <- gHR + stat_function(fun = function(x) (dnorm(x, mean = mean(heartdisease$MaxHR, na.rm=TRUE), sd = sd(heartdisease$MaxHR, na.rm=TRUE)) * 2500), colour = "orange", size = 1)
gHR
#Histogram visually shows skewedness

#Run Q-Q plot for RestBP
qqnorm(heartdisease$MaxHR)
qqline(heartdisease$MaxHR, col=2)
#Q-Q plot shows skewedness of data


#PART (b)

#As the data analyses above all show non- normal, skewed distributions of data,
#Spearmen/Kendall is the most appropriate correlation tool here.

#Correlation test to show relationship between cholesterol and blood pressure:
cor.test(heartdisease$Chol, heartdisease$RestBP, method = "kendall")
cor.test(heartdisease$Chol, heartdisease$RestBP, method = "spearman")

#Correlation test to show relationship between cholesterol and old peak:
cor.test(heartdisease$Chol, heartdisease$Oldpeak, method = "kendall")
cor.test(heartdisease$Chol, heartdisease$Oldpeak, method = "spearman")



###QUESTION 5


#Read in hepatitis dataset to dataframe, substituting question marks with NAs
hepatitis <- read.csv("hepatitis.data", na.strings = c('?'))
#Replace NAs with the mean for that column so these don't affect statistical analysis 
na_mean(hepatitis)
#Add gheaders to dataframe
colnames(hepatitis) <- c("Class", "AGE", "SEX", "STEROID", "ANTIVIRALS",
                         "FATIGUE", "MALAISE", "ANOREXIA", "LIVER BIG", "LIVER FIRM", "SPLEN PALPABLE",
                         "SPIDERS", "ASCITES", "VARICES","BILIRUBIN","ALK PHOSPHATE", "SGOT","ALBMIN",
                         "PROTIME", "HISTOLOGY")


##DIFFERENCE IN BILURUBIN LEVEL BETWEEN THOSE WHO DO AND DON'T HAVE HEPATITIS

#Show summary stats for the Bilirubin dataset based on histology (i.e. whether the patient has hepatitis)
describeBy(hepatitis$BILIRUBIN, group = hepatitis$HISTOLOGY)
#Show number of patients in group who do have hepatitis and who don't
table(hepatitis$HISTOLOGY)

#Test for Skew & Kutosis of Bilirubin levels
skewB <- semTools::skew(hepatitis$BILIRUBIN)
kurtB <- semTools::kurtosis(hepatitis$BILIRUBIN)
#We divide the skew statistic by the standard error to get the standardised score
skewB[1]/skewB[2]
kurtB[1]/kurtB[2]
#Skew is 14.23 and Kurtosis is 25.19 which both show a high level of skew.

#Histogram to visually inspect normality of the data
gBR <- ggplot(hepatitis, aes(x=hepatitis$BILIRUBIN)) + geom_histogram(binwidth=0.2, colour="black", fill = "light blue")
gBR <- gBR + labs(x="BILIRUBIN Level", y = "Number of Patients") 
gBR <- gBR + stat_function(fun = function(x) (dnorm(x, mean = mean(hepatitis$BILIRUBIN, na.rm=TRUE), sd = sd(hepatitis$BILIRUBIN, na.rm=TRUE)) * 75), colour = "blue", size = 1)
gBR
#Histogram visually shows a skewed distribution of BILIRUBIN.

#Summarize bilirubin data base on two groups, those with and without hepatitis
psych::describeBy(hepatitis$BILIRUBIN, group=hepatitis$HISTOLOGY)
table(hepatitis$HISTOLOGY)

#The Wilcox test is appropriate to test difference based on th analysis above
stats::wilcox.test(BILIRUBIN ~ HISTOLOGY, data=hepatitis) 

#The p value form this test is very close to zero which indicates no difference in the two groups with relation to BILIRUBIN.



##DIFFERENCE IN SGOT LEVEL BETWEEN THOSE WHO DO AND DON'T HAVE HEPATITIS

#Show summary stats for the SGOT dataset based on histology (i.e. whether the patient has hepatitis)
describeBy(hepatitis$SGOT, group = hepatitis$HISTOLOGY)
table(hepatitis$HISTOLOGY)

#Test for Skew & Kutosis of SGOT levels
skewS <- semTools::skew(hepatitis$SGOT)
kurtS <- semTools::kurtosis(hepatitis$SGOT)
#We divide the skew statistic by the standard error to get the standardised score
skewS[1]/skewS[2]
kurtS[1]/kurtS[2]
#Skew is 15.87 and Kurtosis is 34.93 which both show a high level of skew.

#Histogram to visually inspect normality of the data
gSG <- ggplot(hepatitis, aes(x=hepatitis$SGOT)) + geom_histogram(binwidth=25, colour="black", fill = "darkseagreen1")
gSG <- gSG + labs(x="SGOT Level", y = "Number of Patients") 
gSG <- gSG + stat_function(fun = function(x) (dnorm(x, mean = mean(hepatitis$SGOT, na.rm=TRUE), sd = sd(hepatitis$SGOT, na.rm=TRUE)) * 10000), colour = "forestgreen", size = 1)
gSG
#Histogram visually shows a skewed distribution of SGOT.

#Summarize bilirubin data base on two groups, those with and without hepatitis
psych::describeBy(hepatitis$SGOT, group=hepatitis$HISTOLOGY)
table(hepatitis$HISTOLOGY)

#The Wilcox test is appropriate to test difference based on th analysis above
stats::wilcox.test(SGOT ~ HISTOLOGY, data=hepatitis) 

#The p value form this test is 0.3 which indicates little difference in the two groups with relation to SGOT.



###QUESTION 6

#HYPOTHESIS: ALK PHOSPHATE levels are higher for patients who have hepatitis.

#Show summary stats for the dataset to get a feel for its shape
summary(hepatitis$'ALK PHOSPHATE')

psych::describeBy(hepatitis$`ALK PHOSPHATE`, group = hepatitis$HISTOLOGY)
table(hepatitis$HISTOLOGY)

pastecs::stat.desc(hepatitis$`ALK PHOSPHATE`, basic=F)
semTools::skew(hepatitis$`ALK PHOSPHATE`)
semTools::kurtosis(hepatitis$`ALK PHOSPHATE`)
#Skew of "maths" is ~6.13 which is not within the standardised scores to prove normal distributuon.
#Kurtosis of "maths" is ~4.46 which is not within the standardised scores to prove normal distributuon.

#Histogram to visually inspect normality of the data
gAP <- ggplot(hepatitis, aes(x=hepatitis$`ALK PHOSPHATE`)) + geom_histogram(binwidth=10, colour="black", fill = "thistle")
gAP <- gAP + labs(x="AlK Phosphate", y = "Number of Patients") 
gAP <- gAP + stat_function(fun = function(x) (dnorm(x, mean = mean(hepatitis$`ALK PHOSPHATE`, na.rm=TRUE), sd = sd(hepatitis$`ALK PHOSPHATE`, na.rm=TRUE)) * 2500), colour = "purple", size = 1)
gAP
#Histogram visually shows a skewed distribution of Alk Phosphate Levels.

#The Wilcox test is appropriate to test for difference and see if Alk Phosphate levels are dependant on the HISTOLOGY variable:
stats::wilcox.test(`ALK PHOSPHATE` ~ HISTOLOGY, data=hepatitis) 

#The p value form this test is close to zero which indicates no difference in the two groups, 
#those who have heaptitis and those who don't
#with relation to Alk Phosphate level.
#The hypothesis can therefore not be true. 



###QUSETION 7


##PART (a)

#Show summary stats for the Bilirubin dataset to get a feel for its shape
pastecs::stat.desc(hepatitis$BILIRUBIN, basic=F)

#Test for Skew & Kutosis of Bilirubin levels
skewB <- semTools::skew(hepatitis$BILIRUBIN)
kurtB <- semTools::kurtosis(hepatitis$BILIRUBIN)
#We divide the skew statistic by the standard error to get the standardised score
skewB[1]/skewB[2]
kurtB[1]/kurtB[2]
#Skew is 14.23 and Kurtosis is 25.19 which both show a high level of skew.

#Histogram to visually inspect normality of the data
gBR <- ggplot(hepatitis, aes(x=hepatitis$BILIRUBIN)) + geom_histogram(binwidth=0.2, colour="black", fill = "light blue")
gBR <- gBR + labs(x="BILIRUBIN Level", y = "Number of Patients") 
gBR <- gBR + stat_function(fun = function(x) (dnorm(x, mean = mean(hepatitis$BILIRUBIN, na.rm=TRUE), sd = sd(hepatitis$BILIRUBIN, na.rm=TRUE)) * 75), colour = "blue", size = 1)
gBR
#Histogram visually shows a skewed distribution of BILIRUBIN.

#Summarize bilirubin data base on two groups, those with a firm liver (yes) and those without (no)
psych::describeBy(hepatitis$BILIRUBIN, group=hepatitis$`LIVER FIRM`)
table(hepatitis$`LIVER FIRM`)

#The Wilcox test is appropriate to test difference based on th analysis above
stats::wilcox.test(BILIRUBIN ~ `LIVER FIRM`, data=hepatitis) 
coin::wilcox_test (BILIRUBIN ~ `LIVER FIRM`, data=hepatitis)

#An independent-samples t-test was conducted to compare BILIRUBIN levels for those with whether the liver was firm or no (Yes vs No)
#No significant difference in BILIRUBIN was found between the two groups.
#Median = 1.01 & SD = 1.01 for LIVER FIRM = No, Median = 1 & SD = 1.33 for LIVER FIRM = Yes, z = -1.72, p = 0.086,  r = -0.06


##PART (b)

#Run on chi-squared/ fisher test on data as both groups are categorical
CrossTable(hepatitis$STEROID, hepatitis$HISTOLOGY, fisher = TRUE, chisq = TRUE, expected = TRUE)

#A Chi-Square test for independence (with Yates' Continuity Correction) indicated 
# no significant association between gender and reported experience of bullying,
# chi^2 = 1.07; p = 0.3 ; phi = -0.34).
