# Install packages
if(!require(broman))install.packages("broman")
if(!require(Hmisc))install.packages("Hmisc")

# Load packages
library(broman)
library(Hmisc)

### Q1 Identify whether the data is positively correlated or negatively correlated using a scatterplot.
temp <- c(91,56,75,68,50,39,98)
accidents <- c(2,9,7,6,6,10,1)
accTemp <- data.frame(temp, accidents)

# Scatter plot 
plot(accTemp)
# The data is negatively correlated


### Q2 Using 1% level of significance test whether insulin has reduced sugar level.
before <- c(350,400,250,200,180)
after <- c(200,300,200,150,120)

# Pearson Correlation test
cor.test(before, after, method='pearson')
# P-value is 0.03024
# The insulin has reduced the sugar levels because there is a less than 3% that the chance of this being coincidental.
# Usually when the sampling error % is between 1% and 5% we can conclude that the finding is statistically significant.
# This means that we can be sufficiently confident that our finding that the insulin reduces the sugar level is correct.


### Q3 Justify with R code suitable correlation test.
maths <- c(50,54,56,59,60,62,61,65,67,71,71,74)
stat <- c(22,25,34,28,26,30,32,30,28,34,36,40)
scoreSet <- data.frame(maths, stat)

# Check the normality of the data
qqplot(scoreSet$maths, scoreSet$stat)
broman::qqline2(scoreSet$maths, scoreSet$stat)
# We can tell from the Q-Q plot that the data is normalised and it looks like there is a positive correlation
# Checking the correlation now:
cor.test(scoreSet$maths, scoreSet$stat, method='pearson')
# The correlation co-efficient is 0.78. The can vary between -1 to 1, where 0 would be no relationship. 
# Cohen's effect size heuristic states that more than 0.5 is a large/strong correlation.
# We can conclude that there is a strong, positive correlation between the mathematics and statistics scores.


### Q4
heartdata <- read.csv('heartdisease.csv')
### Q4 (a) Assess the following variables for normality
#• Cholesterol (Chol)
#• Blood Pressure (RestBP)
#• MaxHR

# Cholesterol:
hist(heartdata$Chol)
# The data is right skewed so the data is not normally distributed

# Blood Pressure:
hist(heartdata$RestBP)
# The data is right skewed so the data is not normally distributed

# MaxHR:
hist(heartdata$MaxHR)
# The data is left skewed so the data is not normally distributed

### Q4 (b)
# • Relationship between cholesterol and blood pressure
qqplot(heartdata$Chol, heartdata$RestBP)
broman::qqline2(heartdata$Chol, heartdata$RestBP)
# The relationship looks parametic so I'm going to use pearson correlation test
cor.test(heartdata$Chol, heartdata$RestBP, method='pearson')
# The correlation co-efficient is 0.13 which means there is a small positive correlation between the cholesterol and blood pressure.

# • Relationship between cholesterol and old peak
qqplot(heartdata$Chol, heartdata$Oldpeak)
broman::qqline2(heartdata$Chol, heartdata$Oldpeak)
# The relationship looks non-parametic so I'm going to use Spearman test to investigate
cor.test(heartdata$Chol, heartdata$Oldpeak, method='spearman')
# Spearman's rho is 0.034 which means there isn't a strong correlation between cholesterol and old peak


### Q5
# Investigate whether there is a difference in the people who have hepatitis and those who did not, by considering the following variables
# • BILIRUBIN
# • SGOT
# Read in dataset
hepatitis <- read.csv("hepatitis.data")
# Add headers
colnames(hepatitis) <- c("Class", "AGE", "SEX", "STEROID", "ANTIVIRALS",
                         "FATIGUE", "MALAISE", "ANOREXIA", "LIVER BIG", "LIVER FIRM", "SPLEN PALPABLE",
                         "SPIDERS", "ASCITES", "VARICES","BILIRUBIN","ALK PHOSPHATE", "SGOT","ALBMIN",
                         "PROTIME", "HISTOLOGY")

# Subset of people with hepatitis
withHep <- subset(hepatitis, hepatitis$HISTOLOGY == '2')
# Subset of people without hepatitis
withoutHep <- subset(hepatitis, hepatitis$HISTOLOGY == '1')

# • BILIRUBIN
# Remove '?' values as we cannot use these in the comparison 
withHep<-withHep[!(withHep$BILIRUBIN=="?"),]
withoutHep<-withoutHep[!(withoutHep$BILIRUBIN=="?"),]

# Look at bilirubin variable. This variable is a character so we need to transform into numeric so that we can summarise it effectively 
sapply(withHep, class)
withHep$BILIRUBIN <- as.numeric(as.character(withHep$BILIRUBIN))
withoutHep$BILIRUBIN <- as.numeric(as.character(withoutHep$BILIRUBIN))

Hmisc::describe(withHep$BILIRUBIN)
Hmisc::describe(withoutHep$BILIRUBIN)
# From describing the data we can see that the mean for people with hepatitis is higher. 
# The lowest values are the same but the highest value for people with hepatitis is twice that of people without hepatitis.
# Also the spread of the data for people without hepatitis is wider than people with hepatitis.
# I visualised the data above by using histograms so that we could also see the frequencies of the bilirubin values more clearly
hist(withHep$BILIRUBIN, ylim = c(0,60), xlim = c(0,8)) # Scaling graph so we can compare values properly
hist(withoutHep$BILIRUBIN, ylim = c(0,60), xlim = c(0,8))
# We can see from the statistical and graphical investigation above that while both frequencies of bilirubin values for the sets of data are skewed to the right, it is more heavily skewed for people without hepatitis.
# Also the majority of the bilirubin values for people without hepatitis are under 1, whereas only half of the values for people with hepatitis are under 1.
# Because of our findings above, we can conclude that it is more likely for a person with hepatitis to have a higher level/value of bilirubin.

# • SGOT
sapply(withHep, class)
sapply(withoutHep, class)
# Similar to bilirubin this column is a character class so we need to transform it to numeric and remove any empty data
withHep<-withHep[!(withHep$SGOT=="?"),]
withoutHep<-withoutHep[!(withoutHep$SGOT=="?"),]
withHep$SGOT <- as.numeric(as.character(withHep$SGOT))
withoutHep$SGOT <- as.numeric(as.character(withoutHep$SGOT))

Hmisc::describe(withHep$SGOT)
Hmisc::describe(withoutHep$SGOT)

hist(withHep$SGOT, ylim = c(0,50), xlim = c(0,700)) # Scaling graph so we can compare values properly
hist(withoutHep$SGOT, ylim = c(0,50), xlim = c(0,700))
# The relationship between SGOT levels and hepatitis seems to be similar to the relationship between bilirubin and hepatitis.
# With people who have hepatitis, the mean value is higher, and the spread of values is wider.
# Both graphs are right skewed as the results above too.
# I think we can conclude that a person is more likely to have a higher level of SGOT if they have hepatitis.


### Q6 Formulate a hypothesis by considering ALK PHOSPHATE levels and hepatitis histology by considering hepatitis dataset. 
# Mention whether you accept or reject the hypothesis.

# Null Hypothesis(H0) : That there is no difference between the ALK Phosphate levels for people with and people without hepatitis
# Alternative Hypothesis(Ha) : That there is a difference between the ALK Phosphate levels for people with and people without hepatitis

sapply(withHep, class)
sapply(withoutHep, class)

# Remove '?' values as we cannot use these in the comparison, and then convert to numeric
withHep<-withHep[!(withHep$`ALK PHOSPHATE`=='?'),]
withoutHep<-withoutHep[!(withoutHep$`ALK PHOSPHATE`=='?'),]
withHep$`ALK PHOSPHATE` <- as.numeric(as.character(withHep$`ALK PHOSPHATE`))
withoutHep$`ALK PHOSPHATE` <- as.numeric(as.character(withoutHep$`ALK PHOSPHATE`))
# Checking frequency as this gives more information
hist(withHep$`ALK PHOSPHATE`, ylim = c(0,50), xlim = c(0,300)) # Scaling graph so we can compare values properly
hist(withoutHep$`ALK PHOSPHATE`, ylim = c(0,50), xlim = c(0,300))
# Checking stats
Hmisc::describe(withHep$`ALK PHOSPHATE`)
Hmisc::describe(withoutHep$`ALK PHOSPHATE`)

# From the investigation above we know that if a person has hepatitis then they are more likely to have a higher level of ALK Phosphate.
# The mean for with hepatitis data is greater and the values have a higher frequency for larger values than the data for people with no hepatitis.
# Most of the alt phosphate values lie between 50 and 100 for people without hepatitis, whereas most of the values for people with hepatitis is greater than 100
# Thus, we accept the alternative hypothesis and reject the null hypothesis.


### Q7 Investigate the following questions by considering the Hepatitis dataset
# • Does Bilirubin level impact the Liver Firm?
# Remove ? values and convert to numeric
hepatitis<-hepatitis[!(hepatitis$BILIRUBIN=="?"),]
hepatitis$BILIRUBIN <- as.numeric(as.character(hepatitis$BILIRUBIN))
# Check the liver firm variable
sapply(hepatitis, class)
# Need to remove ? values and convert to numeric
hepatitis<-hepatitis[!(hepatitis$`LIVER FIRM`=="?"),]
hepatitis$`LIVER FIRM` <- as.numeric(as.character(hepatitis$`LIVER FIRM`))
# Just using qqplot instead of histogram as the graph displays the data clearly enough to see the spread of data
qqplot(hepatitis$`LIVER FIRM`, hepatitis$BILIRUBIN)
# (Assuming that 1 is no and 2 is yes) We can see from the graph that higher levels of bilirubin are associated with people with liver firm
# People with no liver firm have a bilirubin level of about 0-1.5 whereas people with liver firm have bilirubin levels between 0.5 and 8.
# I think that the bilirubin level impacts the liver firm in that a person is more likely to have a liver firm with a higher bilirubin level/value.

# • Are there any differences in steroid level and hepatitis histology?
# Remove ? values and convert

withHep<-withHep[!(withHep$STEROID=="?"),]
withoutHep<-withoutHep[!(withoutHep$STEROID=="?"),]
withHep$STEROID <- as.numeric(as.character(withHep$STEROID))
withoutHep$STEROID <- as.numeric(as.character(withoutHep$STEROID))

Hmisc::describe(withHep$STEROID)
Hmisc::describe(withoutHep$STEROID)
# Using a histogram as the qqplot doesn't tell us anything about the frequencies 
hist(withHep$STEROID, ylim = c(0,50))
hist(withoutHep$STEROID, ylim = c(0,50))

# From the stats and graphs above we can see that people with hepatitis are likely to have either level of steroid (1 or 2).
# The proportion is 0.516 to 0.484 so they are slightly more likely to have no level of steroid with hepatitis.
# The proportion for people without hepatitis leans the other way, 0.434 to 0.566 so they are more likely to have a 1 level of steroid.
# Because the frequencies are so similar I don't think we can conclusively say that there are any significant differences in the steroid levels for histology.