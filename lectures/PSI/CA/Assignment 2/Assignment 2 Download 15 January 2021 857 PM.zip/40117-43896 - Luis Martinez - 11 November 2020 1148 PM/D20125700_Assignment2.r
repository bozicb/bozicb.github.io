



##### ASSIGMENT 2 #####




### 1. QUESTION

# A study was done in which the high daily temperature and the number of 
# traffic accidents within the city were recorded. These sample data are 
# shown as follows.

# Identify whether the data is positively correlated or negatively correlated 
# using a scatter plot. [1 mark]


temp <- c(91,56,75,68,50,39,98)
accidents <- c(2,9,7,6,6,10,1)
accTemp <- data.frame(temp, accidents)

# Let�s visualize the dataframe 3 first rows:

head(accTemp,3)

# let�s call ggplot2 library for make the scatterplot:

library(ggplot2)

# Let�s create the scatterplot:

accTemp_scatter <- ggplot(accTemp, aes(accTemp$accidents, accTemp$temp))
accTemp_scatter + geom_point() + geom_smooth(method = "lm", colour = "Blue", se = F) + labs(x = "temp", y = "accidents")

# According with this Scatterplot, it looks like there is a quite strong negative 
# correlation between the variables temp and accidents.



### 2. QUESTION

# Following data gives the readings of sugar level of 5 diabetic patient before and after
# taking insulin. Using 1% level of significance test whether insulin has reduced sugar
# level. [1 mark]

before <- c(350,400,250,200,180)
after <- c(200,300,200,150,120)

diabetic <- data.frame(before, after)
diabetic

# Let�s calculate the pearson correlation considering 1% level of significance 
# test, but before do it, I am going to make sure that the two variables have 
# normality. I calculate the skewness and kurtosis:

# Now we call this "library(semTools)" to check skewness and kurtosis in order 
# to keep reviewing the normality:

library(semTools)

diabetic_skew<-semTools::skew(diabetic$before)
diabetic_kurt<-semTools::kurtosis(diabetic$before)

# Standardizing the scores:

diabetic_skew[1]/diabetic_skew[2]
diabetic_kurt[1]/diabetic_kurt[2]

diabetic_skew2<-semTools::skew(diabetic$after)
diabetic_kurt2<-semTools::kurtosis(diabetic$after)

# Standardizing the scores:

diabetic_skew2[1]/diabetic_skew2[2]
diabetic_kurt2[1]/diabetic_kurt2[2]


# Standardized scores for skewness and kurtosis between -2 and +2 are considered 
# acceptable in order to prove normal univariate distribution. So in this case, 
# we accept the normality. for both two variables.
# Now, I am going to  calculate the pearson correlation considering 1% level 
# of significance test:

stats::cor.test(diabetic$before, diabetic$after, method='pearson')

# According to the p-value I have to accept the null hypothesis, as the p-value 
# is over 0.01(1%), even if the r is 0.9 of correlation.
# So, I have to reject that at 1% of significance test the insulin has reduced sugar.



### 3. QUESTION

# The following dataset includes the score of students in mathematics and statistics.
# Justify with R code suitable correlation test. [Hint: Check for normality and test the
# data for correlation] [3 marks]



maths <- c(50,54,56,59,60,62,61,65,67,71,71,74)
stat <- c(22,25,34,28,26,30,32,30,28,34,36,40)
scoreSet <- data.frame(maths, stat)

# Let�s check the dataframe:

head(scoreSet)

# First of all, let�s check for normality in the variable maths:

# Let�s create a histogram to visualize its distribution:

mat <- ggplot(scoreSet, aes(x=scoreSet$maths))
mat <- mat + labs(x="maths")
mat <- mat + geom_histogram(binwidth=2, colour="black", aes(y=..density.., fill=..count..))
mat <- mat + scale_fill_gradient("Count", low="#DCDCDC", high="#7C7C7C")
mat <- mat + stat_function(fun=dnorm, color="red",args=list(mean=mean(scoreSet$maths, na.rm=TRUE), sd=sd(scoreSet$maths, na.rm=TRUE)))
mat


# Let�s create a Normal Quantile Plot to visualize it as well:

qqnorm(scoreSet$maths)
qqline(scoreSet$maths, col=2)


# Now, let�s check for normality in the variable stat:

sta <- ggplot(scoreSet, aes(x=scoreSet$stat))
sta <- sta + labs(x="stat")
sta <- sta + geom_histogram(binwidth=2, colour="black", aes(y=..density.., fill=..count..))
sta <- sta + scale_fill_gradient("Count", low="#DCDCDC", high="#7C7C7C")
sta <- sta + stat_function(fun=dnorm, color="red",args=list(mean=mean(scoreSet$stat, na.rm=TRUE), sd=sd(scoreSet$stat, na.rm=TRUE)))
sta

# Let�s make a Normal Quantile Plot to visualize it too:

qqnorm(scoreSet$stat)
qqline(scoreSet$stat, col=2)

# Now I check skewness and kurtosis in order to keep reviewing the normality:

library(semTools)

# Let�s check it for maths:

maths_skew<-semTools::skew(scoreSet$maths)
maths_kurt<-semTools::kurtosis(scoreSet$maths)

# And the same for stat:

stat_skew<-semTools::skew(scoreSet$stat)
stat_kurt<-semTools::kurtosis(scoreSet$stat)

# Now I am going to divide the skew and kurt statistics by the standard errors to get 
# the standardised scores, first with maths:

maths_skew[1]/maths_skew[2]
maths_kurt[1]/maths_kurt[2]

# Now he same with stat:

stat_skew[1]/stat_skew[2]
stat_kurt[1]/stat_kurt[2]

# Standardized scores for skewness and kurtosis between -2 and +2 are considered 
# acceptable in order to prove normal univariate distribution. So in this case, 
# we accept the normality. for both two variables.


# Now let�s visualize with a scatterplot the relationship beetwen the two variables:

scatter_scoreSet <- ggplot(scoreSet, aes(scoreSet$stat, scoreSet$maths))
scatter_scoreSet + geom_point() + geom_smooth(method = "lm", colour = "Yellow", se = F) + labs(x = "maths", y = "stat")

# As the distributions have normality, the most suitable correlation test in 
# the Pearson Correlation:  

stats::cor.test(scoreSet$maths, scoreSet$stat, method='pearson')

# The relationship between Total maths and stat was investigated using a
# Pearson correlation. A strong positive correlation was found 
# (r = 0.78; p(0.002565) < :005), Coefficient of determination = 61.4% of the 
# variation between maths and stat are in common.

# Taking a look at P-value(0.002565) we can say that the probability is 
# less than 0.05 and this value then I can reject the null hypothesis and 
# thus accept the alternative hypothesis and I can state that my findings 
# are 'statistically significant'.




### 4. QUESTION

# Consider given dataset heartdisease.csv. Write the code to do the following.

# (a) Assess the following variables for normality. [6 marks]
# -Cholesterol (Chol)
# -Blood Pressure (RestBP)
# -MaxHR


# Let�s update the dataset:

heartdisease <- read.csv("heartdisease.csv")

# Lets visualize the first rows:

head(heartdisease)

# Let�s install and call the library for "pastecs" to generate summary statistics:

if(!require(pastecs))install.packages("pastecs")
library("pastecs")

# Let�s start with Cholesterol (Chol):

# Let�s generate summary statistics in the variable Cholesterol (Chol):

stat.desc(heartdisease$Chol, basic=F)

# Let�s create a histogram to visualize its distribution of Cholesterol (Chol):

Ch <- ggplot(heartdisease, aes(x=heartdisease$Chol))
Ch <- Ch + labs(x="Chol")
Ch <- Ch + geom_histogram(binwidth=2, colour="yellow", aes(y=..density.., fill=..count..))
Ch <- Ch + scale_fill_gradient("Count", low="#DCDCDC", high="#7C7C7C")
Ch <- Ch + stat_function(fun=dnorm, color="red",args=list(mean=mean(heartdisease$Chol, na.rm=TRUE), sd=sd(heartdisease$Chol, na.rm=TRUE)))
Ch


# Let�s make a Normal Quantile Plot to visualize Cholesterol (Chol):

qqnorm(heartdisease$Cho)
qqline(heartdisease$Cho, col=2) 
# Now Let�s check for skewness and kurtosis of Cholesterol (Chol):

Chol_skew<-semTools::skew(heartdisease$Cho)
Chol_kurt<-semTools::kurtosis(heartdisease$Cho)

# dividing the skewness and kurtosis statistics by the standard errors to get 
# the standardized scores:

stat_skew[1]/stat_skew[2]
stat_kurt[1]/stat_kurt[2]

# Both skewness and kurtosis are between -2 and +2 so we accept the normality.

# Let�s check for normality of Blood Pressure (RestBP):

# Let�s generate summary statistics:

stat.desc(heartdisease$RestBP, basic=F)


# Let�s create a histogram to visualize the distribution of Blood Pressure:

Bl <- ggplot(heartdisease, aes(x=heartdisease$RestBP))
Bl <- Bl + labs(x="RestBP")
Bl <- Bl + geom_histogram(binwidth=2, colour="green", aes(y=..density..,fill=..count..))
Bl <- Bl + scale_fill_gradient("Count", low="#DCDCDC", high="#7C7C7C")
Bl <- Bl + stat_function(fun=dnorm, color="red",args=list(mean=mean(heartdisease$RestBP, na.rm=TRUE), sd=sd(heartdisease$RestBP, na.rm=TRUE)))
Bl


# Let�s make a Normal Quantile Plot of Blood Pressure:

qqnorm(heartdisease$RestBP)
qqline(heartdisease$RestBP, col=2)

# Now Let�s check for skewness and kurtosis of of Blood Pressure:

RestBP_skew<-semTools::skew(heartdisease$RestBP)
RestBP_kurt<-semTools::kurtosis(heartdisease$RestBP)

# Getting standard scores:

RestBP_skew[1]/RestBP_skew[2]
RestBP_kurt[1]/RestBP_kurt[2]

# Both skewness and kurtosis are between -2 and +2 so we accept don�t accept 
# the normality.

# Last one, let�s check for normality of MaxHR:

# Let�s generate summary statistics:

stat.desc(heartdisease$MaxHR, basic=F)


# generating a histogram to visualize the distribution of MaxHR:

Max <- ggplot(heartdisease, aes(x=heartdisease$MaxHR))
Max <- Max + labs(x="MaxHR")
Max <- Max + geom_histogram(binwidth=2, colour="blue", aes(y=..density.., fill=..count..))
Max <- Max + scale_fill_gradient("Count", low="#DCDCDC", high="#7C7C7C")
Max <- Max + stat_function(fun=dnorm, color="red",args=list(mean=mean(heartdisease$MaxHR, na.rm=TRUE), sd=sd(heartdisease$MaxHR, na.rm=TRUE)))
Max

# Let�s make a Normal Quantile Plot of MaxHR:

qqnorm(heartdisease$MaxHR)
qqline(heartdisease$MaxHR, col=2)

# Checking for skewness and kurtsis of MaxHR:

MaxHR_skew<-semTools::skew(heartdisease$MaxHR)
MaxHR_kurt<-semTools::kurtosis(heartdisease$MaxHR)

# Standardizing scores:

MaxHR_skew[1]/MaxHR_skew[2]
MaxHR_kurt[1]/MaxHR_kurt[2]

# The kurtosis looks ok (between -2 and 2) but the skwness its higher, 
# so I do not accept the normality


## (b) Choose the test you think is correct based on your assessment of these variables -
# choose either Pearson, Spearman/Kendall to investigate the following: [4 marks]
# - Relationship between cholesterol and blood pressure
# - Relationship between cholesterol and old peak


# lets check if there is Relationship between cholesterol and 
# blood pressure using a scatterplot:

scatter_chol_Bl <- ggplot(heartdisease, aes(heartdisease$RestBP, heartdisease$Chol))
scatter_chol_Bl + geom_point() + geom_smooth(method = "lm", colour = "Yellow", se = F) + labs(x = "Chol", y = "RestBP")

stats::cor.test(heartdisease$RestBP, heartdisease$Chol, method='spearman')

# The relationship between cholesterol and blood pressure was investigated using a
# spearman correlation. A very weak correlation was found (r = 0.13; p(0.018) < 0.05),
# Coefficient of determination = 1.84% of the variation between cholesterol 
# and blood pressure are in common.
# So, we could say that there is not correlation between the two variables.


# Lets check if there is normality for Oldpeak

# Generating a histogram to visualize the distribution of Oldpeak:

Old <- ggplot(heartdisease, aes(x=heartdisease$Oldpeak))
Old <- Old + labs(x="Oldpeak")
Old <- Old + geom_histogram(binwidth=0.09, colour="red", aes(y=..density.., fill=..count..))
Old <- Old + scale_fill_gradient("Count", low="#DCDCDC", high="#7C7C7C")
Old <- Old + stat_function(fun=dnorm, color="red",args=list(mean=mean(heartdisease$Oldpeak, na.rm=TRUE), sd=sd(heartdisease$Oldpeak, na.rm=TRUE)))
Old



# Let�s make a Normal Quantile Plot of Oldpeak:

qqnorm(heartdisease$Oldpeak)
qqline(heartdisease$Oldpeak, col=2) 

# Checking for skewness and kurtsis of Oldpeak:

Oldpeak_skew<-semTools::skew(heartdisease$Oldpeak)
Oldpeak_kurt<-semTools::kurtosis(heartdisease$Oldpeak)

# Standardize scores:

Oldpeak_skew[1]/Oldpeak_skew[2]
Oldpeak_kurt[1]/Oldpeak_kurt[2]

# Both skewness and kurtsis tell that there is not normality in this variable


# Lets take a look at a scattrplot to visualize if thee is some relationship(or 
# at least some tendency):

scatter_chol_Old <- ggplot(heartdisease, aes(heartdisease$Oldpeak, heartdisease$Chol))
scatter_chol_Old + geom_point() + geom_smooth(method = "lm", colour = "Yellow", se = F) + labs(x = "Chol", y = "Oldpeak")

stats::cor.test(heartdisease$Oldpeak, heartdisease$Chol, method='spearman')

stats::cor.test(heartdisease$Oldpeak, heartdisease$Chol, method='Kendall')

# The relationship between cholesterol and old peak was investigated using a
# spearman correlation. A very weak correlation was found (r = 0.03; p(0.55) > 0.05),

# The p-value (0.5513) tells us is not statistically significant (> 0.05) and 
# indicates strong evidence for the null hypothesis.
# So I can see that there is not correlation at all.



### 5. QUESTION

# Investigate whether there is a difference in the people who have hepatitis and those
# who did not, by considering the following variables. [6 marks]
# - BILIRUBIN
# - SGOT

# Upload data:

hepatitis <- read.csv("hepatitis.data")

# To add headers:

colnames(hepatitis) <- c("Class", "AGE", "SEX", "STEROID", "ANTIVIRALS",
  "FATIGUE", "MALAISE", "ANOREXIA", "LIVER BIG", "LIVER_FIRM", "SPLEN PALPABLE",
  "SPIDERS", "ASCITES", "VARICES","BILIRUBIN","ALK_PHOSPHATE", "SGOT","ALBMIN",
  "PROTIME", "HISTOLOGY")

# Checking the first rows:

head(hepatitis)

# I am going to start with the relation between BILIRUBIN and HISTOLOGY:
# First, I am going to convert BILIRUBIN to a numerical variable to can work with it.

hepatitis$BILIRUBIN <- as.numeric((hepatitis$BILIRUBIN),na.rm=TRUE)

#  Let�s check the change:

head(hepatitis,1)

# Let�s call for all the packs that i will need for the analysis:

library(pastecs) # For creating descriptive statistic 
library(psych) # For using descriptive functions
library(car) # To useLevene's test for homogeneity of variance 
library(coin)# To Wilcox test (non-parametric)

# Let�s generate some statistics for the two groups of HISTOLOGY con respect to BILIRUBIN

describeBy(hepatitis$BILIRUBIN, hepatitis$HISTOLOGY)

# Let�s convert the variable HISTOLOGY to factor in order to can work with it:

hepatitis$HISTOLOGY <- as.character((hepatitis$HISTOLOGY),na.rm=TRUE)
hepatitis$HISTOLOGY <- na.omit(hepatitis$HISTOLOGY)


# Conducting Levene's test for homogeneity of variance in library car, I am 
# checking if the is difference in the variances of the two variables:

newtest <- car::leveneTest(BILIRUBIN ~ HISTOLOGY, data=hepatitis)

# Let�s check it:

newtest

# The null hypothesis is that all variances are equal. A resulting
# p-value under 0.05 means that variances are not equal and than
# further parametric tests are not suitable. 
# In this case the p-value under 0.05(0.0023) 

# Let�s check with no parametric test:

stats::wilcox.test(BILIRUBIN ~ HISTOLOGY, data=hepatitis) 

# P-value is under 0.05, so I can reject the null hypothesis, and accept the 
# alternative hypothesis that the differences on the levels of bilirrubinne 
# depending of the group of HISTOLOGY are statistical significant.

# Just for curiosity, lets check the t-test(parametric one):

stats::t.test(BILIRUBIN ~ HISTOLOGY,var.equal=TRUE,data=hepatitis)

# the result indicated the same as well.


# Secondly, I am going to investigate the relation between SGOT and HISTOLOGY:
# As before, lets convert the variable to numeric in order to can work with it, and 
# also in order to ignore the missing values na:

hepatitis$SGOT <- as.numeric((hepatitis$SGOT),na.rm=TRUE)

# Checking the change:

head(hepatitis,6)

# Conduct Levene's test for homogeneity of variance for SGOT:

ltest2 <- car::leveneTest(SGOT ~ HISTOLOGY, data=hepatitis)

ltest2

# Test is not significant so we can assume homogeneity of variance 
# and proceed with a parametric test

# Lets to carry out the t-test:

stats::t.test(SGOT ~ HISTOLOGY,var.equal=TRUE,data=hepatitis)

# Test statistic is not statistically significant since p-value is over 0.05.
# so I can accept the null hypothesis, that that the differences on the levels 
# of SGOT depending of the group of HISTOLOGY are not statistically significant.




### 6. QUESTION

# Formulate a hypothesis by considering ALK PHOSPHATE levels and hepatitis histology
# by considering hepatitis dataset. Mention whether you accept or reject the hypothesis.
# [3 marks]


# Let�s formulate the hypothesis that the levels of ALK_PHOSPHATE are different 
# depending on the group of the histology variable.
# First of all, lets convert our depended variable into numerical variable to proceed, 
# and fix the na values:

hepatitis$ALK_PHOSPHATE <- as.numeric((hepatitis$ALK_PHOSPHATE),na.rm=TRUE)


# Lets generate some basic statistics:

describeBy(hepatitis$ALK_PHOSPHATE, hepatitis$HISTOLOGY)

# Doing a leveneTest to check the homogenity:

ltest3 <- car::leveneTest(ALK_PHOSPHATE ~ HISTOLOGY, data=hepatitis)

ltest3

# the leveneTest indicates that there are no significant differences in the 
# variances, so , the variances are homogeneous.
# we accept the null hypothesis and can use a parametric test for difference: 

# Doing the t-test:

stats::t.test(ALK_PHOSPHATE ~ HISTOLOGY,var.equal=TRUE,data=hepatitis)

# According to the p-value, I can reject the null hypothesis that there is 
# no significant difference, and I cAN accept the alternative hypothesis 
# that the difference of the levels of ALK_PHOSPHATE depending on the group of the 
# histology variable are statistical significant.



### 7. QUESTION

# Investigate the following questions by considering the Hepatitis dataset. [6 marks]
# - Does Bilirubin level impact the Liver Firm?
# - Are there any differences in steroid level and hepatitis histology?


### first part:

# Because of the way in which the statement of the question is structured, 
# I understand that what you want to find out is that there are differences 
# in the distribution of the "LIVER_FIRM" category variable depending on the 
# levels of bilirruin, therefore I don't see a way clear to do it, I�d say we can 
# no make it in a significant way, but I'm going to try this method:

# In this variable(LIVER_FIRM) 1 means "no" and 2 means"yes".
# Here I clean the data for missing values: 
                
hepatitis$LIVER_FIRM[hepatitis$LIVER_FIRM %in% c('?')] <- NA
hepatitis$STEROID[hepatitis$STEROID %in% c('?')] <- NA

# Removing the nas to can work:

hepatitis <- na.omit(hepatitis)

# Let�s visualize a table of LIVER_FIRM:

table(hepatitis$LIVER_FIRM)

# Let�s visualize a table of BILIRUBIN:

table(hepatitis$BILIRUBIN)

# Let�s describe the LIVER_FIRM by groups of biliruina:

psych::describeBy(as.numeric(hepatitis$LIVER_FIRM),factor(hepatitis$BILIRUBIN) )

# using the kruskal wallis test:

stats::kruskal.test(LIVER_FIRM~BILIRUBIN,data=hepatitis)

# Lets call the FSA to do the post-hoc tests:

library("FSA")


testhoc <- FSA::dunnTest(x=as.numeric(hepatitis$LIVER_FIRM), g=factor(hepatitis$BILIRUBIN), method="bonferroni") 
print(testhoc, dunn.test.results = TRUE)

# As p-value is 0.29, we cannot reject the Ho Hypotesis, therefore we accept the Ho that there is no difference,
# that Bilirubin level does`t impact the Liver Firm.



### 2 part:

# As we are trying to calculate differences in steroid level and hepatitis histology, that is, 2 categorical variales,
# I am going to use the Pearson's Chi-squared test:

catetable <- xtabs(~STEROID+HISTOLOGY, data=hepatitis)

chitest <- chisq.test(catetable, correct=TRUE)

# Getting the details of the test statistic and p-value:

chitest

# expected frequencies:

ctest$expected

# observed frequencies:

ctest$observed
ctest$p.value

# According with the p-value, the differences in steroid level and hepatitis histology are not statistically significat.


# Let�s try another way using the gmodels pack:
# Installing gmodels: 

if(!require(gmodels))install.packages("gmodels")

library("gmodels")

# Using the Crosstable function:

gmodels::CrossTable(hepatitis$STEROID, hepatitis$HISTOLOGY, fisher = TRUE, chisq = TRUE, expected = TRUE, sresid = TRUE)

# Again, according with the p-value, the differences in steroid level and hepatitis histology are not statistically significat.
