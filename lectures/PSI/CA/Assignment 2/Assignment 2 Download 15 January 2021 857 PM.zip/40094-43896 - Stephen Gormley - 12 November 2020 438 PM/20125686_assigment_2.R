#Question 1 - create a scatterplot to understand if the data is positively correlated?
library(ggplot2)

temp <- c(91,56,75,68,50,39,98)
accidents <- c(2,9,7,6,6,10,1)
accTemp <- data.frame(temp, accidents)

scatter_acc_temp <- ggplot(accTemp, aes(accTemp$temp, accTemp$accidents))
scatter_acc_temp + geom_point() + labs(x = "Temperature", y = "Accidents") 

#From the scatterplot produced we can say the data is negatively correlated.
#This is because an increase in temperature decreases the amount of accidents.

#Question 2 - for the 5 diabetic patients ascertain if insulin has reduced sugar
#levels using a 1% significance test.
before <- c(350,400,250,200,180)
after <- c(200,300,200,150,120)
diabetic <- data.frame(before, after)

scatter_diabetic <- ggplot(diabetic, aes(before, after))
scatter_diabetic + geom_point() + labs(x = "Before", y = "After")

cor.test(diabetic$before, diabetic$after, method="kendall",  exact=F)
#The p-value of .022 > then the significance of .01, therefore we can reject the null
#hypothesis that insulin has had no effect on the blood sugar levels.
#I used Kendall to calculate the value because the assumptions of normality don't
#hold up for Pearson method. I used the exact = F because of the "can not compute exact p-value
#with tie error".


#Question 4 - given the below scores for maths and statistics, justify a
#a suitable correlation test.
maths <- c(50,54,56,59,60,62,61,65,67,71,71,74)
stat <- c(22,25,34,28,26,30,32,30,28,34,36,40)
scoreSet <- data.frame(maths, stat)

#our data is numeric so we can explore the use of Pearsons correlation test pending
#the investigation of 3 assumptions required normally distributed variables, linearity, 
#and homoscedasticity
library(pastecs)
library(semTools)

#summary statistics for each of the variables
pastecs::stat.desc(scoreSet$maths, basic=F)
pastecs::stat.desc(scoreSet$stat, basic=F)
#The SD could be considered large for exam scores, suggesting the so further analysis is required,
#before deciding on a test to perform.

#we can also visually check the data to generate some more intuition about the
#distribution of the data though the generation of histograms and qqplots
hist_maths <- ggplot(scoreSet, aes(x = maths)) + geom_histogram(binwidth=1)
hist_maths <- hist_maths + labs(x="Maths Scores")
hist_maths
#Due to the low number of data points it is difficult to interpret the histogram

#scatter plot to understand linearity
scatter <- ggplot(scoreSet, aes(scoreSet$maths, scoreSet$stat))
scatter + geom_point() + labs(x = "Maths", y = "Stat") 

#A qq plot to allow us to understand the distribution and homoscedasticity
library("car")
qqPlot(scoreSet$maths)

qqPlot(scoreSet$stat)

#from the visualizations we can see the linearity of the relationship via the scatter plot.
#The data in the qq plot points towards homoscedasticity because the data points fall
#close to the line and within the boundaries. We can further assess the variables by using
#measurements of skew and kurtosis.

#Lets take the maths variable first
tpskew_math <- semTools::skew(scoreSet$maths)
tpskew_math
tpkurt_math <- semTools::kurtosis(scoreSet$maths)
tpkurt_math
tpskew_math[1]/tpskew_math[2]
tpkurt_math[1]/tpkurt_math[2]
#We can see from our values the skewness and the kurtosis are within acceptable limits 
# +/- 2 and the standardised score for both (-0.018 and -0.5) doesn't exceed +/- 2.5,
#value for sameple size less then 80.

#Now lets move onto the stats variable
tpskew_stat <- semTools::skew(scoreSet$stat)
tpskew_stat
tpkurt_stat <- semTools::kurtosis(scoreSet$stat)
tpkurt_stat
tpskew_stat[1]/tpskew_stat[2]
tpkurt_stat[1]/tpkurt_stat[2]
#We can see from our values the skewness and the kurtosis are within acceptable limits 
# +/- 2 and the standardised score for both doesn't exceed +/- 2.5,
#value for sample size less then 80.

#This validates the assumptions for a Pearson test, namely that the data is 
#normally distributed, linear and satisfies homoscedasticity.

#applying Pearson correlation
stats::cor.test(scoreSet$maths, scoreSet$stat, method='pearson')
#The relationship between maths and stats scores was investigated using Pearsons 
#correlation. A strong positive relationship was found (r = +.7835, n = 12, p > .002)


#Question 4 - assess the heart disease data understand the Chol, RestBP and MaxHR
#for normality. Choose the correct correlation test for Chol and BP, Chol and Old Peak.

#Question 4 A - part 1 understanding the normality of Chol
#Load data
heartdisease <- read.csv("heartdisease.csv")

#describe the data
pastecs::stat.desc(heartdisease$Chol, basic=F)
#visualise the data - histogram
hist_chol <- ggplot(heartdisease, aes(x = Chol))  + geom_histogram(mapping = aes(y=..density..))
hist_chol <- hist_chol + labs(x="Cholestrol Distribution")
hist_chol <- hist_chol + stat_function(fun=dnorm,
                         color="red",
                         args=list(mean=mean(heartdisease$Chol), 
                                   sd=sd(heartdisease$Chol)))
hist_chol

#visualise the data - qq plot
qqPlot(heartdisease$Chol)

#calculate kurtosis and skew of the Cholestorol variable
tpskew_chol <- semTools::skew(heartdisease$Chol)
tpskew_chol
tpkurt_chol <- semTools::kurtosis(heartdisease$Chol)
tpkurt_chol
tpskew_chol[1]/tpskew_chol[2]
tpkurt_chol[1]/tpkurt_chol[2]
#The histogram gives us a visual of the Cholestral. We can see from the histogram
#the data looks positively skewed. We can also see from the QQ plot that the data
#appears to deviate from the line and boundaries suggesting hetroscedasticity.
#The visuals suggest the data is not normally distributed and calculating skew and
#kurtosis adds to the preliminary understanding. The standardised score for skew is 
#8.06926 and for kurtosis is 15.9 far larger then the allowed +/-3.29 for samples of more then
#80 observations. 

#Question 4 A - part 2 understanding the normality of Resting Blood Pressure
#describe the data
pastecs::stat.desc(heartdisease$RestBP, basic=F)
#visualise the data - histogram
hist_RestBP <- ggplot(heartdisease, aes(x = RestBP))  + geom_histogram(mapping = aes(y=..density..))
hist_RestBP <- hist_RestBP + labs(x="Resting Blood Pressure Distribution")
hist_RestBP <- hist_RestBP + stat_function(fun=dnorm,
                                       color="red",
                                       args=list(mean=mean(heartdisease$RestBP), 
                                                 sd=sd(heartdisease$RestBP)))
hist_RestBP

#visualise the data - qq plot
qqPlot(heartdisease$RestBP)


#calculate kurtosis and skew of the Resting Blood Pressure
tpskew_RestBP <- semTools::skew(heartdisease$RestBP)
tpskew_RestBP
tpkurt_RestBP <- semTools::kurtosis(heartdisease$RestBP)
tpkurt_RestBP
tpskew_RestBP[1]/tpskew_RestBP[2]
tpkurt_RestBP[1]/tpkurt_RestBP[2]
#The histogram gives us a visual of the Resting Blood Pressure. We can see from the histogram
#the data appears normal with osme outliers. The QQ plot shows the data veering away from
#from the line and outside of the boundaries suggesting hetroscedasticity.
#The visuals suggest the data is not normally distributed and calculating skew and
#kurtosis adds to the preliminary understanding. The standardised score for skew is 
#5.017 and for kurtosis is 3.12, the skew value falls outside of -/+3.29 acceptable levels
#for samples of more then 80 observations. 

#Question 4 A - part 3 understanding the normality of Max Heart Rate
#describe the data
pastecs::stat.desc(heartdisease$MaxHR, basic=F)
#visualise the data - histogram
hist_MaxHR <- ggplot(heartdisease, aes(x = MaxHR))  + geom_histogram(mapping = aes(y=..density..))
hist_MaxHR <- hist_MaxHR + labs(x="Max Heart Rate Distribution")
hist_MaxHR <- hist_MaxHR + stat_function(fun=dnorm,
                                           color="red",
                                           args=list(mean=mean(heartdisease$MaxHR), 
                                                     sd=sd(heartdisease$MaxHR)))
hist_MaxHR

#visualise the data - qq plot
qqPlot(heartdisease$MaxHR)

#calculate kurtosis and skew of the Max Heart Rate
tpskew_MaxHR <- semTools::skew(heartdisease$MaxHR)
tpskew_MaxHR
tpkurt_MaxHR <- semTools::kurtosis(heartdisease$MaxHR)
tpkurt_MaxHR
tpskew_MaxHR[1]/tpskew_MaxHR[2]
tpkurt_MaxHR[1]/tpkurt_MaxHR[2]
#The histogram gives us a visual of the Max Heart Rate. We can see from the histogram
#the data looks slightly negatively skewed. The qq plot shows a close proximity to the line
#and boundaries indicating homoscedacitity.
#The visuals suggest the data could normally distributed, and the calculation of the metrics agrees. 
#The standardised score for skew is -3.819 and this falls within acceptable values -/+3.29
#for samples of more then 80 observations.


#Question 4 B - part 1 is there a relationship between cholesterol and blood pressure
#we know cholesterol and bloop pressure are not normally distributed so what do we use for correlation?
#first lets visualise the relationship
scatter_chol_bp <- ggplot(heartdisease, aes(x = Chol, y = RestBP))
scatter_chol_bp + geom_point() + labs(x = "Cholesterol", y = "Resting Blood Pressure")
scatter_chol_bp + geom_point() + geom_smooth(method = "lm", colour = "Red")
#The relationship doesnt look strong but we can run a Spearman correlation test, we
#chose this over the parametric Pearson test because the assumption of normality
#has been rejected.

stats::cor.test(heartdisease$Chol, heartdisease$RestBP, method="spearman", exact=F)
#The relationship between Cholestrol and REsting Blood pressure was investigated using Spearman 
#correlation. A weak positive relationship was found (r = +.135, n = 303, p = .018) with the
#test significance level at 0.05.


#Question 4 B - part 2 is there a relationship between cholesterol and old peak
#we know cholesterol is not normally distributed so what do we use for correlation?
#first lets visualise the relationship
scatter_chol_op <- ggplot(heartdisease, aes(x = Chol, y = Oldpeak))
scatter_chol_op + geom_point() + labs(x = "Cholesterol", y = "Old Peak")
scatter_chol_op + geom_point() + geom_smooth(method = "lm", colour = "Red")
#There doesn't appear to be a relationship but we can proceed with a correlation test.
#We know Cholesterol isn't normally distributed so we can use the spearman test as above.

stats::cor.test(heartdisease$Chol, heartdisease$Oldpeak, method="spearman", exact = F)
#The relationship between Cholestrol and Old Peak was investigated using Spearman 
#correlation. There was no relationship found with an r vlaue of 0.03 and a p value = 0.55
#this means we can reject the null hypothesis that there is no relationship between
#the variables.

#Question 5 - investigate if there is a difference between the people who have 
#hepatitis and those that don't, by considering the variables - BILIRUBIN and
#SGOT

#first read in the data and explore the variables
hepatitis <- read.csv("hepatitis.data")
colnames(hepatitis) <- c("Class", "AGE", "SEX", "STEROID", "ANTIVIRALS",
                         "FATIGUE", "MALAISE", "ANOREXIA", "LIVER_BIG", "LIVER_FIRM", "SPLEN_PALPABLE",
                         "SPIDERS", "ASCITES", "VARICES","BILIRUBIN","ALK_PHOSPHATE", "SGOT","ALBMIN",
                         "PROTIME", "HISTOLOGY")

#we can run a summary call to understand the datatypes we are delaying with as well as 
#some basic stats for each of the columns
summary(hepatitis)

#we can see form  the summary that some of the variables that relate to the question are
#classed as chracters. This looks to be related to the fact that missing data was recorded
#using a quesitons mark.
#First lets understand the extent of the problem and devleop a strategyg from there.
nrow(hepatitis)
sum(hepatitis$BILIRUBIN == "?")
(sum(hepatitis$BILIRUBIN == "?") / nrow(hepatitis))*100
#We can see only ~4% of items are missing a value for BILIRUBIN so for the purpose
#of this exercise we can remove the data as the % and absolute amount is small.
#We can save the new dataset to a bilirubin dataframe to preserve the original
#dataframe
bilirubin_data <- hepatitis[hepatitis$BILIRUBIN != "?", ]
nrow(bilirubin_data)

#now we need to change the type of the column we can see from the data that the datatype
#is numeric
bilirubin_data$BILIRUBIN <- as.numeric(bilirubin_data$BILIRUBIN)
str(bilirubin_data)
#We have succesfully converted the values to the correct type.
#we can repeat the check for the SGOT column
nrow(hepatitis)
sum(hepatitis$SGOT == "?")
(sum(hepatitis$SGOT == "?") / nrow(hepatitis))*100
#We can see only ~3% of items are missing a value for SGOT so for the purpose
#of this exercise we can remove the data.
sgot_data <- hepatitis[hepatitis$SGOT != "?", ]
nrow(sgot_data)
sgot_data$SGOT <- as.numeric(sgot_data$SGOT)
str(sgot_data)

#one last change to both dataframe the histology is a boolean column, 1 indicating no and
#2 indicating a yes these are currently being seen as integers in our data but we should change these
#to categorical variables or factors
bilirubin_data$HISTOLOGY <- as.factor(bilirubin_data$HISTOLOGY)
sgot_data$HISTOLOGY <- as.factor(sgot_data$HISTOLOGY)



#Question 5 A - investigating the difference between those with hepatitis and those
#without using the Bilirubin variable.
#We have 2 different groups with and without the disease. The Bilirubin is describe
#as a continuous variable in the hepatitis.names file. This means we can go for an
#independent samples t-test, provided the assumpitons of parametric tests are met.
library(psych)
describeBy(bilirubin_data$BILIRUBIN, bilirubin_data$HISTOLOGY)
#We can see form the description that the group 1 no has 80 participants values with a small
#mean and standard deviation. The same can be said for group 2 yes which has 68 participants.
#Visualising the data form each group would be useful to understand the distributions, as
#we are looking to perform an independent t-test the assumptions of normality hold as
#well as the homogenity of variance.
bilirubin_box<- ggplot(bilirubin_data, aes(x = BILIRUBIN))
bilirubin_box + geom_boxplot() + facet_grid(~HISTOLOGY) + coord_flip()

#We will allocate the histogram to a variable to allow use to manipulate it
bilirubin_hist <- ggplot(bilirubin_data, aes(x = BILIRUBIN))

#Change the label of the x axis
bilirubin_hist <- bilirubin_hist + geom_histogram(mapping = aes(y=..density..), binwidth=2) + labs(x="Bilirubin distribution")
bilirubin_hist <- bilirubin_hist + stat_function(fun=dnorm,
                                         color="red",
                                         args=list(mean=mean(bilirubin_data$BILIRUBIN), 
                                                   sd=sd(bilirubin_data$BILIRUBIN)))
bilirubin_hist

#The visuals look skewed by a small numer of outliers so lets test that.
skew_bili <- semTools::skew(bilirubin_data$BILIRUBIN)
kurt_bili <- semTools::kurtosis(bilirubin_data$BILIRUBIN)
skew_bili[1]/skew_bili[2] 
kurt_bili[1]/kurt_bili[2]

summary(scale(bilirubin_data$BILIRUBIN))
head(sort(scale(bilirubin_data$BILIRUBIN), decreasing = TRUE))
#We can see from the above that there are 2 significant outliers we can remove them
#and rerun the tests

library(dplyr)
bilirubin_data <- bilirubin_data %>% 
  filter(!(scale(BILIRUBIN) > 3.29 | scale(BILIRUBIN) < -3.29))

#even after removing the 2 outliers we still dont have a normal distribution.

library(car) # For Levene's test for homogeneity of variance 
#Conduct Levene's test for homogeneity of variance in library car
ltest <- car::leveneTest(BILIRUBIN ~ HISTOLOGY, data = bilirubin_data)
#Pr(F) is your probability
ltest
#We can tell from the descriptive statistics and the visualisaitons that the data is not
#normally distributed. On top of that we can see the homogenity of variance assumption
#is not met, the p value of .00231 < .05 indicates a rejection of the null hypothesis of
#equal variance. If we knew more about the data we could remove the outliers in an attempt
#to establish normality and equal variance however not knowing about the data collection
#means we can establish if the removal due to error in collection is a legitimate strategy.
#To this end we can choose to run a Mann Whitney U Test, this doesn't
#require the same normality and variance assumptions of the t-test above.
library(coin)
stats::wilcox.test(BILIRUBIN~HISTOLOGY, data=bilirubin_data) #run to get the U value
coin::wilcox_test(BILIRUBIN~HISTOLOGY, data=bilirubin_data)
r = -3.1319 / sqrt(148)
r
#Blirubin levels in those without hepatitis (1) (Mdn = 0.9) did differ from those with
#hepatitis (2) (Mdn = 1.2), (U = 1911, z = -3.1319, p = 0.001737, r = -0.257). The effect
#size of -0.25 can be interpreted as a small effect. 

#Question 5 B - investigating the difference between those with hepatitis and those
#without using the SGOT variable
describeBy(sgot_data$SGOT, sgot_data$HISTOLOGY)
#visualising the groups distribution
sgot_box<- ggplot(sgot_data, aes(x = SGOT))
sgot_box + geom_boxplot() + facet_grid(~HISTOLOGY) + coord_flip()

#We will allocate the histogram to a variable to allow use to manipulate it
sgot_hist <- ggplot(sgot_data, aes(x = SGOT))

#Change the label of the x axis and add a distribution
sgot_hist <- sgot_hist + geom_histogram(mapping = aes(y=..density..)) + labs(x="SGOT distribution")
sgot_hist <- sgot_hist + stat_function(fun=dnorm, color="red",
                                                 args=list(mean=mean(sgot_data$SGOT), 
                                                           sd=sd(sgot_data$SGOT)))
sgot_hist

#Conduct Levene's test for homogeneity of variance in library car
ltest_sgot <- car::leveneTest(SGOT ~ HISTOLOGY, data = sgot_data)
#Pr(F) is your probability
ltest_sgot
#We can tell from the descriptive statistics and the visualisaitons that the data is not
#normally distributed. The homogenity of variance assumption is met, 
#the p value of .085 < .05 indicates an accepting of the null hypothesis of
#equal variance. If we knew more about the data we could remove the outliers in an attmept
#to establish normality however not knowing about the data collection
#means we can establish if the removal due to error in collection is a legitimate strategy.
#To this end we can choose to run a Mann Whitney U Test, this doesn't
#require the same normality and variance assumptions of the t-test above.
stats::wilcox.test(SGOT~HISTOLOGY, data=sgot_data) #run to get the U value
coin::wilcox_test(SGOT~HISTOLOGY, data=sgot_data)
r_SGOT = -1.0146 / sqrt(2525)
r_SGOT
#SGOT levels in those without hepatitis (1) (Mdn = 55) did not differ from those with
#hepatitis (2) (Mdn = 64), (U = 2525, z = -1.0146, p = 0.3103, r = -0.02). The effect
#size of -0.02 can be interpreted as no effect. 


#Question 6 - Formulate a hypothesis by considering ALK PHOSPHATE levels and hepatitis 
#histology by considering hepatitis dataset. Mention whether you accept or reject the hypothesis.

#Null hypothesis: There is no relationship between ALK phosphate levels and the histology of patients.

#Alternative hypothesis: There is a relationship between ALK phosphate levels and the histology of patients.

#Explore the ALK phosphate variable checking what type it is.
str(hepatitis)
#we can see this variable like the BILIRUBIN variable previously has missing data and
#is currently understood as a character type.
#First we assess the extent of the problem of missing data, remove accordingly and assign
#the column as the new data type
nrow(hepatitis)
sum(hepatitis$ALK_PHOSPHATE == "?")
(sum(hepatitis$ALK_PHOSPHATE == "?") / nrow(hepatitis))*100
#We can see 18% of items are missing a value for alk phosphate.
alk_data <- hepatitis[hepatitis$ALK_PHOSPHATE != "?", ]
nrow(alk_data)
alk_data$ALK_PHOSPHATE <- as.numeric(alk_data$ALK_PHOSPHATE)
alk_data$HISTOLOGY <- as.factor(alk_data$HISTOLOGY)
str(alk_data)

describeBy(alk_data$ALK_PHOSPHATE, alk_data$HISTOLOGY)
#visualise the variable to understand the distribution

alk_hist <- ggplot(alk_data, aes(x = ALK_PHOSPHATE))
alk_hist <- alk_hist + geom_histogram(mapping = aes(y=..density..)) + labs(x="Alk Phosphate Distribution")
alk_hist <- alk_hist + stat_function(fun=dnorm, color="red",
                                       args=list(mean=mean(alk_data$ALK_PHOSPHATE), 
                                                 sd=sd(alk_data$ALK_PHOSPHATE)))
alk_hist
#qq plot
qqPlot(alk_data$ALK_PHOSPHATE)

#The visualse suggest a non normal distribution but can check with skew and kurtosis
tpskew_alk <- semTools::skew(alk_data$ALK_PHOSPHATE)
tpskew_alk
tpkurt_alk <- semTools::kurtosis(alk_data$ALK_PHOSPHATE)
tpkurt_alk
tpskew_alk[1]/tpskew_alk[2]
tpkurt_alk[1]/tpkurt_alk[2]
#the data has very large skew and kurtosis measures so the test should be a non-parametric test.
stats::wilcox.test(ALK_PHOSPHATE~HISTOLOGY, data=alk_data) #run to get the U value
coin::wilcox_test(ALK_PHOSPHATE~HISTOLOGY, data=alk_data)
r_ALK = -3.6656 / sqrt(1182.5)
r_ALK
#Alk phosphate levels in those without hepatitis (1) (Mdn = 81) did differ from those with
#hepatitis (2) (Mdn = 114.5), (U = 1182.5, z = -3.6656, p = 0.0002467, r = -0.106). The effect
#size of -0.02 can be interpreted as no effect. In this instance we reject the null hypothesis
#in favor of the alternative hypothesis.

#Question 7 - 
#Does Bilirubin level impact the Liver Firm?
#we can use some of the preprocessing steps from our bilirubin data to begin with, 
#we know we have missing values and incorrect data type.
str(hepatitis)
liver_data <- hepatitis[hepatitis$BILIRUBIN != "?", ]
liver_data <- liver_data[liver_data$LIVER_FIRM != "?", ]
liver_data$BILIRUBIN <- as.numeric(liver_data$BILIRUBIN)

#now we need to change the type of the column we can see from the data that the datatype
#is numeric
liver_unique <- unique(liver_data$LIVER_FIRM)
liver_unique
#There appears to be 3 values for Liver firm including missing values which we can remove.
#we can also convert the column to a categorical variable.
liver_data$LIVER_FIRM <- as.factor(liver_data$LIVER_FIRM)

describeBy(liver_data$BILIRUBIN, liver_data$LIVER_FIRM)

#We already know that Bilirubin isn't noramll distributed so we can choose to go with a
#non paramteric test
stats::wilcox.test(BILIRUBIN~LIVER_FIRM, data=liver_data) #run to get the U value
coin::wilcox_test(BILIRUBIN~LIVER_FIRM, data=liver_data)
r_liver = 1.7192 / sqrt(2761)
r_liver
#Bilirubin levels in those in group liver firm 1 (Mdn = 1.2) did not differ from 
#those in group liver firm 2 (Mdn = 1), (U = 2761, z = 1.7192, p = 0.08559, r = 0.0327). The effect
#size of 0.0327 can be interpreted as no effect. In this instance we cant reject the null hypothesis
#in favor of the alternative hypothesis. In this 

#Are there any differences in steroid level and hepatitis histology?
str(hepatitis)
#An investigation into the data would point towards Steroid as being a Yes/No variable
#We already know the histology column is a Yes/No column.
#Before we get to testing difference we can look at preprocessing the Steroid column
#Which has missing values
steroid_data <- hepatitis[hepatitis$STEROID != "?", ]
steroid_data$STEROID <- as.factor(steroid_data$STEROID)
steroid_data$HISTOLOGY <- as.factor(steroid_data$HISTOLOGY)
str(steroid_data)
#We are comparing two groups of categorical variables so we will look at a Chi-Square test

#Create your contingency table
steorid_table <- xtabs(~STEROID+HISTOLOGY , data=steroid_data) 
ctest <- chisq.test(steorid_table, correct=TRUE)
#get Yates correction needed for 2x2 table
ctest
ctest$expected #expected frequencies
ctest$observed #observed frequencies
ctest$p.value
#The test give us a p-value = 0.301 and Chi squared value = 1.069 as the p value is higher
#then the significance level of 0.05 and the Chi Squared value is lower then 3.84
#we can not reject the null hypothesis that there is no relationship between the two
#variables.
