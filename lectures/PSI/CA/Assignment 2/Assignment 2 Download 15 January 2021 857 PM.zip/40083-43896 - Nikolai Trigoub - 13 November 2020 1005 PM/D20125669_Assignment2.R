#Install Packages if they are required

if (!require('pastecs')) install.packages('pastecs')
if(!require('ggplot2'))install.packages('ggplot2')
if(!require('semTools'))install.packages('semTools')
if(!require('car'))install.packages('car')
if(!require('coin'))install.packages('coin')
if(!require('gmodels'))install.packages('gmodels')


library(pastecs)
library(ggplot2)
library(semTools)
library(car) 
library(coin)
library(gmodels)



#1. A study was done in which the high daily temperature and the number of traffic accidents within the city were recorded. These sample data are shown as follows.
#Identify whether the data is positively correlated or negatively correlated using a scatter plot. 

#Still need to identify if pos/neg correlated

temp <- c(91,56,75,68,50,39,98) 
accidents <- c(2,9,7,6,6,10,1)
accTemp <- data.frame(temp, accidents)


plot(accTemp)

#Answer - Negative Correlation

# 2. Following data gives the readings of sugar level of 5 diabetic patient before and after taking insulin. 
#Using 1% level of significance test whether insulin has reduced sugar level. [1 mark]

before <- c(350,400,250,200,180) 
after <- c(200,300,200,150,120)

sugarlevel <-data.frame(before, after)

plot(sugarlevel)

stat.desc(sugarlevel, basic = T)

cor.test(before, after, method = 'pearson')

# 3. The following dataset includes the score of students in mathematics and statistics. Justify with R code suitable correlation test. 
# [Hint: Check for normality and test the data for correlation] [3 marks]

maths <- c(50,54,56,59,60,62,61,65,67,71,71,74) 
stat <- c(22,25,34,28,26,30,32,30,28,34,36,40) 

scoreSet <- data.frame(maths, stat)


#Summary Stats
stat.desc(scoreSet, basic = F, norm = F)

#Checking for Normality

#Scatter Plot
plot(scoreSet)


#Freq for Maths Score
gg <- ggplot(scoreSet, aes(x=maths))
gg <- gg + labs(x="Maths Score") 
gg <- gg + geom_histogram(binwidth=5, colour="black", aes(y=..density.., fill=..count..))
gg <- gg + scale_fill_gradient("Count", low="#DCDCDC", high="#7C7C7C")


gg + stat_function(fun = dnorm, args = list(mean = mean(scoreSet$maths, na.rm = T), sd = sd(scoreSet$maths, na.rm = T)), colour = "red", size = 1)

#Freq for Stats Scores
gg1 <- ggplot(scoreSet, aes(x=stat))
gg1 <- gg1 + labs(x="Stats Score") 
gg1 <- gg1 + geom_histogram(binwidth=5, colour="black", aes(y=..density.., fill=..count..))
gg1 <- gg1 + scale_fill_gradient("Count", low="#DCDCDC", high="#7C7C7C")


gg1 + stat_function(fun = dnorm, args = list(mean = mean(scoreSet$stat, na.rm = T), sd = sd(scoreSet$stat, na.rm = T)), colour = "green", size = 1)


#Q-Q Plots for Maths & Stats

qqnorm(maths)
qqline(maths, col=2)

qqnorm(stat)
qqline(stat, col=3)

#The data on both QQ Plots broadly follows the diagonal of the plot

#Calculate Skew 

skew(scoreSet$maths)
skew(scoreSet$stat)

#Calculate Kurtosis
kurtosis(scoreSet$maths)
kurtosis(scoreSet$stat)

#Shapiro Wilk Normality Test

shapiro.test(scoreSet$maths)
shapiro.test(scoreSet$stat)


# Considering the dataset is small, the Histograms are distorted but suggest normal distribution 
# Based on the Kurtosis & Skew being within =/-2 this is a normal distribution. 
# The Shapiro Wilk test P>0.05 tells us that the data is normally distributed and we can use the Pearson Test to measure correlation

# Based on the scatterplot we would would expect a linear relatively strong  positive correlation, now check Pearson's Correlation Coefficient

cor.test(scoreSet$maths, scoreSet$stat, method= "pearson")

#PearonsResult is 0.7835978 which tells us there is a strong positive correlation as expected from the scatterplot


# 4. Consider given dataset heartdisease.csv. Write the code to do the following.
# [Note: Kindly save the read dataset in a variable called “heartdisease”. Do not change the variable name. For ex: heartdisease <- read.csv(”heartdisease.data”). ]

#Loading dataset and checking summary stats
heartdisease <- read.csv('heartdisease.csv', header = T )
head(heartdisease)

stat.desc(heartdisease)

# (a) Assess the following variables for normality. [6 marks]

# • Cholesterol (Chol)

#Checking for Normality

#Freq for Cholesterol
ggchol <- ggplot(heartdisease, aes(Chol))
ggchol <- ggchol + labs(x="Cholesterol") 
ggchol <- ggchol + geom_histogram(binwidth=40, colour="black", aes(y=..density.., fill=..count..))
ggchol <- ggchol + scale_fill_gradient("Count", low="#DCDCDC", high="#7C7C7C")

ggchol + stat_function(fun = dnorm, args = list(mean = mean(heartdisease$Chol, na.rm = T), sd = sd(heartdisease$Chol, na.rm = T)), colour = "green", size = 1)


#Q-Q Plots for Chol
qqnorm(heartdisease$Chol)
qqline(heartdisease$Chol, col=2)

#Calculate Skew, Kurtosis & Shapiro Wilks Normality Test

skew(heartdisease$Chol)
kurtosis(heartdisease$Chol)
shapiro.test(heartdisease$Chol)

# Chol's normality is affected by the presense of outliers. We can trim the top/bottom 2.5% of outliers and this will likely bring the kurtosis into the +/-2 range acceptable and allow for a normal histogram and qq plot
# The Skew falls within the +/-2 acceptable range for normality. Finally the with a P value of <0.05 confirms that Chol is not a normal distribution
# Without trimming outliers Chol's distribution is not normal

# • Blood Pressure (RestBP)

#Freq for RestBP
ggRestBP <- ggplot(heartdisease, aes(RestBP))
ggRestBP <- ggRestBP + labs(x="RestBP") 
ggRestBP <- ggRestBP + geom_histogram(binwidth=10, colour="black", aes(y=..density.., fill=..count..))
ggRestBP <- ggRestBP + scale_fill_gradient("Count", low="#DCDCDC", high="#7C7C7C")

ggRestBP + stat_function(fun = dnorm, args = list(mean = mean(heartdisease$RestBP, na.rm = T), sd = sd(heartdisease$RestBP, na.rm = T)), colour = "green", size = 1)


#Q-Q Plots for RestBP
qqnorm(heartdisease$RestBP)
qqline(heartdisease$RestBP, col=3)


#Calculate Skew, Kurtosis & Shapiro Wilks Normality Test

skew(heartdisease$RestBP)
kurtosis(heartdisease$RestBP)
shapiro.test(heartdisease$RestBP)

# The positive skewing of RestBP in the histogram and also the divergence from the diagonal line in QQ Plot suggests that RestBP is not normal
# A P value of <0.05 confirms that RestBP is not a normal distribution

# • MaxHR

#Freq for MaxHR

ggMaxHR <- ggplot(heartdisease, aes(MaxHR))
ggMaxHR <- ggMaxHR + labs(x="MaxHR") 
ggMaxHR <- ggMaxHR + geom_histogram(binwidth=10, colour="black", aes(y=..density.., fill=..count..))
ggMaxHR <- ggMaxHR + scale_fill_gradient("Count", low="#DCDCDC", high="#7C7C7C")

ggMaxHR + stat_function(fun = dnorm, args = list(mean = mean(heartdisease$MaxHR, na.rm = T), sd = sd(heartdisease$MaxHR, na.rm = T)), colour = "green", size = 1)


#Q-Q Plots for MaxHR
qqnorm(heartdisease$MaxHR)
qqline(heartdisease$MaxHR, col=2)

#Calculate Skew, Kurtosis & Shapiro Wilks Normality Test

skew(heartdisease$MaxHR)
kurtosis(heartdisease$MaxHR)
shapiro.test(heartdisease$MaxHR)

# MaxHR shows a negatives skew in the histogram and divergence in the extremes of the QQplot.


# (b) Choose the test you think is correct based on your assessment of these variables -
#   choose either Pearson, Spearman/Kendall to investigate the following: [4 marks] 

#Based on the judgements of none of the variables being Normal we can not use Pearson's
# Also as there are ties in the data, we will need to use Kendall's Tau


# • Relationship between cholesterol and blood pressure

# Both Chol & BP are interval 

ggplot(heartdisease, aes(x = Chol, y = RestBP))+
  geom_point()

#Running Correlation test excluding any missing variables

cor.test(heartdisease$Chol, heartdisease$RestBP, use = 'pairwise.complete.obs', method = "kendall")

#The P Value tells us that there is a significant relationship and the Tau of 0.09 tells us it has a small positive effect

# • Relationship between cholesterol and old peak

# Chol is interval and old peak is ratio

ggplot(heartdisease, aes(x = Chol, y = Oldpeak))+
  geom_point()

cor.test(heartdisease$Chol, heartdisease$Oldpeak, use = 'pairwise.complete.obs', method = "kendall")
#The P Value < 0.05 tells us that there is a not a significant relationship and the Tau of 0.027 tells us it has a very small positive effect



# 5. Investigate whether there is a difference in the people who have hepatitis and those who did not, by considering the following variables. [6 marks]
# • BILIRUBIN • SGOT
# [Note: Kindly save the read dataset in a variable called “hepatitis”. Do not change the variable name. For ex: hepatitis <- read.csv(”hepatitis.data”). Dataset is available https://archive.ics.uci.edu/ml/datasets/Hepatitis. Use the following code to add header. ]


#Adding Headers 

#Importing it and changing all the '?' into NAs

hepatitis <- read.csv('hepatitis.data', na.strings = "?")

colnames(hepatitis) <- c("Class", "AGE", "SEX", "STEROID", "ANTIVIRALS",
                         "FATIGUE", "MALAISE", "ANOREXIA", "LIVER BIG", "LIVER FIRM", "SPLEN PALPABLE",
                         "SPIDERS", "ASCITES", "VARICES","BILIRUBIN","ALK PHOSPHATE", "SGOT","ALBMIN",
                         "PROTIME", "HISTOLOGY")

summary(hepatitis)


#First lets check Bilirubin for Normality

#Freq for Bilirubin
ggBil <- ggplot(hepatitis, aes(x=BILIRUBIN))
ggBil <- ggBil + labs(x="Bilirubin") 
ggBil <- ggBil + geom_histogram(binwidth=0.4, colour="black", aes(y=..density.., fill=..count..))
ggBil <- ggBil + scale_fill_gradient("Count", low="#DCDCDC", high="#7C7C7C")


ggBil + stat_function(fun = dnorm, args = list(mean = mean(hepatitis$BILIRUBIN, na.rm = T), sd = sd(hepatitis$BILIRUBIN, na.rm = T)), colour = "red", size = 1)

#Q-Q Plots for Bilrubin

qqnorm(hepatitis$BILIRUBIN)
qqline(hepatitis$BILIRUBIN, col=2)


#Calculate Skew 

skew(hepatitis$BILIRUBIN)

#Calculate Kurtosis
kurtosis(hepatitis$BILIRUBIN)

#Shapiro Wilk Normality Test

shapiro.test(hepatitis$BILIRUBIN)



# The Histogram & QQ Plot show that the data is not normally distributed
# Based on the Kurtosis & Skew being outside +/-2 this is a not normal distribution. 
# The Shapiro Wilk test P<0.05 tells us that the data is not normally distributed 


#Check SGOT for Normality

#Freq for SGOT
ggSGOT <- ggplot(hepatitis, aes(x=SGOT))
ggSGOT <- ggSGOT + labs(x="SGOT") 
ggSGOT <- ggSGOT + geom_histogram(binwidth=20, colour="black", aes(y=..density.., fill=..count..))
ggSGOT <- ggSGOT + scale_fill_gradient("Count", low="#DCDCDC", high="#7C7C7C")


ggSGOT + stat_function(fun = dnorm, args = list(mean = mean(hepatitis$SGOT, na.rm = T), sd = sd(hepatitis$SGOT, na.rm = T)), colour = "red", size = 1)

#Q-Q Plots for SGOT

qqnorm(hepatitis$SGOT)
qqline(hepatitis$SGOT, col=2)

#Calculate Skew 

skew(hepatitis$SGOT)

#Calculate Kurtosis
kurtosis(hepatitis$SGOT)

#Shapiro Wilk Normality Test

shapiro.test(hepatitis$SGOT)

# The Histogram & QQ Plot show that the data is not normally distributed
# Based on the Kurtosis & Skew being outside +/-2 this is a not normal distribution. 
# The Shapiro Wilk test P<0.05 tells us that the data is not normally distributed 


# With both SGOT & Bilirubin are both not normally distributed and intervals
# Histology is a Nominal Value

#As the data is non normal, independent and one variable is interval we will use the Mann-Whitney Test

#Need to covert Histology from an Integer to a Factor
hepatitis$HISTOLOGY <- as.factor(hepatitis$HISTOLOGY)


#Descriptive Stats by Group
describeBy(hepatitis$SGOT,group=hepatitis$HISTOLOGY)
describeBy(hepatitis$BILIRUBIN,group=hepatitis$HISTOLOGY)

#Creating dataset for both positive and negative Hep results
Negative <- subset(hepatitis, HISTOLOGY=='1')
Positive <-subset(hepatitis, HISTOLOGY=='2')

# Test for differences based on SGOT
stats::wilcox.test(SGOT~HISTOLOGY, data=hepatitis) 
# Test for differences based on Bilirubin
stats::wilcox.test(BILIRUBIN~HISTOLOGY, data=hepatitis) 

# Test for differences based on SGOT
coin::wilcox_test(SGOT~HISTOLOGY, data=hepatitis) 
# Test for differences based on Bilirubin
coin::wilcox_test(BILIRUBIN~HISTOLOGY, data=hepatitis) 

#SGOT Levels For patients who were Hep Positive were higher (Median = 64) than Hep Neg Patients (Median = 55), W = 2525.5, p = 0.3112

#Bilirubin Levels For patients who were Hep Positive were higher (Median = 1.2) than Hep Neg Patients (Median = 0.9), W = 1911, p = 0.001737



# 6. Formulate a hypothesis by considering ALK PHOSPHATE levels and hepatitis histology by considering hepatitis dataset. Mention whether you accept or reject the hypothesis. [3 marks]

#H0: There is no relationship between ALK Phosphate and Hepatitis Histology.

# ALK Phosphate is an interval and histology nominal

#Check ALK Phosphate for Normality

#Freq for ALK
ggALK <- ggplot(hepatitis, aes(x=`ALK PHOSPHATE`))
ggALK <- ggALK + labs(x="ALK") 
ggALK <- ggALK + geom_histogram(binwidth=20, colour="black", aes(y=..density.., fill=..count..))
ggALK <- ggALK + scale_fill_gradient("Count", low="#DCDCDC", high="#7C7C7C")


ggALK + stat_function(fun = dnorm, args = list(mean = mean(hepatitis$`ALK PHOSPHATE`, na.rm = T), sd = sd(hepatitis$`ALK PHOSPHATE`, na.rm = T)), colour = "red", size = 1)

#Q-Q Plots for ALK

qqnorm(hepatitis$`ALK PHOSPHATE`)
qqline(hepatitis$`ALK PHOSPHATE`, col=2)

#Calculate Skew 

skew(hepatitis$`ALK PHOSPHATE`)

#Calculate Kurtosis
kurtosis(hepatitis$`ALK PHOSPHATE`)

#Shapiro Wilk Normality Test

shapiro.test(hepatitis$`ALK PHOSPHATE`)


# The Histogram & QQ Plot show that the data is not normally distributed
# The Shapiro Wilk test P<0.05 tells us that the data is not normally distributed 


#Descriptive Stats by Group
describeBy(hepatitis$`ALK PHOSPHATE`,group=hepatitis$HISTOLOGY)

#Creating dataset for both positive and negative Hep results
NegativeHep <- subset(hepatitis, HISTOLOGY=='1')
PositiveHep <-subset(hepatitis, HISTOLOGY=='2')


# Test for differences based on ALK 
stats::wilcox.test(`ALK PHOSPHATE`~HISTOLOGY, data=hepatitis) 


# Test for differences based on ALK
coin::wilcox_test(`ALK PHOSPHATE`~HISTOLOGY, data=hepatitis) 


# Patients who are Hep Positive have a higher ALK Phosphate (Med = 114.5) than patients who are Hep Negative (Med = 81)

# 7. Investigate the following questions by considering the Hepatitis dataset. [6 marks] 
#• Does Bilirubin level impact the Liver Firm?

#We already know that Bilirubin is not normally distributed & liver firm is a nominal variable. We will again use the Mann Whitney Test

hepatitis$`LIVER FIRM`<- as.factor(hepatitis$`LIVER FIRM`)

#Descriptive Stats by Group
describeBy(hepatitis$BILIRUBIN,group=hepatitis$`LIVER FIRM`)

#Creating dataset for both positive and negative Hep results
NegativeFirm <- subset(hepatitis, `LIVER FIRM`=='1')
PositiveFirm <-subset(hepatitis, `LIVER FIRM`=='2')


# Test for differences based on Bilirubin
stats::wilcox.test(BILIRUBIN~`LIVER FIRM`, data=hepatitis) 


# Test for differences based on Bilirubin
coin::wilcox_test(BILIRUBIN~`LIVER FIRM`, data=hepatitis) 

#Bilirubin Levels For patients who had Firm Livers were higer (Median = 1.2) than patients who didn't have firm livers  (Median = 1), W = 2761, p = 0.08598



#   • Are there any differences in steroid level and hepatitis histology?


# As these are both Nominal Values we will need to use a Chi Square Test


#Use the Crosstable function
#CrossTable(predictor, outcome, fisher = TRUE, chisq = TRUE, expected = TRUE)

CrossTable(hepatitis$STEROID, hepatitis$HISTOLOGY, fisher = TRUE, chisq = TRUE, expected = TRUE, sresid = TRUE, format = "SPSS")

#Calculate the phi value
sqrt(1.069/153)


#A Chi-Square test for independence (with Yates’ Continuity Correction) indicated no significant association between steroid level and hepatitis histology,
# X2(1,n = 153) = 1.069,p = 0.3,phi = 0.0835).
