if(!require(Hmisc))install.packages("Hmisc")
if(!require(Hmisc))install.packages("lmSupport")
if(!require(Hmisc))install.packages("lm.beta")
if(!require(Hmisc))install.packages("stargazer")
library(Hmisc)
library(lmSupport)
library(lm.beta)
library(stargazer)

### LINEAR REGRESSION WITH DUMMY VARIABLE (weatherhistory.csv)

weather <- read.csv('weatherHistory.csv')
# 1. Describe dependent variable pressure and independent variable temperature.
Hmisc::describe(weather)
hist(weather$pressure)
# Pressure: This is a continuous variable that ranges between 0 and 1046.38. There are no missing values in this dataset. 
# The Mean is 1003. There are 4979 distinct values. From plotting the frequency of this variable and checking the proportion, 
# it looks like there could be some outliers.
subset(weather, weather$pressure < 980) # 4801
subset(weather, weather$pressure == 0) # 4736
# Less than 5% of the data is between 0 and 980, and 99% of that data is where the pressure is equal to 0. This data can be considered
# an outlier so should be removed in the data cleaning steps.
# Remove outliers
weather <- subset(weather, weather$pressure >=980)
hist(weather$pressure)
# The pressure is normally distributed.

hist(weather$temperature)
# Temperature: This variable is also continuous and has no missing values. There are 7574 distinct values. The values range
# between -21.82222 and 39.90556 and mean is 11.93. The distribution is normal.


# 2. Explore the relationship between pressure and temperature.
plot(weather$pressure, weather$temperature)
# Before removing the outliers, the data plotted didn't reveal anything as there were just two vertical lines plotted.
# After removing, we have a much clearer view of the variables. It looks like there is a weak negative relationship between
# pressure and temperature.
# Checking the correlation using Pearson's test as both variables are continuous and normally distributed
cor.test(weather$pressure, weather$temperature, method="pearson")
# Pearson's correlation coefficient is low at -0.3 which confirms that there is a small negative correlation between the values.


# 3. Build a linear model considering temperature and pressure
model1<-lm(weather$temperature ~ weather$pressure)
anova(model1)
summary(model1)
lm.beta(model1)
stargazer(model1, type="text")


# 4. Identify a dummy variable and build extended model considering dummy variable.
# Build second model with dummy variable humidity
model2<-lm(weather$temperature ~ weather$pressure + weather$humidity)
anova(model2)
summary(model2)
lm.beta(model2)
stargazer(model2, type="text")


# 5. Report your findings.
stargazer(model1, model2, type="text")
# R2 for our first model is 0.097 and is 0.483 for the second model which means this model explains
# 48.3% of the variance in comparison to 9.7% for model1. This means that our second model has a better fit.



### MULTIPLE LINEAR REGRESSION (weatherhistory.csv)

# 1. Explore the relationship between pressure and windspeed.
plot(weather$pressure, weather$windSpeed)
hist(weather$pressure) # normal
hist(weather$windSpeed) # right skewed
# Choosing the spearman test because the data is continuous and windspeed is right skewed
cor.test(weather$pressure, weather$windSpeed, method="spearman")
# From the plot and Spearman's correlation coefficient (-0.228) we can conclude that there is a weak negative 
# correlation between pressure and windspeed


# 2. Build a linear model considering (windspeed, humidity, temperature) and pressure.
model3 <- lm(weather$pressure ~ weather$windSpeed + weather$humidity + weather$temperature)
stargazer(model3, type="text")


# 3. Assess how model meets key assumptions of linear regression
# The model assumes that windspeed, humidity and temperature effects pressure. Humidity seems to be the main factor whereas temperature and windspeed are not.


# 4. Investigate a differential effect by adding dummy variable.
model4 <- lm(weather$pressure ~ weather$windSpeed + weather$humidity + weather$temperature + weather$windBearing)
stargazer(model3, model4, type="text")
# It looks like this model has slightly increased with windBearing as a dummy variable. The R2 value has increased from 0.240 to 0.241


# 5. Investigate an interaction effect for windspeed and dummyvariable.
weather$interaction <- weather$windSpeed * weather$windBearing
model5 <- lm(weather$pressure ~ weather$windSpeed + weather$humidity + weather$temperature + weather$windBearing + weather$interaction)
stargazer(model4, model5, type="text")


# 6. Report your findings.
# The interaction effect does not change the model outcome so the interaction effect does not make a difference



### LOGISTIC REGRESSION (heartfailure.csv)

heartFailure <- read.csv("heartfailure.csv")
# 1. Build a model considering diabetes as predictor.
logmodel1 <- glm(diabetes ~ 1, data=heartFailure, family = binomial())
stargazer(logmodel1, type="text")
summary(logmodel1)


# 2. Calculate and analyze odds ratio of the model.
exp(coefficients(logmodel1))
# odds ratio is 0.7183908 which means there's a 71% chance of having diabetes


# 3. Extend the model by considering variable age. 
# (Convert the age into categorical data, if age < 55 , category 1; age is between 55 and 68 category 2 ; otherwise category 3)
# Convert age values
heartFailure$age[heartFailure$age < 55] <- 1
heartFailure$age[heartFailure$age %in% c(54:68)] <- 2
heartFailure$age[heartFailure$age != 1 & heartFailure$age != 2] <- 3
# Extend model with age
logmodel2 <- glm(diabetes ~ age, data=heartFailure, family = binomial())
stargazer(logmodel2, type="text")
summary(logmodel2)


# 4. Report your finding.
exp(coefficients(logmodel2))
# odds ratio is 0.7805951 which means that our model has improved after extending it to consider the age variable