library(tidyverse)
library(plyr)
library(dplyr)
library(psych)
library(REdaS)
library(Hmisc)
library(corrplot)
library(ggcorrplot)
library(ggpubr)
library(FSA)
library(dummies)
library(regclass)
library(car)

path <- 'D:/Data Science MsC/Statistics/Assignment 4/'
setwd(path)
getwd()
weather <- read.csv('./weatherhistory.csv')

psych::describe(weather)

#  Linear regression with dummy variable
# 1. Describe dependent variable pressure and independent variable temperature.
psych::describe(weather$pressure)
histogram(weather$pressure)
ggqqplot(weather$pressure)

zero <- function(x) sum(x == 0)
numcolwise(zero)(weather)
## zero's on pressure are probably a reading error - will replace with NAs
weather[weather$pressure == 0,]$pressure <- NA

# Check normality of the distribution
psych::describe(weather$pressure) #skew and kurtosis indicate normally distributed
histogram(weather$pressure) # histogram now looks Gaussian
ggqqplot(weather$pressure) # there are some observations on the tails deviating from normality

pressure_zscore <- abs(scale(weather$pressure))
FSA::perc(as.numeric(pressure_zscore), 3.29, 'gt') #0.29% of outliers - we will treat distribution as normal

# Pressure is a normally distributed variable. 
# n 95164 
# mean 1016.81
# sd 7.78
# median 1016.55
# skew 0.08
# Kurtosis 0.9 

# Temperature
psych::describe(weather$temperature) #skew and kurtosis indicate normally distributed
histogram(weather$temperature) # few observations around the mean compared to a normal distribution
ggqqplot(weather$temperature) # there are some observations on the tails deviating from normality

temperature_zscore <- abs(scale(weather$temperature))
FSA::perc(as.numeric(temperature_zscore), 3.29, 'gt') #0.016% of outliers - we will treat distribution as normal

# Temperature is a normally distributed variable. 
# n 96452  
# mean 11.93 
# sd 9.55     
# median 12   
# skew .09    
# Kurtosis -0.57

# 2. Explore the relationship between pressure and temperature.

plot(weather$temperature, weather$pressure)
abline(lm(weather$pressure ~ weather$temperature)) # visually there seems to be a slight negative correlation
cor.test(weather$temperature, weather$pressure, method = 'pearson')

# H0 is that the correlation is equal to 0. H1 is that the correlation is not equal to 0
# As p-value is close to zero, we can reject the NULL hypothesis and conclude that that pressure and temperature
# are significantly correlated (-0.3104561)

# 3. Build a linear model considering temperature and pressure.
temp_pres_lm <- lm(weather$pressure ~ weather$temperature)
summary(temp_pres_lm) %>%
  print()

# 4. Identify a dummy variable and build extended model considering dummy variable

distinct(weather, precipType)
weather_dummy <- cbind(weather, dummy(weather$precipType, sep = ''))
distinct(weather_dummy, weathernull, weatherrain, weathersnow) # dummy variables created correctly

temp_dummy_lm <- lm(weather_dummy$pressure ~ weather_dummy$temperature  
                      + weather_dummy$weathersnow + weather_dummy$weathernull
                      + weather_dummy$weatherrain)

col_check <- weather_dummy %>%
  select(temperature, pressure, weathersnow, weathernull, weatherrain)
round(cor(col_check), 2)

# based on the message "Coefficients: (1 not defined because of singularities)" probably two of my dummies are 
# perfectly collinear - we are going to remove one (weatherrain)

temp_dummy_lm <- lm(weather_dummy$pressure ~ weather_dummy$temperature  
                    + weather_dummy$weathersnow + weather_dummy$weathernull)

summary(temp_dummy_lm) %>%
  print()

# previously Multiple R-squared:  0.09638,	Adjusted R-squared:  0.09637
# now: Multiple R-squared:  0.1198,	Adjusted R-squared:  0.1197 
# Interpretion: the addition of dummy variables improves the quality of the model as it is able
# to explain more of the variance.


### Multiple Linear Regression
# 1.  Explore the relationship between pressure and windspeed.

psych::describe(weather$windSpeed)
histogram(weather$windSpeed)
ggqqplot(weather$windSpeed)
# windspeed is not normally distributed

plot(weather$windSpeed, weather$pressure)
abline(lm(weather$pressure ~ weather$windSpeed)) # visually there seems to be a slight negative correlation
cor.test(weather$windSpeed, weather$pressure, method = 'kendall') %>%
  print()

# 2.  Build a linear model considering (windspeed, humidity, temperature) and pressure

temperature_lm2 <- lm(weather$pressure ~ weather$windSpeed + weather$temperature + weather$humidity)
stargazer::stargazer(temperature_lm2, type = 'text') %>%
  print()

# 3.  Assess how model meets key assumptions of linear regression.

# Non-zero variance, linearity and independence

weather_col_test <- weather %>%
    select(windSpeed, temperature, pressure, humidity)
round(cor(weather_col_test), 2)
VIF(temperature_lm2)
# there doesn't seem to be collinearity between predictors

durbinWatsonTest(temperature_lm2) # the data is highly autocorrelated, which is to be expected as is a time series
plot(temperature_lm2)

#Cooks distance
cooks.distance(temperature_lm2)
#Plot Cooks distance
plot(cooks.distance(temperature_lm2), ylab="Cook's statistic")

#Create histogram
#A density plot of the residuals
plot(density(resid(temperature_lm2))) 
# residuals look they fit a normal distribution

leveragePlots(temperature_lm2) # leverage plots
qqPlot(temperature_lm2, main="QQ Plot") #QQplot 
#Collinearity
vifmodel<-vif(temperature_lm2) # All variables are smaller than 4 so we can assume no collinearity between variables
#Calculate tolerance
1/vifmodel

# 4. Investigate a differential effect by adding dummy variable
temperature_lm3 <- lm(weather_dummy$pressure ~ weather_dummy$windSpeed + weather_dummy$temperature 
                      + weather_dummy$humidity + weather_dummy$weathernull + weather_dummy$weathersnow)
stargazer::stargazer(temperature_lm3, type = 'text') %>%
  print()

#Cooks distance
cooks.distance(temperature_lm3)
#Plot Cooks distance
plot(cooks.distance(temperature_lm3), ylab="Cook's statistic")

#Create histogram
#A density plot of the residuals
plot(density(resid(temperature_lm3))) 
# residuals look they fit a normal distribution

leveragePlots(temperature_lm3) # leverage plots
qqPlot(temperature_lm3, main="QQ Plot") #QQplot 
#Collinearity
vifmodel<-vif(temperature_lm3) # All variables are smaller than 4 so we can assume no collinearity between variables
#Calculate tolerance
1/vifmodel
