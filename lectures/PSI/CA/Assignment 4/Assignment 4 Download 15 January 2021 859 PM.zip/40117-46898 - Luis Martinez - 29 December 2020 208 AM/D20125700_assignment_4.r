

###### Linear regression with dummy variable [5 marks]

### 1. Describe dependent variable pressure and independent variable temperature.



# Loading data:

weatherhistory <- read.csv("weatherhistory.csv")


# Checking data:

head(weatherhistory)

# calling Hmisc library:

library(Hmisc)

# describing temperature

describe(weatherhistory$pressure)

# describing temperature

describe(weatherhistory$temperature)


### 2. Explore the relationship between pressure and temperature.

# Checking for missing vales in the variables:

sum(is.na(weatherhistory$pressure))

sum(is.na(weatherhistory$temperature))

# let�s call ggplot2 library for make the scatterplot:

library(ggplot2)

# Standardizing the variables:

weatherhistory$pressure <- scale(weatherhistory$pressure, center = TRUE, scale = TRUE)
weatherhistory$temperature <- scale(weatherhistory$temperature, center = TRUE, scale = TRUE)

# Now, let�s check for normality in the pressure variable:

pre <- ggplot(weatherhistory, aes(x=weatherhistory$pressure))
pre <- pre + labs(x="stat")
pre <- pre + geom_histogram(binwidth=2, colour="black", aes(y=..density.., fill=..count..))
pre <- pre + scale_fill_gradient("Count", low="#DCDCDC", high="#7C7C7C")
pre <- pre + stat_function(fun=dnorm, color="red",args=list(mean=mean(weatherhistory$pressure, na.rm=TRUE), sd=sd(weatherhistory$pressure, na.rm=TRUE)))
pre

# Now, let´s check for normality in the temperature variable:

tem <- ggplot(weatherhistory, aes(x=weatherhistory$temperature))
tem <- tem + labs(x="stat")
tem <- tem + geom_histogram(binwidth=2, colour="black", aes(y=..density.., fill=..count..))
tem <- tem + scale_fill_gradient("Count", low="#DCDCDC", high="#7C7C7C")
tem <- tem + stat_function(fun=dnorm, color="red",args=list(mean=mean(weatherhistory$temperature, na.rm=TRUE), sd=sd(weatherhistory$temperature, na.rm=TRUE)))
tem

# lets check if there is Relationship between temperature and pressure using a scatterplot:

scatter_chol_Bl <- ggplot(weatherhistory, aes(weatherhistory$pressure, weatherhistory$temperature))
scatter_chol_Bl + geom_point() + geom_smooth(method = "lm", colour = "Yellow", se = F) + labs(x = "pressure", y = "temperature")

# Lets use the spearman correlation to check the relation between the two variables since there is not normality 
# in neither of them.

stats::cor.test(weatherhistory$pressure, weatherhistory$temperature, method='spearman')

# The relationship between pressure and temperature was investigated using a
# spearman correlation. A weak negative correlation was found (r = -0.30; p-value < 2.2e-16),
# So, we could say that there is small correlation between the two variables and it is statistically significant
# according to the p value.

### 3. Build a linear model considering temperature and pressure.

# Calling needed variables for building the model:

library(foreign) #To work with SPSS data
library(lmSupport)#Extra functions for linear model
library(lm.beta)
library(stargazer)

# Building the first model:

model1<-lm(weatherhistory$pressure~weatherhistory$temperature)
anova(model1)
summary(model1)
lm.beta(model1)
stargazer(model1, type="text") #Tidy output of all the required stats

# the findings report is at the end of the question.

### 4. Identify a dummy variable and build extended model considering dummy variable.

# Lets get the precipType variable:

table(weatherhistory$precipType)

# Lets call the car library and recode the preciptype variable:
library (car )
weatherhistory$tipo = recode(weatherhistory$precipType,'0 = 1;1 = 2')

table(weatherhistory$tipo)

# Extending the model with the dummy variable:

model2<-lm(weatherhistory$pressure~weatherhistory$temperature+weatherhistory$tipo)
anova(model2)
summary(model2)
stargazer(model2, type="text")
stargazer(model1, model2, type="text") 


### 5. Report your findings.

# R squared ( 0.0002)indicates that the variables explain 0.02% the variation found 
# in the dependent variable. R2 and adjusted R2 are exactly the same in this case.
# Overall p value on the basis of F-statistic, normally p value less than 0.05 indicate 
# that overall model is significant,so having p-value: 0.0004, it looks is significant.
# According to R squared, that is, explaining just 0.02% of the variance in pressure is 
# explained by the pressure and tipo variables, the model is not good, it explains almost nothing.


##### Multiple Linear Regression [6 marks]

### 1. Explore the relationship between pressure and windspeed.


# checking foe NAS:

sum(is.na(weatherhistory$windSpeed))

# Standardizing the windSpeed variable:

weatherhistory$pressure <- scale(weatherhistory$windSpeed, center = TRUE, scale = TRUE)


summary(weatherhistory$windSpeed)

# Now, let´s check for normality in the windSpeed variable:

wind <- ggplot(weatherhistory, aes(x=weatherhistory$windSpeed))
wind <- wind + labs(x="stat")
wind <- wind + geom_histogram(binwidth=2, colour="black", aes(y=..density.., fill=..count..))
wind <- wind + scale_fill_gradient("Count", low="#DCDCDC", high="#7C7C7C")
wind <- wind + stat_function(fun=dnorm, color="red",args=list(mean=mean(weatherhistory$windSpeed, na.rm=TRUE), sd=sd(weatherhistory$windSpeed, na.rm=TRUE)))
wind

# lets check if there is Relationship between humidity and total rented bikes using a scatterplot:

scatter_chol_Bl <- ggplot(weatherhistory, aes(weatherhistory$windSpeed, weatherhistory$pressure))
scatter_chol_Bl + geom_point() + geom_smooth(method = "lm", colour = "Yellow", se = F) + labs(x = "windSpeed", y = "pressure")

# Lets use the spearman correlation to check the relation between the two variables since there is not normality 
# in neither of them.

stats::cor.test(weatherhistory$pressure, weatherhistory$windSpeed, method='spearman')

# The relationship between pressure and windSpeed was investigated using a
# spearman correlation. A perfect positive correlation was found (r = 1; p-value < 2.2e-16),
# So, we could say that there is total correlation between the two variables and it 
# is statistically significant according to the p value.

### 2. Build a linear model considering (windspeed, humidity, temperature) and pressure.

# Creating the model:

model1=lm(weatherhistory$pressure~weatherhistory$windSpeed+weatherhistory$humidity+weatherhistory$temperature)
stargazer(model1, type="text")
anova(model1)
summary(model1)

### 3. Assess how model meets key assumptions of linear regression.

cooks.distance(model1)

# Plotting Cooks distance:

plot(cooks.distance(model1), ylab="Cook's statistic")


# Creating histogram:
# A density plot of the residuals:

plot(density(resid(model1))) 


# Create a QQ plotqqPlot(model, main="QQ Plot") #qq plot for studentized resid 

leveragePlots(model1) # leverage plots

# Collinearity

vifmodel<-vif(model1)

# Calculate tolerance

1/vifmodel

### 4. Investigate a differential effect by adding dummy variable.

model2=lm(weatherhistory$pressure~weatherhistory$windSpeed+weatherhistory$humidity+weatherhistory$temperature+weatherhistory$tipo)
summary(model2)
plot(model2)

### 5. Investigate an interaction effect for windspeed and dummyvariable.

weatherhistory$intwindSpeed = as.numeric(weatherhistory$tipo)*weatherhistory$windSpeed


model3=lm(weatherhistory$pressure~weatherhistory$windSpeed+weatherhistory$humidity+weatherhistory$temperature+weatherhistory$tipo1+weatherhistory$intwindSpeed)

### 6. Report your findings.


# According to the R squared (1), indicates that for model1, the variables explain 
# 100% the variation found in the dependent variable. R2 and adjusted R2 are 
# exactly the same in this case.
# the p-value: < 2.2e-16, so that means that it is statistically significant as well.
# For, model1, Predicted Pressure = -1.56+ 0.145*windSpeed  + 0*humidity + 0*temperature, then   
# Pressure = -1.56+ 0.145*windSpeed                                  


##### Logistic regression [4 marks]

### 1. Build a model considering diabetes as predictor.


# Loading data:

heartfailure <- read.csv("heartfailure.csv")

# Checking data:

head(heartfailure)

table(heartfailure$diabetes)

logmodel1 <- glm(diabetes ~ anaemia+creatinine_phosphokinase, data = heartfailure, na.action = na.exclude, family = binomial())


# Summary of the model with co-efficients

stargazer(logmodel1, type="text")


# Full summary of the model

summary(logmodel1)

# Chi-square plus significance:

lmtest::lrtest(logmodel1)

### 2. Calculate and analyze odds ratio of the model.

# Exponentiate the co-efficients:

exp(coefficients(logmodel1))

install.packages('AutoModel')

#Calculate confusion matrix:

AutoModel::classification_table(logmodel1, heartfailure$diabetes)

Epi::ROC(form=heartfailure$diabetes ~ heartfailure$anaemia+heartfailure$creatinine_phosphokinase, plot="ROC")

### 3. Extend the model by considering variable age. (Convert the age into categorical data,
### if age � 55 , category 1; age is between 55 and 68 category 2 ; otherwise category 3)


# calling  dplyr library:

library(dplyr)

# recoding the variable:


heartfailure$age <- case_when(heartfailure$age <= 55 ~ 'category 1',
                  between(heartfailure$age, 55, 68) ~ 'category 2',
                  heartfailure$age >= 68 ~ 'category 3'
                  )
heartfailure$age <- as.factor(heartfailure$age)

# Extending the model:

logmodel2 <- glm(diabetes ~ anaemia+age, data = heartfailure, na.action = na.exclude, family = binomial())

# Summary of the model with co-efficients

stargazer(logmodel2, type="text")

# Full summary of the model

summary(logmodel2)

# Chi-square plus significance:

lmtest::lrtest(logmodel2)

Epi::ROC(form=heartfailure$diabetes ~ heartfailure$anaemia+heartfailure$age, plot="ROC")

### 4. Report your finding.

# Regarding the model2, The Chi-square statistic is 12.21, df = -3, which is statistically 
# significant (p < 0.001).
# The z statistic calculated to get the significance of the predictor indicates that 
# just agecategoty 2 is statistically significant,
# According to the sensitivity, Those with "yes" with diabetes correctly predicted by 
# the model, were predicted by the model
# in 45.6% and those with no were predicted in 71.3%.
# Regarding the AUC(percentage of this graph that is under this curve)is 0.613 (.5 is considered 
# weak, 0.8 strong).
