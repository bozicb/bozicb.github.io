#### Linear regression with dummy variable #####
library(readr)
weatherHistory <- read.csv("Kieran/TUD/Stats/Assignment 4/weatherHistory.csv")
View(weatherHistory)

#1. Describe dependent variable pressure and independent variable temperature.
library(psych)
describe(weatherHistory$temperature) #temperature
describe(weatherHistory$pressure) #pressure

#2. Explore the relationship between pressure and temperature.
plot(weatherHistory$temperature, weatherHistory$pressure)

hist(weatherHistory$pressure) #Pressure has some outliers with zero reading for pressure
weatherHistoryAdjusted <-weatherHistory[!(weatherHistory$pressure ==0),]
View(weatherHistoryAdjusted)

hist(weatherHistoryAdjusted$pressure)
hist(weatherHistoryAdjusted$temperature)
plot(weatherHistoryAdjusted$temperature, weatherHistoryAdjusted$pressure) #slight negative relationship on plot
cor.test(weatherHistoryAdjusted$temperature, weatherHistoryAdjusted$pressure, 
         method = "pearson") #correlated with a correlation coefficient of -0.3104 and p-value of < 2.2e-16 

#3. Build a linear model considering temperature and pressure.

model <- lm(weatherHistoryAdjusted$pressure ~ weatherHistoryAdjusted$temperature)
summary(model) #temp has a negative coefficent of -2.530 on pressure with a significance of 0. RMSE figure is 7.394 and R squared = .096


#4. Identify a dummy variable and build extended model considering dummy variable.
library(dplyr)
weatherHistoryAdjusted <- weatherHistoryAdjusted %>% 
  replace(.=="null", "No Rain") # replace null values with "No Rain"
View(weatherHistoryAdjusted)
library(plyr)
count(weatherHistoryAdjusted, 'precipType')
weatherHistoryAdjusted$precipType <- factor(weatherHistoryAdjusted$precipType)
is.factor(weatherHistoryAdjusted$precipType)

model2<-lm(weatherHistoryAdjusted$pressure ~ weatherHistoryAdjusted$temperature + weatherHistoryAdjusted$precipType)
summary(model2)

#5. Report your fndings.
The extended model includes precipType as the dummy variable. Similar to the last model, temp has a negative relationship with pressure
as does rain. Both have negative coefficents. On the other hand Snow has a positvie influence.
All factors are statistically significant per P values.
This is a slughtly better fitting model as the R squared figure has improved to 0.1197

##### Multiple Linear Regression [6 marks] #########
#1. Explore the relationship between pressure and windspeed.

plot(weatherHistoryAdjusted$windSpeed, weatherHistoryAdjusted$pressure) #negative relationship
hist(weatherHistoryAdjusted$windSpeed) #NotNormal
cor.test(weatherHistoryAdjusted$windSpeed, weatherHistoryAdjusted$pressure,  method = "spearman") #The correlation coefficient between windspeed and pressure is -0.227944 and the p-value is < 2.2e-16

#2. Build a linear model considering (windspeed, humidity, temperature) and pressure.
hist(weatherHistoryAdjusted$windSpeed)
library(ggpubr)
ggqqplot(weatherHistoryAdjusted$windSpeed) #Not Normal
hist(weatherHistoryAdjusted$humidity)
ggqqplot(weatherHistoryAdjusted$humidity) #Not Normal

weatherHistoryAdjusted$windSpeed <- (log10(weatherHistoryAdjusted$windSpeed + 1))
hist(weatherHistoryAdjusted$windSpeed) #Transform to more nrmal dist

weatherHistoryAdjusted$humidity <- log10(max(weatherHistoryAdjusted$humidity + 1)- weatherHistoryAdjusted$humidity)
hist(weatherHistoryAdjusted$humidity) #Transform to more nrmal dist


matrix <- data.frame(weatherHistoryAdjusted$temperature, weatherHistoryAdjusted$windSpeed, weatherHistoryAdjusted$humidity)
cor(matrix) #none of the data overly correlated

model3<-lm(weatherHistoryAdjusted$pressure ~ weatherHistoryAdjusted$temperature+weatherHistoryAdjusted$windSpeed+weatherHistoryAdjusted$humidity)
summary(model3) # all variables significant. temp and windspeed negative relationship with pressure. humdity has a positve. R squared = 0.22

# 3. Assess how model meets key assumptions of linear regression.

-- Y values are independent
-- linerar relationship with pressure
-- all variables normal or transformed to normal
-- no or little multicolinaerity 

plot(model3)
qqplot(model3)

#4. Investigate a diferential effect by adding dummy variable.

View(weatherHistoryAdjusted)
table(weatherHistoryAdjusted$precipType) #Dummy

model4<-lm(weatherHistoryAdjusted$pressure ~ weatherHistoryAdjusted$temperature+weatherHistoryAdjusted$windSpeed+weatherHistoryAdjusted$humidity+weatherHistoryAdjusted$precipType)
summary(model4) #Coefficients of dummy variable have a negative influence on Pressure. However,snow is insignificant as the P value is above threshold. 
anova(model4)

#Question 5
model5<-lm(weatherHistoryAdjusted$pressure ~ weatherHistoryAdjusted$windSpeed*weatherHistoryAdjusted$precipType)
summary(model5) #interaction term has no significant effect on the model.

#Question 6
The first model that predicted pressure using temperature, windspeed and humidity had an Rsquared figure of 0.2224. All variables were statistically significant.
Windspeed and temp both had negative relationship, while humidity had positive. When dummy variable prec type was added the R squared figure marginally increased.
Variables that were not not normally distributed were transformed. All dummy variables had a negative relationship with pressure, burt snow was insignificant. interaction 
term between windspeed and prec type was assessed but had no meaningful impact on model. 


#Logistic Regression
heartfailure <- read.csv("Kieran/TUD/Stats/Assignment 4/heartfailure.csv")
attach(heartfailure)
View(heartfailure)
str(heartfailure)

heartfailure$diabetes <- factor(heartfailure$diabetes)
heartfailure$sex <- factor(heartfailure$sex)
is.factor(heartfailure$sex)
heartfailure


logistic <- glm(diabetes ~ sex, data=heartfailure, family="binomial")
summary(logistic) #Diabetes as predicted variable. diabetes = 0.09531 - 0.66710x the patient is male. 0 when patient is female, 1 when male


#Question 2 
exp(coefficients(logistic)) #Woman's odds of getting diabetes are smaller by a factor of 0.51319

# Question 3.
library(dplyr)

heartfailure <- heartfailure %>% mutate(age = case_when(age > 68 ~ '3',
                                             age >= 50  & age <= 68 ~ '2',
                                             age < 55 ~ '1')) #Change Age to categories

heartfailure$age <- factor(heartfailure$age)
is.factor(heartfailure$sex)


logistic2 <- glm(diabetes ~ sex+age, data=heartfailure, family="binomial")
summary(logistic2) #Age does not seem to be a significant influencer on a patient having diabetes. 55-68 is a positive coefficent, 3 is a negative,

#Question 4
#Sex was a significant coefficent when predicting for Diabetes. When we added age we found this was not signifciant. Woman's odds of getting diabetes are smaller by a factor of 0.51319
#AIC score for first model was 403.03, this improved to 399.73 when  age was added.  