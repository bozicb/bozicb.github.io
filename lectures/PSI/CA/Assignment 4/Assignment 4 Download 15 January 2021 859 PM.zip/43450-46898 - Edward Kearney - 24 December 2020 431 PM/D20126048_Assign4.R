
# Assignment 4. D20126048

# Import required libraries
library(psych)
library(car)
library(gmodels)
library(ggplot2)
library(dplyr)
library(lm.beta)
library(stargazer)
library(ggfortify)

# Linear Regression
weatherHistory <- read.csv("weatherHistory.csv")
# 1. Describe pressure and temp.
describe(weatherHistory$pressure)
# Continuous variable with range  of 1046.38 and mean 1003.24. Variable is negatively 
# skewed (-8.42)and highly peaked via analysis of kurtosis.
# Value of pressure=0 appears to be significant outlier (probable error as atmospheric 
# pressure cannot be 0) and should be removed before re-analysis of variable.
weatherHistory <- filter(weatherHistory, pressure != 0)
describe(weatherHistory$pressure)
ggplot(weatherHistory,aes(pressure)) + geom_histogram()
qplot(sample=weatherHistory$pressure,stat='qq')
# Re-analysis of variable following removal of outlier shows reduction in range to 72.6
# minimum of 973.78 and skew and kurtosis of 0.08 and 0.9 respectively where the level of skew
# implies the variable is symmetrical while kurtosis at close to 0 implies a close to normal
# distribution as also displayed by histogram plot in addition to qplot which is close to diagonal.
describe(weatherHistory$temperature)
ggplot(weatherHistory,aes(temperature)) + geom_histogram()
qplot(sample=weatherHistory$temperature,stat='qq')
# Continuous variable with range  of 61.73 and mean 11.93. Skew of 0.09 indicated that variable
# is relatively close to normal distribution. Histogram plot shows near-normal distribution but
# with some outliers and moderate left-skewness in variable. Qplot is also approximates to diagonal
# with slight deviation at higher values.

# 2. Relationship between pressure and temp.
# Investigate plot of variables.
ggplot(weatherHistory,aes(pressure,temperature)) + geom_point()
# Plot is indistinct concerning relationship as negative correlation between variables at higher
# pressure but divergent relationship at lower pressure levels

# Calculation of correlation between variables
cor.test(weatherHistory$temperature,weatherHistory$pressure)
# Pearson correlation between variables is -0.3104 and is highly significant at p<2.2exp-16 (p<.001)
# In addition, the 95% confidence interval ranged from -0.312 to -0.305 which does not cross 0.
# Therefore, likelihood that the variables temperature and pressure are negatively correlated.
# Meteorlogial background information to relationship shows experimentally that
# air density plays a role in the correlation between temperature and pressure 
# because warmer air is less dense than cool air, allowing molecules to have more 
# space to collide with greater force. In cooler air, the molecules are closer together. 
# The proximity results in collisions with less force and lower air pressure.

# 3. Linear model temp. and pressure
lmodel1 <- lm(pressure~temperature,data=weatherHistory)
summary(lmodel1)
anova(lmodel1)
lm.beta(lmodel1)
# Analysis of summary results show R^2 of 0.09638 which indicates that temperature can account for
# 9.6% variation in pressure. The F-statistic of 1.01 exp^04 is significant at p<0.001.
# Therefore, can conclude that regression model is good predictor of temperature.
# Standardised output indicate similar inference from model.

# 4. Dummy variable and extended model
# Conversion of categorical variable to dummy variables in order to assess relationship
# There are three variables in precipitation therefore require two dummy variables and set to set baseline level.
contrasts(weatherHistory$precipType)<-contr.treatment(3,base=3)
lmodel2<-lm(pressure~temperature+precipType,data=weatherHistory)
summary(lmodel2)
# Overall analysis shows that extended model encompassing both temperature and precipitation type now 
# explains 11.98% of variance in pressure. F-statistic also shows that model is significant fit at p<0.001.
# t-statistic for both temperature and dummy variables is highly significant at p<0.001

# 5. Report of Findings
# Analysis detailed after each stage above. Overall can be observed that initial model and inclusion of
# dummy variable are good predictor for portion of pressure. Remaining c88% from extended model
# can be explained by other factors.

# Multiple Linear Regression
# 1. Relationship pressure and windspeed
# Investigate plot of variables.
ggplot(weatherHistory,aes(pressure,windSpeed)) + geom_point()
# Plot indicates weak negative correlation between variables as it shows that windspeed decreases at
# higher pressure readings but width of plot shows that decrease occurs across a large range of pressure
# readings.
cor.test(weatherHistory$windSpeed,weatherHistory$pressure)
# correlation coefficient shows negative correlation of -0.254 which is highly significant at 
# p<2.2exp^16 (<0.001)

# 2. Linear model of (windspeed,humidity,temperature) and pressure
mlmodel1<-lm(pressure~windSpeed + humidity + temperature,data=weatherHistory)
summary(mlmodel1)
# R^2 describes accuracy of overall model whereby a figure of 0.2404 shows that model predictor variables
# explain 24.04% of outcome (pressure) and is highly significant at p<2.2e-16. Adjusted R^2 is equal to R^2
# and shows that it would apply similarly (generalise) with regard to overall population.

# 3. Assessment of model wrt key assumptions of linear regression
#Calculate Cooks distance of model which measures effect of deleting a given observation
cooks.distance(mlmodel1)
# Analysing the output shows that no values are greater than 1 so no cases have an undue
# influence.
# Plot histogram
hist(rstandard(mlmodel1))
# Density plot of the residuals
plot(density(resid(mlmodel1)))
# These both display approximate normal distribution indicating compliance with normality of errors
# assumption
# Qqplot
plot(mlmodel1,main='qq')
# qqplot shows some deviation from straight line at lower levels so not entirely normal 
# leverage plots
leveragePlots(mlmodel1)
plot(mlmodel1, 1) # Linearity of data
# Red-line should be approximately horizontal but some deviation indicates there may be a problem
plot(mlmodel1, 3) # Homogeneity of variance
# Slight increase in variability of variances based on increased fitted values but not significant
# to imply non-constant variances in the residuals errors
# Collinearity-assessed via Variance Inflation Factors
vif(mlmodel1)
sqrt(vif(mlmodel1)) 
# These show that all factor measures are within acceptable levels for tolerance>0.4 
# and Variance Influence<2.5
# While there is some deviation from assumptions concerning compliance with assumptions regarding
# normality and homogeneity of variance neither are assessed as being significant.

# 4. Investigation of differential effect via dummy variable
# Inclusion precipType dummy variable as above
mlmodel2<-lm(pressure~windSpeed + humidity + temperature + precipType,data=weatherHistory)
summary(mlmodel2)
# The model accounts for 24.59% of variance in pressure and generalises well with no differnce
# between R^2 and adj. R^2 values

# 5. Interaction effect of windspeed and dummy variable
# Create interaction term
weatherHistory$intWindPrecip=as.numeric(weatherHistory$precipType)*weatherHistory$windSpeed
mlmodel3<-lm(pressure~windSpeed + humidity + temperature + precipType + intWindPrecip,data=weatherHistory)
summary(mlmodel3)
stargazer(mlmodel3 , type="text" )
# Can conclude via interaction that there is some difference in precipitation between different
# levels of windspeed
# 6. Report findings
# Details wrt each stage discussed above. 

# Logistic Regression
# 1. Model-diabetes as predictor
# Assumed that initial model is baseline model as there is no specifically prescribed independent
# variable in relation to the question. Alternative approach may be to decide on potential variables
# based on prior analysis or subject matter expertise in the field.
# a. Baseline model
logmodel0 <- glm(diabetes~1,data=heartfailure,family=binomial())
summary(logmodel0)
# b. Build additional model using possible variables identified (gender,blood pressure)
# as diabetes is higher among those with high blood pressure and females
# high_blood_pressure 1=HighBp, 0=notHighBp
# Sex 1=Male 0=Female
heartfailure$sex <- ifelse(heartfailure$sex==1,"Male","Female")
heartfailure$high_blood_pressure <- ifelse(heartfailure$high_blood_pressure==1,"High","NotHigh")
logmodel1 <- glm(diabetes~high_blood_pressure + sex,data=heartfailure,family=binomial())
# Initial analysis of model
modelChi <- logmodel1$null.deviance - logmodel1$deviance
modelChi

chidf <- logmodel1$df.null - logmodel1$df.residual
chidf
# 2 degrees of freedom based on num variables in model
chisq.prob <- 1 - pchisq(modelChi, chidf)
chisq.prob
# further reduction in p-value of 0.02 which is also <0.05 therfore also null-hypothesis that model is not better
# than the null model

summary(logmodel1)
# Lower residual shows that model is better at predicting diabetes compared to the null model.
# Based on z statistic sex appears to be significant predictor while highbp is not
# The odds based on being diabetes decrease by 0.6812 based on male gender type

# 3. Calculate and analyse odds-ratio of model
exp(coefficients(logmodel1))
# Being male the odds of diabetes diagnosis is 0.506 compared to being female
# while, based on data, for not high BP is 1.138 compared to highBp 

# 4. Extend model by including age
# Conversion of age to categorical variable for ranges <55 and >=55
heartfailure$CatAge <- cut(heartfailure$age, breaks=c(0,54,68,Inf),labels=c("cat.1","cat.2","cat.3"))
logmodel2 <- glm(diabetes~high_blood_pressure + sex + CatAge,data=heartfailure,family=binomial())
# Initial analysis of model
modelChi1 <- logmodel1$deviance - logmodel2$deviance
modelChi1

chidf1 <- logmodel1$df.residual - logmodel2$df.residual
chidf1

chisq.prob1 <- 1 - pchisq(modelChi1, chidf1)
chisq.prob1
# p-value of 0.02. As this is <0.05 can reject null-hypothesis that model is not better
# than the null model

summary(logmodel2)
# Reduction in deviance shows that inclusion of age parameter provides even better prediction of
# occurrence of diabetes.
# Log odds of having diabetes decrease by -0.587 if in age category three compared to category 1.

# 5. Analysis of results
# Inclusion of age variable provides better prediction of diabetes. Additional comparison of models
# can be undertaken using ANOVA
# Nagelkurke statistic is pseudo R^2 and indicates usefulness of model in addition ROC curve and confusion
# matrix can assess accuracy, specificity, and sensitivity of model respectively.
