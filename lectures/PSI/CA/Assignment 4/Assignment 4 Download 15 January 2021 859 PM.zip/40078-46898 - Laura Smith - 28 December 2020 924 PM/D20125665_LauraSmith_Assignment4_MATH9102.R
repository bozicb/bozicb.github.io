#Assignment 4 - MATH 9102 Prob & Stats
#D20125665 - Laura Smith
#24/12/2020

##Relevant Library Install & Import for Assignment 4:

if(!require(ggplot2))install.packages("ggplot2")
if(!require(psych))install.packages("psych")
if(!require(car))install.packages("car")
if(!require(gmodels))install.packages("gmodels")
if(!require(stats))install.packages("stats")
if(!require(foreign))install.packages("foreign")
if(!require(lmtest))install.packages("lmtest")
if(!require(lm.beta))install.packages("lm.beta")
if(!require(stargazer))install.packages("stargazer")
if(!require(caret))install.packages("caret")
if(!require(Epi))install.packages("Epi")
if(!require(rcompanion))install.packages("rcompanion")

library(ggplot2) #For Graphs & Histograms
library(psych) #Descriptive functions
library(car) #For recoding dummy variables for regression
library(gmodels) #For chi test
library(stats) #Summary stats
library(foreign) #To work with SPSS data
library(lmtest)
library(lm.beta) #More linear model functions
library(stargazer) #For formatting outputs/tables
library(caret)
library(Epi)
library(rcompanion)



###Part 1: Linear Regression witha Dummy Variable

#Read in weather dataset
weather <- read.csv("weatherHistory.csv", header = TRUE)


#Describe pressure variable
describe(weather$pressure)
#Pressure has a mean of 1003.24, a standard deviation of 116.97, a median of 1016.54,
#a range of values between 0 and 1014.38, a skew of -8.42 and a kurtosis of 69.26.
weathHistP <- ggplot(weather, aes(x=pressure)) + geom_histogram(binwidth = 5, colour = "black", fill = "pink")
weathHistP <- weathHistP + labs(x="Pressure", y = "Frequency") 
weathHistP <- weathHistP + stat_function(fun = function(x) (dnorm(x, mean = mean(weather$pressure, na.rm=TRUE), sd = sd(weather$pressure, na.rm=TRUE)) * 5000000), colour = "red", size = 1)
weathHistP
#Pressure has a very high level of negative skew here and therefore is not normal.


#Describe temperature variable
describe(weather$temperature)
#Pressure has a mean of 11.93, a standard deviation of 9.55, a median of 12,
#a range of values between -21.82 and 39.91, a skew of 0.09 and a kurtosis of -0.57.
weathHistT <- ggplot(weather, aes(x=temperature)) + geom_histogram(binwidth = 5, colour = "black", fill = "light blue")
weathHistT <- weathHistT + labs(x="Temperature", y = "Frequency") 
weathHistT <- weathHistT + stat_function(fun = function(x) (dnorm(x, mean = mean(weather$temperature, na.rm=TRUE), sd = sd(weather$temperature, na.rm=TRUE)) * 250000), colour = "blue", size = 1)
weathHistT
#Temperature has a level of skew and kurtosis which sit within the standardized error of normality and is therefore normal.

#Scatter plot to investigate the relationship between Temperature and pressure
weathPTScat <- ggplot(weather, aes(weather$pressure, weather$temperature)) + geom_point() 
weathPTScat <- weathPTScat + labs(x = "Pressure", y = "Temperature") + geom_smooth(method=lm, se=FALSE)
weathPTScat

#From this scatter plot it is clear that the entries with a pressure value of zero obscure the data and span these whole range of temperature values.
#This means they are nt likely to affect the prediction model.
#We will replace the 0 values of pressure with NAs as it would not be possible to have absolute zero pressure and so these values must represent missing values 
#(The description was not provided to confirmthis and I could not find this specific dataset online either so this is an assumption)
weather$pressure <- replace(weather$pressure, weather$pressure==0, NA)
#And replace NAs with the mean for the sake of analysis
weather$pressure[is.na(weather$pressure)] <- mean(weather$pressure, na.rm = T)

#Description of Pressure after zero values have been removed
describe(weather$pressure)
#After Zero values were removed:
#Pressure has a mean of 1016.81, a standard deviation of 7.73, a median of 1016.67,
#a range of values between 973.78 and 1014.38, a skew of 0.08 and a kurtosis of 0.96.
weathHistP2 <- ggplot(weather, aes(x=pressure)) + geom_histogram(binwidth = 5, colour = "black", fill = "pink")
weathHistP2 <- weathHistP2 + labs(x="Pressure", y = "Frequency") 
weathHistP2 <- weathHistP2 + stat_function(fun = function(x) (dnorm(x, mean = mean(weather$pressure, na.rm=TRUE), sd = sd(weather$pressure, na.rm=TRUE)) * 500000), colour = "red", size = 1)
weathHistP2
#Pressure now has a low level of negative skew. But the skew and kurtosis levels are withing the standardized errors so we can take te data to be normal.

#New scatter plot comparing temperature and pressure after pressure zero values removed:
weathPTScat2 <- ggplot(weather, aes(weather$pressure, weather$temperature)) + geom_point() 
weathPTScat2 <- weathPTScat2 + labs(x = "Pressure", y = "Temperature") + geom_smooth(method=lm, se=FALSE)
weathPTScat2
#From a visual inspection:
#There is a negative correlation between temperature and pressure.
#As pressure increases, temperature decreases. 

#Since both variables are normal, pearson test is relevant to test correlation.
cor.test(weather$pressure, weather$temperature, method="pearson")
#The correlation coefficient is -0.308 which means pressure and temperature have a moderate correlation.

#Model based on temperature predicting pressure
modelTP <- lm(weather$pressure ~ weather$temperature)
summary(modelTP)
lm.beta(modelTP)
stargazer(modelTP, type="text")
#F-static is 1.012e+04, p-value is < 2.2e-16 and so is statistically significant.
#Adjusted r squared is 0.095 which means that temperature explains only 9.5% of the variance of pressure. 

#We are going to use precipitation type as a dummy variable as this has only rain and snow as categorical values and so can be converted to a binary predictor, ideal as a dummy value.
#From this we can see if whether it rained or snowed have an impact on the ability for temperature to predict pressure. 

#Summary of precipitation type variable
table(weather$precipType)

#Data Prep of the PrecipType variable. Change "null"s to NAs
weather$precipType <- replace(weather$precipType, weather$precipType == "null", NA)
#Recode rain & Snow to be a binary value, here 0 will indicate rain and 1 snow. 
weather$precipType = recode(weather$precipType,'"rain" = 0;"snow" = 1')
#Check this recoding has completed correctly
head(weather)
table(weather$precipType)

#Use dummy variable in new model
modelTP2 <- lm(weather$pressure ~ weather$temperature + weather$precipType)
anova(modelTP2)
summary(modelTP2)
lm.beta(modelTP2)
stargazer(modelTP2, type="text")
#F-statistic is 6408 and p-value is 2.2e-16 for this model with a dummy variable, so the model is statistically significant. 
#R squared is 0.1178 and so can account for 11.8% of the temperature variability when our dummy variable is included. 

#Model comparisson bwtween including the dummy variable or prcipitation type and not including this factor
stargazer(modelTP, modelTP2, type="text")
#Comparing the two models, adding in a dummy variable has improved the predictive model slightly, with predictability rising from 9.5% to 11.8%.


##Part 2: Multiple Linear Regression


#Describe the windspeed variable so we know how to use his in our pressure model:
describe(weather$windSpeed)
#Wind Speed has a mean of 10.81, a standard deviation of 6.91, a median of 9.97,
#a range of values between 0 and 63.85, a skew of 1.11 and a kurtosis of 1.77.
weathHistWS <- ggplot(weather, aes(x=windSpeed)) + geom_histogram(binwidth = 5, colour = "black", fill = "bisque")
weathHistWS <- weathHistWS + labs(x="Wind Speed", y = "Frequency") 
weathHistWS <- weathHistWS + stat_function(fun = function(x) (dnorm(x, mean = mean(weather$windSpeed, na.rm=TRUE), sd = sd(weather$windSpeed, na.rm=TRUE)) * 500000), colour = "chocolate4", size = 1)
weathHistWS
#Wind Speed is positively skewed, however its values for skew and kurtsis are sill within the standardized levels of error levels both being less than 2.
#We can therefore take wind speed to be normally distributed.

#Scatter plot of Pressure vs wind speed to show relationship
weathPWSScat <- ggplot(weather, aes(pressure, windSpeed)) + geom_point() 
weathPWSScat <- weathPWSScat + labs(x = "Pressure", y = "Wind Speed") + geom_smooth(method=lm, se=FALSE)
weathPWSScat
#Visually there looks to be a weak negative correlation between these two variables. 

#Since both variables are withing the skew and kurtosis standardized errors and so are taken to be normal, Pearson test is relevant 
cor.test(weather$pressure, weather$windSpeed, method="pearson")
#The correlation coefficient is -0.251 which means pressure and windspeed have a weak correlation.


#Model based on WindSpeed predicting pressure
modelPWS <- lm(weather$pressure ~ weather$windSpeed)
summary(modelPWS)
lm.beta(modelPWS)
stargazer(modelPWS, type="text")
#F-static is 6497, p-value is < 2.2e-16 and so this model is statistically significant.
#Adjusted r squared is 0.063 which means that windspeed explains only 6.3% of the variance of pressure. 

#Model based on humidity predicting pressure
modelPH <- lm(weather$pressure ~ weather$humidity)
summary(modelPH)
lm.beta(modelPH)
stargazer(modelPH, type="text")
#F-static is 147.1, p-value is < 2.2e-16 and so this model is statistically significant.
#Adjusted r squared is 0.002 which means that humidity explains almost none of the variance of pressure. 

#Linear model considering windspeed, humdity & temperature effect on pressure. 
modelPTHWS <- lm(weather$pressure ~ weather$windSpeed + weather$humidity + weather$temperature)
anova(modelPTHWS)
summary(modelPTHWS)
lm.beta(modelPTHWS)
stargazer(modelPTHWS, type="text")
#F-static is 9978, p-value is < 2.2e-16 and so this model is statistically significant.
#Adjusted r squared is 0.237 which means that all of these variables together can account for 23.7% of the variance of pressure.


#Before we assess if the assumptions of linear regressions are met, we must also describe humidity as this hasn't been conducted yet. 

#Describe humidity
describe(weather$humidity)
#Wind Speed has a mean of 0.73, a standard deviation of 0.2, a median of 0.78,
#a range of values between 0 and 1, a skew of -0.72 and a kurtosis of -0.46.
weathHistH <- ggplot(weather, aes(x=humidity)) + geom_histogram(binwidth = 0.1, colour = "black", fill = "darkseagreen1")
weathHistH <- weathHistH + labs(x="Humidity", y = "Frequency") 
weathHistH <- weathHistH + stat_function(fun = function(x) (dnorm(x, mean = mean(weather$humidity, na.rm=TRUE), sd = sd(weather$humidity, na.rm=TRUE)) * 10000), colour = "forestgreen", size = 1)
weathHistH
#Humidity negatively skewed, however its values for skew and kurtsis are sill within the standardised levels of error
#we can therefore take wind speed to be normally distributed.

#Scatter plot of Pressure vs humidity to show linear relationship. 
weathPHScat <- ggplot(weather, aes(pressure, humidity)) + geom_point() 
weathPHScat <- weathPHScat + labs(x = "Pressure", y = "Humidity") + geom_smooth(method=lm, se=FALSE)
weathPHScat
#There is weak positive correlation between pressure & humidity


##Assessing the assumptions of linear regression:
#1. Linear Relationship: there is a linear relationship, albeit weak in some cases, between the dependent variables, temperature, wind speed and humidity, with pressure (See scatter plots plotted above for each.)
#2. Independence: While this is time series data, the unpredictability of weather patterns in general mean there is no single correlation running through any of teh variables.
#3. Homoscedasticity: Humidity, temperature & wind speed all have a constant variance with pressure, this can be seen in the scatter plots.
#4. Normality: All of the variables are normaly distributed as proved at various stages in the code above.


#Linear model considering windspeed, humdity & temperature effect on pressure adding in teh dummy variable of precipitation type also. 
modelPTHWSDum <- lm(weather$pressure ~ weather$windSpeed + weather$humidity + weather$temperature + weather$precipType)
anova(modelPTHWSDum)
summary(modelPTHWSDum)
lm.beta(modelPTHWSDum)
stargazer(modelPTHWSDum, type="text")
#F-static is 7711, p-value is < 2.2e-16 and so this model is statistically significant.
#Adjusted r squared is 0.2433 which means that all of these variables together can account for 24.3% of the variance of pressure.

stargazer(modelPTHWS, modelPTHWSDum, type="text")
#There is an increase in adjusted r squared when a dummy variable is added to the model, from 0.237 to 0.243, so there is a very minor improvement with the addition of this.



###Part 3 Logistic Regression

#Read in heart failure dataset
heartFailure <- read.csv("heartfailure.csv", header = TRUE)

#Summarize diabetes variable
table(heartFailure$diabetes)

#Logistic regression model based solely on the diabetes variable as a predictor.
logmodelD <- glm(diabetes ~ 1, data = heartFailure, na.action = na.exclude, family = binomial())
#Summaries of this model with co-efficients
summary(logmodelD)
stargazer(logmodelD, type="text")
#Chi-square test plus significance
lmtest::lrtest(logmodelD)
#Pseudo Rsquared plus Chi-square of the model
rcompanion::nagelkerke(logmodelD,restrictNobs=TRUE)
#Exponentiate the co-efficients to find the odds ratio
exp(coefficients(logmodelD))
#The odds ratio for a patient having diabetes in this dataset are 0.72.

#***Can't get Below command to work as Caret package won't install. Haven't been able to fix.
#***Also tried to use AutoModel and classification table as mentioned in notes and RMD TO accompany class notes but this is an outdated package and also wouldnb't install.
#Calculate confusion matrix is what I'd like to do next if I could get it working! 
confusionMatrix(logmodelD, heartFailure$diabetes)

#Recode age varablie based on age ranges and values provided. 
heartFailure$age <- replace(heartFailure$age, heartFailure$age < 55, 1)
heartFailure$age <- replace(heartFailure$age, heartFailure$age > 54 & heartFailure$age < 69, 2)
heartFailure$age <- replace(heartFailure$age, heartFailure$age > 68, 3)
#Summarize to check this has been completed successfully
table(heartFailure$age)

#New logistic regression model including age as a predictor 
logmodelDA <- glm(diabetes ~ age, data = heartFailure, na.action = na.exclude, family = binomial())
#Summaries of this model
summary(logmodelDA)
stargazer(logmodelDA, type="text")
#Chi-square plus significance
lmtest::lrtest(logmodelDA)
#Pseudo Rsquared plus Chi-square of the model
rcompanion::nagelkerke(logmodelDA,restrictNobs=TRUE)

#Unable to report fully on this one as I can't get the confusion matrix working or the Cox & Snell and Nagelkerke values to work, sorry! :(
