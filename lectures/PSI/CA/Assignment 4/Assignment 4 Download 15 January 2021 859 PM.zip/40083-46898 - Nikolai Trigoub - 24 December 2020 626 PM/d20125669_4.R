if(!require(psych))install.packages("psych")
if(!require(car))install.packages("car")
if(!require(mlogit))install.packages("mlogit")
if(!require(stargazer))install.packages("stargazer")
if(!require(dplyr))install.packages("dplyr")

library(psych)
library(car)
library(mlogit)
library(stargazer)
library(dplyr)


# Linear regression with dummy variable [5 marks]
weatherhistory1 <- read.csv("weatherhistory.csv")


# 1. Describe dependent variable pressure and independent variable temperature.
describe(weatherhistory1$pressure)
describe(weatherhistory1$temperature)

# 2. Explore the relationship between pressure and temperature.
# 3. Build a linear model considering temperature and pressure.

lm1<-lm(pressure ~ temperature, data = weatherhistory1)
lm1

summary(lm1)

#Multiple R Squared =  0.967e-05, which means temperature accounts for 0.967e-05% of the vairaiton in pressure)

sqrt(0.967e-05)

0.967e-05

#Pearsons Correlation Coefficient is 0.0031 for Temperature & Pressure
# Pressure =1004 + (-0.066 × temperature)


#4. Identify a dummy variable and build extended model considering dummy variable. 
#5. Report your findings.

weatherhistory1$Rain = ifelse(weatherhistory1$precipType=='rain', 1, 0) 

lmrain<-lm(pressure ~ temperature + Rain, data = weatherhistory1)
lmrain

summary(lmrain)

#Multiple R Squared =  0.000124, which means temperature &  accounts for 0.000124% of the variation in pressure)

sqrt(0.000124)

0.01113553

# Pressure =1006.8 + (-0.01242 × temperature) + (-4.25 x Rain))



# Multiple Linear Regression [6 marks]

weatherhistory2 <- read.csv("weatherhistory.csv")
# 1. Explore the relationship between pressure and windspeed.

lm2<-lm(pressure ~ windSpeed, data = weatherhistory2)
lm2

summary(lm2)

#Multiple R Squared =  0.002427, which means temperature accounts for 0.0025% of the variationin pressure)

sqrt(0.002427)

#Pearsons Correlation Coefficient is 0.049 for Temperature & Pressure
# Pressure = 1012 + (-0.833 × windSpeed)

# 2. Build a linear model considering (windspeed, humidity, temperature) and pressure. 
lm3 <- lm(pressure ~ windSpeed + humidity + temperature, data = weatherhistory2)
summary(lm3)


# 3. Assess how model meets key assumptions of linear regression.
# 4. Investigate a differential effect by adding dummy variable.
# 5. Investigate an interaction effect for windspeed and dummyvariable.
# 6. Report your findings.


# Logistic regression [4 marks]
heartfailure <- read.csv("heartfailure.csv", stringsAsFactors = 1)

# 1. Build a model considering diabetes as predictor.

heartModel<-glm(DEATH_EVENT ~ diabetes, data = heartfailure, family = binomial)

summary(heartModel)
stargazer(heartModel, type="text")

#calculate model Chi Square
modelChi <- heartModel$null.deviance - heartModel$deviance
modelChi

#Calculate Degrees of Freedom

heartchidf <- heartModel$df.null - heartModel$df.residual
heartchidf

heartchisq.prob <- 1 - pchisq(modelChi, heartchidf)
heartchisq.prob 

#p-value value is .97 meaning the model is better than chance at predicting the outcome 

#Hosmer and Lemeshow R^2


R2.hl<-modelChi/heartModel$null.deviance
R2.hl

#Cox and Snell R^2
R.cs <- 1 - exp ((heartModel$deviance - heartModel$null.deviance)/299) 
R.cs

#Nagelkerke R^2
R.n <- R.cs /(1-(exp(-(heartModel$null.deviance/299)))) 
R.n

# 2. Calculate and analyze odds ratio of the model.

heartModel$coefficients
exp(heartModel$coefficients)
exp(confint(heartModel))

#We can be fairly confident that the population value of the odds ratio lies between 0.6 and 1.62. As the lower limit is below 1 we can no trust that diabetes increases the odds of Death_Event

# 3. Extend the model by considering variable age. (Convert the age into categorical data, if age < 55 , category 1; age is between 55 and 68 category 2 ; otherwise category 3)
# 4. Report your finding.
heartfailure <-heartfailure %>%
  mutate(age=replace(age, age<55, "category 1")) %>%
  mutate(age=replace(age, age>68, "category 3")) %>%
  mutate(age=replace(age, age>=55 & age<=68, "category 2")) %>%
  as.data.frame()


heartfailure

str(heartfailure)

heartfailure$age <- as.factor(heartfailure$age)

heartModel2 <- glm(DEATH_EVENT ~ diabetes + age, data = heartfailure, family = binomial())

heartModel2

summary(heartModel2)
stargazer(heartModel2, type="text")

#calculate model Chi Square
modelChi2 <- heartModel2$null.deviance - heartModel2$deviance
modelChi2

#Calculate Degrees of Freedom

heartchidf2 <- heartModel2$df.null - heartModel2$df.residual
heartchidf2

heartchisq.prob2 <- 1 - pchisq(modelChi2, heartchidf2)
heartchisq.prob2 

#p-value value is .97 meaning the model is better than chance at predicting the outcome 

#Hosmer and Lemeshow R^2


R2.hl2<-modelChi2/heartModel2$null.deviance
R2.hl2

#Cox and Snell R^2
R.cs2 <- 1 - exp ((heartModel2$deviance - heartModel2$null.deviance)/299) 
R.cs2

#Nagelkerke R^2
R.n2 <- R.cs2 /(1-(exp(-(heartModel2$null.deviance/299)))) 
R.n2

#Odds Ratio
heartModel2$coefficients
exp(heartModel2$coefficients)
exp(confint(heartModel2))

