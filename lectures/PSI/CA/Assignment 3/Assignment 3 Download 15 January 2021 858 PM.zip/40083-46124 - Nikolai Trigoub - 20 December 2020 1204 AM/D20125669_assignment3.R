if(!require(dplyr))install.packages('dplyr')
if(!require(BBmisc))install.packages('BBmisc')
if(!require(ggplot2))install.packages('ggplot2')
if(!require(lattice))install.packages('lattice')
if(!require(Hmisc))install.packages('Hmisc')
if(!require(corrplot))install.packages('corrplot')
if(!require(psych))install.packages('psych')
if(!require(factoextra))install.packages('factoextra')
if(!require(ggplot2))install.packages('ggplot2')
if(!require(psych))install.packages('psych')
if(!require(gmodels))install.packages('gmodels')


library(dplyr)
library(BBmisc)
library(ggplot2)
library(lattice)
library(Hmisc)
library(corrplot)
library(psych)
library(factoextra)
library(ggplot2)
library(psych)
library(gmodels)
### PCA
#1. What do the eigenvectors of the covariance matrix give us? [2 marks]

#They give us the axes with the greatest variance and covariance. They allows us to reorientate the X & Y axis to axes represented by the Principal Component

#2. When can we decide to compress the data in PCA process? Explain the effects if any. [2 marks]

# Once all but one Collinear variables have been removed. Removing too many variables can remove inforamtion and weakne the fit of the model
# When varibles get compressed with PCA, they become less interpretable as you are left with the principle components. 

#3. Read the glass identification data provided. Apply PCA algorithm to reduce the dimensions. Analyze your findings. [5 marks]
#Note: Read glass dataset. Kindly save the read dataset in a variable called “glass”. Do not change the variable name. For ex: glass <- read.csv(”glassidentification.csv”).

glass <- read.csv('glassidentification.csv', header = T)
#Removing all categorcial and index variables
glass = select(glass, -1, -2, -12)                 

# Obtain summary stats
str(glass)

#Create a correlation matrix
glassMatrix<-cor(glass)
round(glassMatrix, 2)
rcorr(as.matrix(glass))

#Visualise the correlation matrix numerically
corrplot(glassMatrix, method="number")


#Visualise @ 0.06 Confidence level as the p value of SI/RI is 0.06, close to 0.05 and has a good correlation (.54)
res1 <-  cor.mtest(glassMatrix, conf.level = .94)
corrplot(glassMatrix, p.mat = res1$p, type="lower", sig.level = .06)

#Show P Value for non-significant results
corrplot(glassMatrix, p.mat = res1$p, type="lower",insig = "p-value")

#We can see there is no singular correlation, but CA/RI could suggest multicollinearity

#Bartlett Test
cortest.bartlett(glass)


#KMO Test
KMO(glass)

det(glassMatrix)


# Det is 0.0001530649 - Greater than 0.00001. Bartletts Test of Sphericity is significant with p < 0.05. KMO is unacceptable at 0.13


#Run PCA algorithm cutting at 0.3 correlation

fa.diagram(pc1)
fa.sort(pc1$loading)
pc1$communality

#Scree Plot
plot(pc1$values, type = "b")
#There seem to be mulitple inflection points so we will take all factors greater than 1 (Kaisers Rule) (factor 1, 2, 3, 4)


pc1$Vaccounted
# Eigenvalues 

pc1$values 

pcf=princomp(glass)
get_eigenvalue(pcf)
#First 4 factors explain 94.9% of the variance
fviz_eig(pcf, addlabels = TRUE, ylim = c(0, 50))#Visualise the Eigenvalues
fviz_pca_var(pcf, col.var = "black")
fviz_pca_var(pcf, col.var = "cos2", gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),repel = TRUE 

             
#Visualise how each of the samples affects the dimensions              
var <- get_pca_var(pcf)
corrplot(var$contrib, is.corr=FALSE)         

fviz_contrib(pcf, choice = "var", axes = 1, top = 10)
fviz_contrib(pcf, choice = "var", axes = 2, top = 10)
fviz_contrib(pcf, choice = "var", axes = 3, top = 10)
fviz_contrib(pcf, choice = "var", axes = 4, top = 10)
                         
#For Dimension 1 which explains 47.6 % of Variance. Mg and CA are the major contributors to Dim 1    
#For Dimension 2 which explains 26.3 % of Variance. CA and Mg and to a lesser extent Na are the  contributors to Dim 2          
#For Dimension 3 which explains 10.8 % of Variance. Si and Na are the major contributors to Dim 3              
#For Dimension 4 which explains 10.2 % of Variance  K and Si and to a lesser extent Na are the  contributors to Dim 4       


###Difference
#Read in heartdisease CSV - saving as bike dataset
heartdisease <- read.csv('heartdisease.csv')


#1. Are there any differences between patients having different chest pain to the angiographic disease status? Report your findings. [Hint: Consider variables ChestPain and AHD] [5 marks]

#As both variables are categorical we will use the Chi Square Test

CrossTable(heartdisease$ChestPain, heartdisease$AHD, fisher = TRUE, chisq = TRUE, expected = TRUE, sresid = TRUE, format = "SPSS")

#The p-value is highly significant (X2=1,81.81, p<.001) indicating that the Chest Pain had an effect on AHD Status.The Fishers Test being highly significant (>.001) shows we should reject the null hypothesis


#2. Is there any difference between cholesterol level and angiographic disease status? Report your findings. [Hint: Consider variables Chol and AHD] [5 marks]
#Note: Read heartdisease dataset for Q1. and Q2. Kindly save the read dataset in a variable called “heartdisease”. Do not change the variable name. For ex: heartdisease <- read.csv(”heartdisease.csv”).


#Freq for Free Sulfur
ggChol <- ggplot(heartdisease, aes(x=Chol))
ggChol <- ggChol + labs(x="Chol") 
ggChol <- ggChol + geom_histogram(binwidth=5, colour="black", aes(y=..density.., fill=..count..))
ggChol <- ggChol + scale_fill_gradient("Count", low="#DCDCDC", high="#7C7C7C")


ggChol + stat_function(fun = dnorm, args = list(mean = mean(heartdisease$Chol, na.rm = T), sd = sd(heartdisease$Chol, na.rm = T)), colour = "red", size = 1)

#Q-Q Plots for Free Sulfur

qqnorm(heartdisease$Chol)
qqline(heartdisease$Chol, col=2)


#Calculate Kurtosis (4.35) & Skew (1.12)
describe(heartdisease$Chol)

#Shapiro Wilk Normality Test

shapiro.test(heartdisease$Chol)


#Based primarily on the Kurtosis, QQPlot - we will define the data as Non-Normal and conduct a Mann Whitney U Test


model2 <-wilcox.test(Chol ~ AHD, data = heartdisease)
model2

# The AHD Status affected the Chol level significantly (W - 9798.5, p = 0.03536)


#3 Are there any differences between the free sulfur dioxide and quality of the wine? Report your findings. [Hint: Consider variables free sulfur dioxide and quality] [5 marks]
wine <- read.csv('winequality-red.csv')

#Check Free Sulphur Dioxide for Normality

#Freq for Free Sulfur
ggWine <- ggplot(wine, aes(x=free_sulfur_dioxide))
ggWine <- ggWine + labs(x="free_sulfur_dioxide") 
ggWine <- ggWine + geom_histogram(binwidth=10, colour="black", aes(y=..density.., fill=..count..))
ggWine <- ggWine + scale_fill_gradient("Count", low="#DCDCDC", high="#7C7C7C")


ggWine + stat_function(fun = dnorm, args = list(mean = mean(wine$free_sulfur_dioxide, na.rm = T), sd = sd(wine$free_sulfur_dioxide, na.rm = T)), colour = "red", size = 1)

#Q-Q Plots for Free Sulfur

qqnorm(wine$free_sulfur_dioxide)
qqline(wine$free_sulfur_dioxide, col=2)

#Calculate Skew & Kurtosis

describe(wine$free_sulfur_dioxide)

#Skew = 1.25, Kurtosis = 2.01

#Shapiro Wilk Normality Test

shapiro.test(wine$free_sulfur_dioxide)


model3 <-wilcox.test(wine$free_sulfur_dioxide ,wine$quality)
model3

# The Free Sulfur Diox Status affected the Quality level significantly (W - 2200235, p < 2.2e-16)


###Predictive statistics

#1. Model the relationship between humidity and total rented bikes. How good is the model? [Hint: Consider the variables hum and cnt] [3 marks]

#Read in bikesharing CSV - saving as bike dataset
bike <- read.csv('bikesharing.csv', header = T)

#We would expect there to be a negative correlation between humidity and total rented bikes

#Plot humidity vs total bike rentals 
plot(bike$hum, bike$cnt)

#Conduct a Pearson's correlation test - Showing a weak negatice correlation (-0.1)

cor.test(bike$hum, bike$cntNorm, method='pearson')

ggplot2

#Create a histogram for Bike Rental Count showing that this response variable it is approximately normally distributed

histogram(bike$cnt)

#Fit the linear model

modelbike<-lm(bike$cnt~bike$hum)
modelbike


#How good is the model? Weak Pearson correlation suggests that the model is poor, as does the plot. 

#Now to create the sum of squares & the residual sum of squares
#Anova shows this is a lot of difference with a p value of 0.00645

anova(modelbike)
summary(modelbike)

#F-statistic: 7.462 on 1 and 729 DF,  p-value: 0.006454, Multiple R-squared:  0.01013
#Humidity(Hum) explains 1% of the variance in Bike Rental Count (CNT). The low F Statistic suggests that the model is not statistically significant


#2. Include a dummy variable (working day) to the model and compare the relationship. Report your findings. [3 marks]

#We now add the workinday variable to the model 0 (Weekend), 1 (Weekday)

modelbike2<-lm(bike$cnt~bike$hum+bike$workingday)
anova(modelbike2)
summary(modelbike2)

#F-statistic: 5.236 on 2 and 728 DF,  p-value: 0.005525, Adjusted R-squared:  0.01147 
#F-statistic has decreased, and the R squared has slight increased from 1% to 1.1% of variance suggesting a slight improvement of the model




