
# Assignment 3. D20126048

# Import required libraries
library(psych)
library(car)
library(gmodels)
library(ggplot2)
library(pgirmess)

# PCA
# 1. Eigenvectors of covariance matrix
# These are the directions in which data varies the most whereby the first eigenvector is the 
# direction of greatest variance within the data the second eigenvector is the 
# direction of greatest variance among those that are orthogonal to the first vector.
# The goal of PCA is to identify directions (or principal components) along which the 
# variation in the data is maximal.

# 2. Can decide to compress data as final step in PCA process as it may reduce
# correlations present if performed earlier.
# Compression may reduce some of the correlation present in data.

# 3. PCA-glass identification dataset
glass <- read.csv("glassidentification.csv")
head(glass)
# Exclude id columns from analysis
glassdata <- glass[,3:12]
# Find the Covariance matrix of the data
S <- cov(glassdata)
S
# Total variance is sum of eigenvalues (diag.) of cov matrix
sum(diag(S))
# Compute eigenvalues and corresponding eigenvectors of S
s.eigen <- eigen(S)
s.eigen
# Eigenvector represent principal components of S while eigenvalues used to find
# proportion of total variance explained by the components.
for (s in s.eigen$values){
  print(s/sum(s.eigen$values))
}
# First two principal components account for 81.07% of variance
# Generation of correlation matrix
glassmatrix <- cor(glassdata)
round(glassmatrix,2)
# No values outside diagonal >0.9 => multicollinearity not expected to be issue
cortest.bartlett(glassmatrix)
# p-value < 0.001
KMO(glassdata)
# KMO of 0.19 < min requirement of 0.5 indicates additional sampling required
# both RI and T variables are above 0.8 which indicate very good range for these
# items
det(cor(glassdata))
# Multicollinearity may be an issue but not strictly problem as doing PCA
pcglass1 <- principal(glassdata,nfactors = length(glassdata),rotate = "none")
pcglass1
# Component 1 (PC1) explains 30.6% (3.06/10) of variance with the first 5 components
# explaining 88.4%
#Scree plot of eigenvalues
plot(pcglass1$values,type="b")
# Point of inflexion at approx. either 3 or 6 so could justify extracting this num. components
pcglass2 <- principal(glassdata,nfactors = 6,rotate = "none")
pcglass2
# Values of >0.95 are considered good fit and PCA returns value of 0.99
# Reproduced correlations of pca
factor.model(pcglass2$loadings)
# Difference between reproduced and actual correlation matrix obtained from
# residuals
residuals <- factor.residuals(glassdata,pcglass2$loadings)
residuals

# Difference
heartdisease <- read.csv("heartdisease.csv")
# 1. Diff between patients having diff chest pain to AHD (disease status)
# Chest pain divided into different groupings AHD-binary yes/no
# Recode AHD variable to binary 1:0
heartdisease$AHD = recode(heartdisease$AHD,'"Yes"=1;"No"=0')
# Perform Chi-SQuare (Fisher-Exact) test using Crosstable function
# CrossTable(predictor, outcome, fisher = TRUE, chisq = TRUE, expected = TRUE)
CrossTable(heartdisease$ChestPain, heartdisease$AHD, fisher = TRUE, chisq = TRUE, expected = TRUE, sresid = TRUE)
# Assumption that all expected frequencies > 5 is met as per second row of each
# variable cell in the result otherwise additional data collection required.
# The value of p (1.25e-17) is highly significant (p<0.001) indicating that the 
# type of chest pain (of 4 diff. indep. groups) had an impact on the disease status diagnosis.
# The value of the Fisher test is also <0.001 therefore reject null-hypothesis of no difference.

# 2. Diff between chol. level and AHD
# Chol. ranges from min of 126 to max 564 with mean of c247
# Group chol. levels across suitable range within 6 equally sized bins.
heartdisease$CholGroup <- cut_number(heartdisease$Chol,6)
# Perform Chi-SQuare (Fisher-Exact) test using Crosstable function
CrossTable(heartdisease$CholGroup, heartdisease$AHD, fisher = TRUE, chisq = TRUE, expected = TRUE, sresid = TRUE)
# Assumption that all expected frequencies > 5 is met as per second row of each
# variable cell in the result otherwise additional data collection or smaller 
# number of groups required.
# The value of p is not <0.001 therefore chol level within relevant ranges does not
# have an impact on AHD status. Fishers exact also returns p >.001 so do not reject
# the null hypothesis.

# 3. Diff between free sulfur dioxide and wine quality (score between 0 and 10)
# Wine quality is ordinal variable => non-parametric
wine <- read.csv("winequality-red.csv")
# Sulfur dioxide ranges from min. 1 to max. 72 with mean c15.87
# Group sulfur dioxide levels across suitable range
wine$SulfGroup <- cut_number(wine$free_sulfur_dioxide,5)
# As quality level is ordinal variable (3->8) must apply non-parametric test-Kruskal Wallis
kruskal.test(quality ~ SulfGroup, data = wine)
# Returns p-value of 0.0752 is not <0.001 and therefore free sulfur dioxide in the
# main does not have an impact on the quality score level.
# However, additional testing can be undertaken to assess if difference based on specific
# levels rather than across all levels
kruskalmc(quality ~ SulfGroup, data = wine, cont='two-tailed')
# This indicates that while there is no difference at all levels that there is
# a difference between the upper level of free sulfur dioxide(24->72) and the 
# lowest level (6->11).

# Predictive Statistics
bike <- read.csv("bikesharing.csv")
# 1. Linear model of relationship between bike rental and humidity
model1 <- lm(bike$cnt~bike$hum)
model1
anova(model1)
summary(model1)
# R^2 of 0.01013 indicates that humidity can account for c10% of variation in 
# bike rental figures. Intercept shows that with humidity of 0 a figure of 5364 bikes
# will be rented and predictor variable (hum) has inverse relationship on this
# variable (-1369.1).
# F-statistic of 7.462 is significant at p<.001

# 2. Include dummy variable (working day), currently binary data, in the model.
# There are only two groups in working day => 1 (2-1) dummy variable(s) required.
# Not necessary to recode dummy variable as assigned per above criteria.
model2 <- lm(bike$cnt~bike$hum + bike$workingday)
model2
anova(model2)
summary(model2)
# Adjusted R^2 indicates that model accounts for 11.47% of variance rather
# than 10% for model 1.
# F-statistic of 5.236 significant at p<.01