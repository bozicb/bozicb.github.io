

#### PCA

### QESTION 1. What do the eigenvectors of the covariance matrix give us? [2 marks]



# In a covariance matrix, the eingenvectors can give you a clear visualization of the 
# corresponding probability of the distribution. They give us the direction of the 
# axes line. in other words, eingenvectors showing the directions in which data varies the most


### QESTION 2. When can we decide to compress the data in PCA process? Explain the effects if any.
### [2 marks]


# PCA is a technique of dimension reduction. we use it to reduce the dimension of the data. 
# When we deal with data usually variables are correlated and these correlations cause redundancy 
# in the information that can be got by the data set. So, in order to reduce this, we use PCA to 
# transform the original variables to the linear combination of these variables which are independent.
# We can decide use this technique to do a regression to predict, in principal component 
# regression, for classification purposes, etc.


### QUESTION 3. Read the glass identification data provided. Apply PCA algorithm to reduce the
### dimensions. Analyze your findings. [5 marks]


# loading the data:

glass <- read.csv("glassidentification.csv")
head(glass)

# Let�s chcking of there are missing values:

which(is.na(glass))

# Let�s use this library to visualize the correlation of the variables:

library("ggcorrplot")

# Let�s create the matix correlation:

glassMatrix <- cor(glass)
round(glassMatrix, 2)
Hmisc::rcorr(as.matrix(glass))

# Let�s visualize nicer showing the co-efficients:

ggcorrplot::ggcorrplot(glassMatrix, lab=TRUE, title = "Correlation matrix for glass data",  type="lower")

# Let�s calculate the variance that exists

apply(glass, 2, var)

# Let�s use the method prcomp to centralize the mean and scale each of the variables to 
# reduce the variability

apc <- prcomp(glass, center = TRUE, scale = TRUE)

# Let�s check it:

print(apc)

# Here can see the standard deviation of each of the components and their respective rotations

# Let�s visualize the analysis:

plot(apc, type = "l")

# We can see the analysis of the 12 principal components with their respective variances, 
# we can see that to the extent that the latter components descend, they hardly have a presence, 
# their variance is very low.

# Let�s make a summary of the PCA:

summary(apc)

# Here we can see in the cumulative proportion up to what percentage of variability  it is 
# explained with the PC that we want to use.If we want to explain until the 98% we will be able 
# to use up to PC8 to cover it.

# If i would like for example check the PC1 for all the elements of the glass dataframe this would 
# be like this:

pc1 <- apply(apc$rotation[,1]*glass,1,sum)
pc1

# Lets call all packes needed to make a wider analysis as we lectured:

library("corrplot")
library(REdaS)
library("GPArotation")
library("factoextra")
library("nFactors")
library("Hmisc")
library("psych")

# Doing Analysis:

pca <-  principal(glass, nfactors = 12, rotate = "none")
pca <-  principal(glass, nfactors = length(glass), rotate = "none")
pca 
psych::print.psych(pca, cut = 0.3, sort = TRUE)

# Creating diagram showing the components and how the manifest variables load:

fa.diagram(pca) 

# Loading of variables on to components:

fa.sort(pca$loading)

# Communalities of variables across components (will be one for PCA since all the variance is used):

pca$communality 

plot(pca$values, type = "b") # scree plot
pca$Vaccounted
pca$values #output eigenvalues

# Another way to look at eigen values plus variance explained (need to use princomp function fof PCA to 
# get right class for use with factoextra dunctions):

pcf=princomp(glass)
factoextra::get_eigenvalue(pcf)
factoextra::fviz_eig(pcf, addlabels = TRUE, ylim = c(0, 50)) # Visualise the Eigenvalues
factoextra::fviz_pca_var(pcf, col.var = "black")
factoextra::fviz_pca_var(pcf, col.var = "cos2",
             gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"), 
             repel = TRUE # Avoid text overlapping
             )


#### Difference

### QESTION 1. Are there any differences between patients having different chest pain to the angiographic
### disease status? Report your findings. [Hint: Consider variables ChestPain and AHD] [5marks]


# Let�s load the data:

heartdisease <- read.csv("heartdisease.csv")

# Checking it:

head(heartdisease)

# PSI-lab5.Rmd line 163 y 187

# Look at the numbers in the relevant categories of each variables:

table(heartdisease$ChestPain)
table(heartdisease$AHD)

# Now Let�s use the Crosstable function:

gmodels::CrossTable(heartdisease$ChestPain, heartdisease$AHD, fisher = TRUE, chisq = TRUE, expected = TRUE, sresid = TRUE, format = "SPSS")

# A Chi-square test analysis  was conducted to explore the difference chest pain on having or no 
# the angiographic disease.  The Chi-square test indicated no significant association between the two 
# variables, X2(1; n = 303) = 81:81; p = 1.25;


### QUESTION 2. Is there any difference between cholesterol level and angiographic disease status?
### Report your findings. [Hint: Consider variables Chol and AHD] [5 marks]


# So, here we have one nominal variable with 2 groups(yes,no) and one continuous variable,
# so I am going to try to analyze in this way:

describeBy(heartdisease$Chol,group=heartdisease$AHD)



# Let�s check fo normality of the continuos variable:

skew<-semTools::skew(heartdisease$Chol)
kurt<-semTools::kurtosis(heartdisease$Chol)

# Let�s make standardized score:

skew[1]/skew[2]
kurt[1]/kurt[2]

# Both two are out of the accepted parameters:

# Let�s check which are max and min standardized score for normalization:

summary(scale(heartdisease$Chol))

# It is out of the accepted parameters for normal distribution

# Let�s plot it:

Old <- ggplot(heartdisease, aes(x=heartdisease$Chol))
Old <- Old + labs(x="Chol")
Old <- Old + geom_histogram(binwidth=0.09, colour="red", aes(y=..density.., fill=..count..))
Old <- Old + scale_fill_gradient("Count", low="#DCDCDC", high="#7C7C7C")
Old <- Old + stat_function(fun=dnorm, color="red",args=list(mean=mean(heartdisease$Chol, na.rm=TRUE), sd=sd(heartdisease$Chol, na.rm=TRUE)))
Old


# Let�s plot in this way:

qqnorm(heartdisease$Chol)
qqline(heartdisease$Chol, col=2) 

library(car) # To useLevene's test for homogeneity of variance 
library(coin)# To Wilcox test (non-parametric)

# Conducting Levene's test for homogeneity of variance in library car,  I am checking if the is diference in the 
# variances of the two variables:

newtest <- car::leveneTest(Chol ~ AHD, data=heartdisease)

newtest

# The null hypothesis is that all variances are equal. A resulting
# p-value under 0.05 means that variances are not equal and then
# further parametric tests are not suitable. 
# In this case the p-value is 0.7, so we can go ahead with the parametric test:

stats::t.test(Chol ~ AHD,var.equal=TRUE,data=heartdisease)

# An independent samples test was conducted to compare the cholesteron for having or 
# not the anhiographic disease status,
# No significant difference scores for the cholesterol was found(M=242.64 for 
# No respondents),(M=251.47 for yes respondents),(t(301)=-1.48; p = 0.13).


### QUESTION 3. Are there any differences between the free sulfur dioxide and quality of the wine?
### Report your findings. [Hint: Consider variables free sulfur dioxide and quality] [5marks]
                                                                               


# Let�s load the data:

wine <- read.csv("winequality-red.csv")
head(wine)

# checking the distribution of the categories of the variable quality:
table(wine$quality)

# checking the normality of the free_sulfur_dioxide variable:

skew<-semTools::skew(wine$free_sulfur_dioxide)
kurt<-semTools::kurtosis(wine$free_sulfur_dioxide)

# Let�s standardized scores:

skew[1]/skew[2]
kurt[1]/kurt[2]

# Falling within acceptable ranges.

# Let�s do the bartlett.test to check the homogeneity of variances:

bartlett.test(wine$free_sulfur_dioxide, wine$quality)

# Variances can be considered homogeneous p-value > 0.05

# Loading packages to or analysis:

library(psych)
library(semTools)
library(stats)
library(ggplot2)
library(FSA)
library(userfriendlyscience) 
library(gmodels)

# Compute the analysis of variance:

res.aov <- aov(wine$free_sulfur_dioxide ~ wine$quality, data = wine)

# Summary of the analysis:

summary(res.aov)

one.way <- userfriendlyscience::oneway(wine$quality, y = wine$free_sulfur_dioxide, posthoc = 'Tukey') 
 
#printout a summary of the anova:
one.way 

# A one way between grops analysis of variance was conducted to explore the differences 
# between the free sulfur dioxide and quality of the wine. Quality of the wine is divided 
# in six groups. There was a statistically significant difference at the p < .05 level in scores 
# for the six categories: F(5; 1593) = 4.75; p = .001.Despite reaching statistical significance, 
# the actual difference in mean scores between groups was quite small. The effect size, calculated 
# using eta squared was .01.


#### Predictive statistics

### QUESTION 1. Model the relationship between humidity and total rented bikes. How good is the
### model? [Hint: Consider the variables hum and cnt] [3 marks]


# Let�s load the data:

bikesharing <- read.csv("bikesharing.csv")
head(bikesharing, 3)

# Checking for missing vales in the response variable:

sum(is.na(bikesharing$cnt))

# Let�s exam the response variable:

# Calling ggplot2 library for make the scatterplot:

library(ggplot2)

# Now, checking for normality in the response variable:

sta <- ggplot(bikesharing, aes(x=bikesharing$cnt))
sta <- sta + labs(x="stat")
sta <- sta + geom_histogram(binwidth=2, colour="black", aes(y=..density.., fill=..count..))
sta <- sta + scale_fill_gradient("Count", low="#DCDCDC", high="#7C7C7C")
sta <- sta + stat_function(fun=dnorm, color="red",args=list(mean=mean(bikesharing$cnt, na.rm=TRUE), sd=sd(bikesharing$cnt, na.rm=TRUE)))
sta

# Let�s describe the variable:

library(Hmisc)
describe(bikesharing$cnt)

# Standarizing the variables:

bikesharing$cnt <- scale(bikesharing$cnt, center = TRUE, scale = TRUE)
bikesharing$hum <- scale(bikesharing$hum, center = TRUE, scale = TRUE)

# Let�s check which are max and min standardised score for normalitation:

summary(bikesharing$cnt)

# lets check if there is Relationship between humidity and total rented bikes using a scatterplot:

scatter_chol_Bl <- ggplot(bikesharing, aes(bikesharing$cnt, bikesharing$hum))
scatter_chol_Bl + geom_point() + geom_smooth(method = "lm", colour = "Yellow", se = F) + labs(x = "hum", y = "cnt")

stats::cor.test(bikesharing$cnt, bikesharing$hum, method='spearman')

# The relationship between total bikes rented and humidity was investigated using a
# spearman correlation. A very weak correlation was found (r = -0.09; p(0.0079) < 0.05),
# So, we could say that there is not correlation between the two variables, its very very small,
# but statistically significant according to the p value.

# Lets call the libraries "lm.beta" and "stargazer" to carry out the model:

library(lm.beta)
library(stargazer)

# ceating the model:

model1 <- lm(bikesharing$hum~bikesharing$cnt)
anova(model1)
summary(model1)
lm.beta(model1)
stargazer(model1, type="text") #Tidy output of all the required stats

# R squared (0.010)indicates that hm explains 1% of the variance in cnt. There is only one 
# predictor at the, so R2 and adjusted R2 are almost the same.
# Overall p value on the basis of F-statistic, normally p value less than 0.05 indicate 
# that overall model is significant, So having p-value: 0.006 it looks is significant.
# With the coefficients got we have this model Predicted: 'cnt' = 6.554 +(-7.538) x 'hum

# How good is the model: According to R squared, that is, explaining just 1% of the variance in cnt,
# the model is not good.

### QUESTION 2. Include a dummy variable (working day) to the model and compare the relationship.
### Report your findings. [3 marks]


# Let�s add the dummy variable workingday into the model:

model2<-lm(bikesharing$hum~bikesharing$cnt+bikesharing$workingday)
anova(model2)
summary(model2)
stargazer(model2, type="text") 
lm.beta(model2)
stargazer(model1, model2, type="text") 

# The model keep explaining just 1% basically, so is not good.
# In this case, added the dmmy variable now having p-value: 0.01 it looks is significant, 
# even(as before) if it explains almost nothing.

