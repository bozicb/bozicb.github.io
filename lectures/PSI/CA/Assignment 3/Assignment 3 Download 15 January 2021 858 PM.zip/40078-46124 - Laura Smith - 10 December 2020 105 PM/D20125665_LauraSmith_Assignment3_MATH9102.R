#Assignment 3 - MATH 9102 Prob & Stats
#D20125665 - Laura Smith
#10/12/2020

##Relevant Library Install & Import for Assignment 3:

if(!require(pastecs))install.packages("pastecs")
if(!require(ggplot2))install.packages("ggplot2")
if(!require(corpcor))install.packages("corpcor")
if(!require(GPArotation))install.packages("GPArotation")
if(!require(psych))install.packages("psych")
if(!require(REdaS))install.packages("REdaS")
if(!require(Hmisc))install.packages("Hmisc")
if(!require(corrplot))install.packages("corrplot")
if(!require(ggcorrplot))install.packages("ggcorrplot")
if(!require(factoextra))install.packages("factoextra")
if(!require(nFactors))install.packages("nFactors")
if(!require(coin))install.packages("coin")
if(!require(gmodels))install.packages("gmodels")
if(!require(stats))install.packages("stats")
if(!require(foreign))install.packages("foreign")
if(!require(lmSupport))install.packages("lmSupport")
if(!require(lm.beta))install.packages("lm.beta")
if(!require(stargazer))install.packages("stargazer")

library(pastecs) #Descriptive Stat Summaries
library(ggplot2) #For Graphs & Histograms
library(corpcor) #Covariance & correlation estimation
library(GPArotation) #GPA factor rotation
library(psych) #Descriptive functions
library(REdaS) #For Confidence intervals
library(Hmisc) #Functions & visualization
library(corrplot) #visualization of correlation matrix
library(ggcorrplot)#visualization of correlation matrix using ggplot2
library(factoextra) #extract functions and visualization
library(nFactors) #parallel analysis
library(coin) #For man whitney u test (non-parametric)
library(gmodels) #For chi test
library(stats) #Summary stats
library(foreign) #To work with SPSS data
library(lmSupport) #Extra functions for linear model (may require install of nloptr also)
library(lm.beta) #More linear model functions
library(stargazer) #For formatting outputs/tables


###Part 1: PCA


#Q.1

#The eigenvector of a covariance matrix give us the directions in which the data varies by the most.
#The first eigenvector gives us the direction in which the data varies the most and the second 
#eigenvector gives us the direction of highest variance of the points that are perpendicular to the first eigenvector,
#if there is a third dimension there will be a third eigenvector which will show the direction of variance of points 
#perpendicular to the first two eigenvectors and so on for each additional dimension.


#Q.2 

#Compression should be the last step in the PCA process and should be applied to the results of the model.
#If compressed any earlier in the process this will obscure correlations in the data. 


#Q.3

#Read in glass dataset
glass <- read.csv("glassidentification.csv", header=TRUE)

#Diff methods for creating correlation matrix
glassMatrix<-cor(glass)
round(glassMatrix, 2)
Hmisc::rcorr(as.matrix(glass))

#Visualisation using numbers
corrplot::corrplot(glassMatrix, method="number")

#Visualisation of correlations using circles
corrplot::corrplot(glassMatrix, method="circle", type="lower")

#Visualisation of significance levels at 0.05
res1 <- corrplot::cor.mtest(glassMatrix, conf.level = .95)
corrplot::corrplot(glassMatrix, p.mat = res1$p, type="lower", sig.level = .05)

###Initial stats
#Bartlett's test
psych::cortest.bartlett(glass)

#KMO
psych::KMO(glass)

#Determinent
det(glassMatrix)

#On raw data using principal components analysis
#For PCA we know how many factors if is possible to find
#principal will work out our loadings of each variable onto each component, the proportion each component explained and the cummulative proportion of variance explai 
pc1 <-  principal(glass, nfactors = 23, rotate = "none")
pc1 <-  principal(glass, nfactors = length(glass), rotate = "none")
pc1#output all details of the PCA
psych::print.psych(pc1, cut = 0.3, sort = TRUE)


fa.diagram(pc1) #create a diagram showing the components and how the manifest variables load
fa.sort(pc1$loading) #Loadings of variables on to components
pc1$communality #Communalities of variables across components (will be one for PCA since all the variance is used)

plot(pc1$values, type = "b") #scree plot
pc1$Vaccounted
pc1$values #output eigenvalues
#Another way to look at eigen values plus variance explained (need to use princomp function fof PCA to get right class for use with factoextra dunctions)
pcf=princomp(glass)
factoextra::get_eigenvalue(pcf)
factoextra::fviz_eig(pcf, addlabels = TRUE, ylim = c(0, 50))#Visualise the Eigenvalues
factoextra::fviz_pca_var(pcf, col.var = "black")
factoextra::fviz_pca_var(pcf, col.var = "cos2",
                         gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"), 
                         repel = TRUE # Avoid text overlapping
)

#Visualise contribution of variables
var <- factoextra::get_pca_var(pcf)
corrplot::corrplot(var$contrib, is.corr=FALSE) 

# Contributions of variables to PC1
factoextra::fviz_contrib(pcf, choice = "var", axes = 1, top = 10)
# Contributions of variables to PC2
factoextra::fviz_contrib(pcf, choice = "var", axes = 2, top = 10)

#PCA with rotation
pc2 <-  principal(glass, nfactors = 4, rotate = "varimax")#Extracting 4 factors
psych::print.psych(pc2, cut = 0.3, sort = TRUE)
pc2$communality


#Factor Analysis

#Principal Axis Factoring
pc3 <- fa(glassMatrix, nfactors=4, obs=NA, n.iter=1, rotate="varimax", fm="pa")
psych::print.psych(pc3,cut=0.3, sort=TRUE)

fa.sort(pc3$loading)
fa.diagram(pc3)#create a diagram showing the factors and how the manifest variables load
plot(pc3$values, type = "b") #scree plot

pc3$Vaccounted#Variance accounted for
pc3$values #output eigenvalues



####PART 2 DIFFERENCE


#Q.1

#Load in heart disease dataset
heartdisease <- read.csv("heartdisease.csv")

#Create cross table with chi-squared test as chestpain is a categorical variable and there are 2 groups in the independant variable
CrossTable(heartdisease$ChestPain, heartdisease$AHD, fisher = TRUE, chisq = TRUE, expected = TRUE, format = "SPSS")

#Minimum expected frequency is more than 5confirming this test is appropriate.
#Percentages add up to 100% indicating no errors in percentages. 

#A Chi-Square test for independence indicated no significant association between chest pain and angiographic disease status X2(1,n=303) = 81.8; p = 0)


#Q. 2

#Summarize cholesterol variable
summary(heartdisease$Chol)

#Histogram of Cholesterol to test for normailty
gChol <- ggplot(heartdisease, aes(x=Chol)) + geom_histogram(binwidth=25, colour="black", fill = "pink")
gChol <- gChol + labs(x="Cholesterol Level", y = "Number of Patients") 
gChol <- gChol+ stat_function(fun = function(x) (dnorm(x, mean = mean(heartdisease$Chol, na.rm=TRUE), sd = sd(heartdisease$Chol, na.rm=TRUE)) * 7500), colour = "red", size = 1)
gChol
#Data is not normal, it is positively skewed

#Descriptive ststistics of cholesterol based on Angigraphic disease status
describeBy(heartdisease$Chol, group = heartdisease$AHD)

ADHyes <- subset(heartdisease, heartdisease$AHD == 'Yes')
ADHno <- subset(heartdisease, heartdisease$AHD == 'No')

#Create plot of Yes ADH Cholesterol data
gADHY <- ggplot(ADHyes, aes(x=ADHyes$Chol))
gADHY <- gADHY + labs(x="Yes ADH")
gADHY <- gADHY + geom_histogram(binwidth=25, colour="black", aes(y=..density.., fill=..count..))
gADHY <- gADHY + scale_fill_gradient("Count", low="#DCDCDC", high="#7C7C7C")
gADHY <- gADHY + stat_function(fun=dnorm, color="red",args=list(mean=mean(ADHyes$Chol, na.rm=TRUE), sd=sd(ADHyes$Chol, na.rm=TRUE)))
gADHY

#Create plot of No ADH Cholesterol data
gADHN <- ggplot(ADHno, aes(x=ADHno$Chol))
gADHN <- gADHN + labs(x="No ADH")
gADHN <- gADHN + geom_histogram(binwidth=25, colour="black", aes(y=..density.., fill=..count..))
gADHN <- gADHN + scale_fill_gradient("Count", low="#DCDCDC", high="#7C7C7C")
gADHN <- gADHN + stat_function(fun=dnorm, color="red",args=list(mean=mean(ADHno$Chol, na.rm=TRUE), sd=sd(ADHyes$Chol, na.rm=TRUE)))
gADHN

#Summarize the cholesterol levels for the 2 groups
summary(ADHyes$Chol)
summary(ADHno$Chol)

#The appropriate test for differences her is the Man-Whitney-U Test
wilcox.test(Chol ~ AHD, data = heartdisease)

#Cholesterol levels do not differ between those who do have angiographic disease (ADH = Yes, median 249)
#and those who don't (AHD = No, median 234.5) as th ep-value is 0.035.


#Q.3

#Load in wine data
wine <- read.csv("winequality-red.csv")

#Summarize the 2 variable sin question
summary(wine$free_sulfur_dioxide)
summary(wine$quality)
#Summarize relationship stats between 2 variables by group
describeBy(wine$free_sulfur_dioxide, group = wine$quality)

#Plot data to see if it is normal
gWine <- ggplot(wine, aes(x=free_sulfur_dioxide)) + geom_histogram(binwidth=5, colour="black", fill = "light blue")
gWine <- gWine + labs(x="Free Sulfur Dioxide Level", y = "Number of Patients") 
gWine <- gWine + stat_function(fun = function(x) (dnorm(x, mean = mean(wine$free_sulfur_dioxide, na.rm=TRUE), sd = sd(wine$free_sulfur_dioxide, na.rm=TRUE)) * 7500), colour = "blue", size = 1)
gWine
#Data is positively skewed

#The appropriate test for difference her is the kruksal test (Ordinal and non-parametric)
stats::kruskal.test(free_sulfur_dioxide ~ quality, data=wine)

#The results show that there is no difference between these variables. 
#Chi-squared is 31.128, df = 5 and p-value = 8.836e-06



####PART 2 PREICTIVE STATISTICS


#Q.1

#Load in bike sharing data
bike <- read.csv("bikesharing.csv")

#Create model to compare humidity levels and total amount of rented bikes
modelq1 <- lm(bike$hum ~ bike$cnt)
anova(modelq1)
summary(modelq1)
lm.beta(modelq1)
stargazer(modelq1, type="text")

#F-statistic is 7.462, p-value is 0.006 which is more than 0.001 and so not statistically significant.
#Adjusted R squared is 0.008 which means that humidity does not explain much of the variance in amount of rented bikes. 


#Q.2 

#Add dummy variable of working day to the model
modelq2<-lm(bike$hum ~ bike$cnt + bike$workingday)
anova(modelq2)
summary(modelq2)
lm.beta(modelq2)
stargazer(modelq2, type="text")
#F-statistic is 4.073 and p-value is 0.01742 for this model with a dummy variable.

#Model comparisson
stargazer(modelq1, modelq2, type="text")

#The adjusted r squared for th second model is lower and therefor adding in the dummy variable does not improve the model

