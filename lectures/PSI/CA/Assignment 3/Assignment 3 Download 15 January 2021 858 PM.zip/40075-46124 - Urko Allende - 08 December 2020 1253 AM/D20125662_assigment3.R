library(corpcor)
library(GPArotation)
library(psych)
library(REdaS)
library(Hmisc)
library(corrplot)
library(ggcorrplot)
library(factoextra)
library(nFactors)
library(foreign) 
library(lmSupport)
library(lm.beta)
library(stargazer)

path <- 'D:/Data Science MsC/Statistics/Assignment 3/Data/'
getwd()

################ PCA ###################
###########
## 1. What do the eigenvectors of the covariance matrix give us? 
################################################################

# The eigenvectors of the covariance matrix will point to the dimensions where the data points are spread the most, 
# in otherwords, where the variance is the greatest

###########
## 2. When can we decide to compress the data in PCA process?
#############################################################

# We are trying to get rid of multicollinearity as it could provide a false signal and affect our model 
# You also want the fewest number of predictive variables for the most predictive power

###########
## 3. Read the glass identification data provided.   
## Apply PCA algorithm to reduce the dimensions.  
## Analyze your findings.
##################################################

# glass_test <- read.csv("D:/Data Science MsC/Statistics/Assignment 3/Data/glassidentification.csv")
glass <- read.csv("D:/Data Science MsC/Statistics/Assignment 3/Data/glassidentification.csv")
glass$X <- NULL
glass$id <- NULL

head(glass)

#Determinant
det(cor(glass)) # [1] 3.879978e-05 > comment: almost 0 indicative of no multicollinearity

#Bartlett Test of Sphericity
psych::cortest.bartlett(glass, n = length(glass)) 
# p.value is 0 > comment: we reject the null hypothesis assuming that samples have equal variance
# there is no homogeneity, hence PCA is recommended                                                  

#KMO
psych::KMO(glass)
REdaS :: KMOS(glass)
# Overall MSA =  0.19 > comment: "unacceptable" according to KMO for factor analysis 
### It is not entirely clear that dimension reduction should be performed

#PCA
pc1 <-  principal(glass, nfactors = length(glass), rotate = "varimax") # first method
pc1_2 <- princomp(glass) # second method compatible with get_eigenvalue
plot(pc1$values, type = 'b') 
# scree plot > comment: there doesn't seem to be a clear turning point, 
# Although the first two points account for the most eigenvalues

pc1$values # output eigenvalues > comment: only the first 4 are > 1
factoextra::get_eigenvalue(pc1_2) # the first two dimensiones account for 81% of the variance

################ DIFFERENCE ##############################

###########
#1. Are there any differences between patients having different chest pain to the angiographic disease status
#############################################################################################################

heartdisease <- read.csv("D:/Data Science MsC/Statistics/Assignment 3/Data/heartdisease.csv")

library(gmodels)
gmodels::CrossTable(heartdisease$ChestPain, heartdisease$AHD, chisq = T, fisher = T, expected = T, format = 'SPSS', sresid = T)
#p =  1.086255e-18  We reject the null hypothesis, hence we can say that there are differences in the groups of chest pain affecting AHD

###########
#2. Is  there  any  difference  between  cholesterol  level  and  angiographic  disease  status?
##############################################################################################

#Check normality of the distribution
ggqqplot(heartdisease$Chol) #
plot(density(heartdisease$Chol)) 
# visually we can see that only a few observations lie outside the expected values for a normal distribution
shapiro.test(heartdisease$Chol) # p-value = 5.912e-09 rejects the null hypothesis - distribution is not normal
Chol <- as.data.frame(sort(scale(heartdisease$Chol))) 

Chol_3.96 <- Chol %>%
  filter(Chol$`sort(scale(heartdisease$Chol))` < 3.29 & Chol$`sort(scale(heartdisease$Chol))` > -3.29)

print((length(Chol$`sort(scale(heartdisease$Chol))`) - length(Chol_3.96[,1]))/ length(Chol$`sort(scale(heartdisease$Chol))`))
# only 3% of the data is outside the +-3.96 zscores - hence we will treat the distribution as normal

boxplot(heartdisease$Chol ~ heartdisease$AHD)
t.test(heartdisease$Chol ~ heartdisease$AHD, mu = 0, alternative = "two.sided")
#p-value = 0.1366 > we fail to reject the null hypothesis, hence we can conclude that the difference in cholesterol means 
# in both AHD groups (Yes & No) is close to 0

###########
#3. Are  there  any  differences  between  the  free  sulfur  dioxide  and  quality  of  the  wine?
###################################################################################################

wine <- read.csv("D:/Data Science MsC/Statistics/Assignment 3/Data/winequality-red.csv")

cor.test(wine$free_sulfur_dioxide, wine$quality)
plot(wine$free_sulfur_dioxide, wine$quality)
abline(lm(wine$quality ~ wine$free_sulfur_dioxide))
#cor -0.05065606  there is a close-to-zero relationship between free_sulfur and the quality of the wine 
# (the result is statistically significant p-value = 0.04283)

################ PREDICTIVE STATISTICS ###################

###########
## 1. Model the relationship between humidity and total rented bikes.  How good is the model?
############################################################################################

bike <- read.csv("D:/Data Science MsC/Statistics/Assignment 3/Data/bikesharing.csv")

# cor.test(bike$hum, bike$cnt, method='pearson')
model <- lm(bike$cnt ~ bike$hum)
plot(bike$hum, bike$cnt)
abline(model) # the visual representation of the relationship shows no correlation
anova(model) # Anova confirms the observation > R2 = 0.010 > only 1% of the variation is explained by humidity
# Answer: it is a bad model
summary(model)

###########
## 2. Include a dummy variable (working day) to the model and compare the relationship.Report your findings. 
############################################################################################

library(car)
library(ggpubr) #For creating histograms with more detail than plot

#################### CNT VARIABLE IS NOT NORMALLY DISTRIBUTED ##########################################
#Check normality of the distribution
boxplot(bike$cnt ~ bike$workingday)
ggqqplot(bike$cnt) # does not conform to a normal distribution
plot(density(bike$cnt)) # does not conform to a normal distribution
shapiro.test(bike$cnt) # rejects the null hypothesis - distribution is not normal
ALK <- as.data.frame(sort(scale(bike$cnt))) 

#Skewness and Kurtosis
skew <- semTools::skew(bike$cnt)
kurt <- semTools::kurtosis(bike$cnt)
#We divide the skew statistic by the standard error to get the standardised score
skew[1]/skew[2] # does satisfy normal dist
kurt[1]/kurt[2] # does not satisfy normal dist
########################################################################################################


t.test(bike$cnt ~ bike$workingday, var.eq = TRUE) # we reject the null hypothesis assuming equal means
model2 <- lm(bike$cnt ~  bike$hum + bike$workingday)
anova(model2)
summary(model2) # Adjusted R-squared:  0.01147 which is higher than the previous model (0.10)
# 11.47% of the variation is explained by hum and whether or not is a working day
