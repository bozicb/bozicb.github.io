### PCA
# 1. What do the eigenvectors of the covariance matrix give us?
# - They give us the direction in which the data varies the most. 

# 2. When can we decide to compress the data in PCA process? Explain the effects if any.
# - When it tries to explain the maximum amount of total variance in a correlation matrix. It transforms the variables into a set of linear components.

# 3. Read the glass identification data provided. Apply PCA algorithm to reduce the dimensions. Analyze your findings.
if(!require("psych"))install.packages("psych")
library(psych)

glass <- read.csv("glassidentification.csv")

pc1 <- principal(glass, nfactors=12, rotate="none")
plot(pc1$values, type="b") # scree plot
pc1$values # output eigen values 
# We only want to use the factors with eigenvalues greater than 1 which is 4
pc2 <- principal(glass, nfactors=4, rotate="varimax") # Reduce to 4 dimensions
psych::print.psych(pc2, cut = 0.3, sort = TRUE)
pc2$communality


### Difference
# 1. Are there any differences between patients having different chest pain to the angiographic disease status? Report your findings.
# (ChestPain & AHD)
if(!require("gmodels"))install.packages("gmodels")
library(gmodels)
heartdisease <- read.csv("heartdisease.csv")
# Because the data is categorical and there are 2 groups, I'll use the chi-squared test and fisher's exact
gmodels::CrossTable(heartdisease$ChestPain, heartdisease$AHD, fisher = TRUE, chisq = TRUE, expected = TRUE, sresid = TRUE, format = "SPSS")
# Our null hypothesis is that there are no differences between patients having different chest pain in association with the angiographic disease status
# We can see for each type of chest pain, that there is a significant difference in counts between Yes for angiographic disease and No
# The chi squared value is very high at 81.81577 which indicates that the data doesn't fit our null hypothesis
# Also with a very low p value I think we can reject the null hypothesis
# This means that we can conclude that there is a difference between patients having chest pain because of the angiographic disease status

# 2. Is there any difference between cholesterol level and angiographic disease status? Report your findings
# (Chol and AHD)
hist(heartdisease$Chol)
# The data is skewed and continuous so I'll use the Mann-Whitney U (Wilcoxon) test
if(!require("stats"))install.packages("stats")
library(stats)

wilcox.test(Chol ~ AHD, data=heartdisease)
# This test can be used to see if our null hypothesis that there is no difference between cholesterol level and AHD status.
# It compares the median values for cholesterol from the two populations (yes AHD/no AHD)
# The p-value is 0.03536 which is less than the significance level 0.5
# This means that we can conclude that there is a difference in cholesterol for different AHD statuses.

# 3. Are there any differences between the free sulfur dioxide and quality of the wine?
# (free_sulfur_dioxide and quality)
wine <- read.csv("winequality-red.csv")
hist(wine$free_sulfur_dioxide)
hist(wine$quality)
plot(wine$free_sulfur_dioxide ~ wine$quality)
# Going to use Pearsons correlation test and our data is continuous and looks normally distributed
cor.test(wine$free_sulfur_dioxide, wine$quality, method="pearson")
# Pearson's correlation coefficient is very low at a value of -0.05 which means there is little to no correlation between the free sulfur dioxide and quality of the wine
# This means that the free sulfur dioxide does not directly affect the quality of the wine 


### Predictive Statistics
# 1. Model the relationship between humidity and total rented bikes. How good is the model?
# (hum and cnt)
bike <- read.csv("bikesharing.csv")
hist(bike$hum) # left skewed
hist(bike$cnt) # normally distributed
plot(bike$hum ~ bike$cnt) # no strong correlation
bikeModel <- lm(bike$hum ~ bike$cnt)
# How good is the model?
anova(bikeModel)
summary(bikeModel)
# The p-level is low (0.006454) which means that the model fits the data well

# 2. Include a dummy variable (working day) to the model and compare the relationship. Report your findings.
bikeModelDummy <- lm(hum ~ cnt + workingday, data = bike)
anova(bikeModelDummy)
summary(bikeModelDummy)
# Our model is still significant with p-value 0.01742 and F stat 4.073 on 2 and 728 DF