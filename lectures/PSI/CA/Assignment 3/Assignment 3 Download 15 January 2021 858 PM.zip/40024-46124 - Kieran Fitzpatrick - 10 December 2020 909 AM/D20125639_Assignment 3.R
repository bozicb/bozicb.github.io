####### PCA ############


glass <- read.csv("Assignment 3/glassidentification.csv")
View(glass)

#1. What do the eigenvectors of the covariance matrix give us?
Eigenvectors of a covariance matrix  are the directions in which the data varies the most.
i.e. the 1st eigenvector is the direction which the data varies the most, 
the 2nd eigenvector is the direction of greatest variance among those that are perpendicular
to the first eigenvector etc...

#2. When can we decide to compress the data in PCA process? Explain the efects if any.
When there is high Collinearity between two variables. 
If we conduct inferential statistics with collinear variables then
the model will produce unreliable results. eg. Bias, Type 1 error

###### Question 3 #########
glass<- subset(glass, select = -c(X, id) )
glass
glassMatrix<-cor(glass)
round(glassMatrix, 2)
heatmap(cor(glass), Rowv = NA, Colv = NA)

psych::cortest.bartlett(glass)
psych::cortest.bartlett(glassMatrix, n = 214)


pc1 <-  principal(glass, nfactors = 10, rotate = "none")
pc1 <-  principal(glass, nfactors = length(glass), rotate = "none")
pc1#output all details of the PCA
psych::print.psych(pc1, cut = 0.3, sort = TRUE)

fa.diagram(pc1) #create a diagram showing the components and how the manifest variables load
fa.sort(pc1$loading) #Loadings of variables on to components
pc1$communality #Communalities of variables across components (will be one for PCA since all the variance is used)

####### Difference ############
heart <- read.csv("Assignment 3/heartdisease.csv")
View(heart)

#Q.1
TAB <- table(heart$ChestPain, heart$AHD)
TAB
barplot(TAB, legend=T, beside = T)

chisq.test(TAB) #Reject null hypothesis

fisher.test(TAB)


#Question 2
hist(heart$Cho,probability=T, main="Histogram of Chol
data")
lines(density(heart$Cho),col=2)
boxplot(heart$Chol~heart$AHD) #There is one outlier extremely far from the rest of sample
summary(heart$Chol)

heart1 <- heart[!(heart$Chol > 500),]
View(heart1)
qqnorm(heart1$Chol)
qqline(heart1$Chol)
shapiro.test(heart1$Chol) #Data is not normal

wilcox.test(heart$Chol~heart$AHD) #Significant Difference 

#Question 3.

wine <- read.csv("Assignment 3/winequality-red.csv")
View(wine)
plot(wine$quality, wine$free_sulfur_dioxide)

hist(wine$free_sulfur_dioxide)
wine$quality <- as.factor(wine$quality)
class(wine$quality)

bartlett.test(wine$free_sulfur_dioxide~wine$quality) #Variances are equal

kruskal.test(wine$free_sulfur_dioxide~wine$quality) #REject null hypothesis, there is difference


######## Predictive Statistics #######

bike <- read.csv("Assignment 3/bikesharing.csv")
View(bike)

#Question 1.
plot(bike$cnt, bike$hum)
cor(bike$cnt, bike$hum) #No strong relationship

model1<-lm(bike$cnt~bike$hum)
summary(model1)
#R squared stat of model is: .01013, which indicates model is not strong at predicting number of bikes using 
#humidity as only variable


#Question 2.
library(dplyr)
bike$workingday= recode(bike$workingday, "0"=1, "1"=2)
model2<-lm(bike$cnt~bike$hum + bike$workingday)
summary(model2) #Still a poor model
